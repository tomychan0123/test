﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;


namespace Fubon.Utility.Common
{
    public class TaskQueueManager
    {
        private Dictionary<string, TaskQueue> dicTaskQueues = new Dictionary<string, TaskQueue>();
        private Dictionary<string, Func<Task>> dicCheckFailTasks = new Dictionary<string, Func<Task>>();

        private Timer checkFailTaskTimer; //one minute

        public TaskQueueManager(int checkFailInterval = 60000)
        {
            checkFailTaskTimer = new Timer(checkFailInterval); //one minute
            checkFailTaskTimer.Elapsed += new ElapsedEventHandler(this.timer_DoCheckFail);
            checkFailTaskTimer.Start();
        }

        //無法執行到
        //~TaskQueueManager()
        //{
        //    checkFailTaskTimer.Stop();
        //}


        public TaskQueue GetTaskQueue(string id, Func<Task> checkFailTask = null, int? maxParallelizationCount = null, int? maxQueueLength = null)
        {
            TaskQueue taskQueue = null;

            if (id == null)
                return null;
            if (this.dicTaskQueues.ContainsKey(id))
                taskQueue = this.dicTaskQueues[id];
            else
            {
                taskQueue = new TaskQueue(maxParallelizationCount, maxQueueLength);
                this.dicTaskQueues.Add(id, taskQueue);

                if (checkFailTask != null)
                    this.dicCheckFailTasks.Add(id, checkFailTask);

                Task.Run(() => taskQueue.ProcessBackground());
            }
            return taskQueue;
        }

        //public bool ProcessBackground(string id)
        //{
        //    if (!this.dicTaskQueues.ContainsKey(id))
        //        return false;

        //    TaskQueue taskQueue = this.dicTaskQueues[id];

        //    Task.Run(() => taskQueue.ProcessBackground());

        //    return true;
        //}

        public bool CancelTaskQueue(string id)
        {
            if (!this.dicTaskQueues.ContainsKey(id))
                return false;

            TaskQueue taskQueue = this.dicTaskQueues[id];
            taskQueue.CancelTask();
            return true;

        }

        public TaskQueue GetTaskQueue(string id)
        {
            if (!this.dicTaskQueues.ContainsKey(id))
                return null;

            return this.dicTaskQueues[id];

        }

        public void timer_DoCheckFail(object sender, ElapsedEventArgs e)
        {
            foreach (KeyValuePair<string, Func<Task>> item in this.dicCheckFailTasks)
            {
                Task.Run(item.Value);
            }
        }


    }
}
