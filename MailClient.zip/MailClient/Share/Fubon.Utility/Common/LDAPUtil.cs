﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Text;
using log4net;

namespace Fubon.Utility.Common
{
    public class LDAPUtil
    {
        private static readonly ILog _log = LogManager.GetLogger(typeof(LDAPUtil));

        private static string ldapServer_default = "LDAP://10.201.10.5:389";

        public static string ldapServer { get; set; }

        public static bool ValidateUser(string userName, string password)
        {
            bool result = false;
            if (ldapServer == null)
                ldapServer = ldapServer_default;
 
            DirectoryEntry entry = new DirectoryEntry(ldapServer, userName, password);
            try
            {   DirectorySearcher search = new DirectorySearcher(entry);
                search.Filter = "(&(cn=" + userName + "))";
                SearchResult searchResult = search.FindOne();
                result = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex);
                result = false;
            }
            finally
            {
                entry.Dispose();
            }
            return result;

        } 
    }



}
