﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using FileExpApp.Models;
using log4net;
using Newtonsoft.Json;
using Ionic.Zip;

namespace FileExpApp.Controllers
{
    public class HomeController : Controller
    {
        private static ILog _log = LogManager.GetLogger(typeof(HomeController));
        //
        // GET: /Home/
        public ActionResult Index()
        {
            return View();
        }
        /// <summary>
        /// 取得web.config設定目錄下的所有目錄
        /// </summary>
        /// <returns></returns>
        public JsonResult GetDirs()
        {
            FileDir rootDirs = FileToolKits.GetDirs();
            return this.Json(rootDirs, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 取得目錄中的檔案
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public JsonResult GetFiles(string id)
        {
            List<FileInf> files = FileToolKits.GetFilesByFolderName(id);
            return this.Json(files, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 傳出檔案
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult DownloadFile(string id)
        {
            _log.Error("DownloadFile id=" + id);
            if (System.IO.File.Exists(id))
            {
                string  strDownLoadFileName   = System.IO.Path.GetFileName(id);
                string mimeType = "application/octet-stream"; //"application/binary"; //
                if (HttpContext.Request.Browser.Browser == "IE")
                {
                    strDownLoadFileName = HttpContext.Server.UrlPathEncode(strDownLoadFileName);
                }
                using (System.IO.FileStream fs = new System.IO.FileStream(id, System.IO.FileMode.Open, 
                    System.IO.FileAccess.Read, System.IO.FileShare.Read))
                {
                    // Read the source file into a byte array.
                    byte[] bytes = new byte[fs.Length];
                    int numBytesToRead = (int)fs.Length;
                    int numBytesRead = 0;
                    while (numBytesToRead > 0)
                    {
                        // Read may return anything from 0 to numBytesToRead.
                        int n = fs.Read(bytes, numBytesRead, numBytesToRead);
                        // Break when the end of the file is reached.
                        if (n == 0)
                            break;
                        numBytesRead += n;
                        numBytesToRead -= n;
                    }
                    numBytesToRead = bytes.Length;
                    return File(bytes, mimeType, strDownLoadFileName);
                }
             }
            return null;
        }

        public ActionResult UploadFile(string uploadPath)
        {
            _log.Error("UploadFile() uploadPath=" + uploadPath);
            HttpPostedFileBase postedFile = Request.Files["processfile"];
            string fileName = postedFile.FileName;
            string path = Path.Combine(uploadPath, fileName);
            
            if (System.IO.File.Exists(path))
                System.IO.File.Delete(path);

            postedFile.SaveAs(path);
            if (postedFile != null) //(2)
            {
                return Content("{success:true, result:\"File uploaded correctly\"}"); //(4)
            }
            return new JsonResult() //(6)
            {
                ContentType = "text/html",
                Data = new { success = false, error = "File uploaded error" }
            };
        }

        /// <summary>
        /// 刪除檔案
        /// </summary>
        /// <returns></returns>
        public ActionResult DelFiles(string path, string[] files)
        {
            Dictionary<string, string> jo = new Dictionary<string, string>();
            bool result = false;
            string reason = "";
            foreach (string file in files)            {
                string fullPath = Path.Combine(path, file);
                if (System.IO.File.Exists(fullPath))
                {
                    try
                    {
                        System.IO.File.Delete(fullPath);                        
                        result = true;                        
                    }
                    catch (Exception e)
                    {
                        _log.Error(e.Message);
                        _log.Error(e.StackTrace);
                        result = false;
                        reason = "{success:false, result:\"Delete Files failure!e=" + e.Message + "\"}";
                        break;
                    }
                }
                else
                {
                    result = false;
                    reason = "{success:false, result:\"Delete Files not exist!\"}";
                    break;
                }                    
            }
            if (result == true)
            {
                jo.Add("Msg", "刪除成功!");
                jo.Add("ReturnCode", "刪除成功!");
                return Content("{success:true, result:\"Delete Files successful!\"}"); //(4)
            }
            else
            {
                return Content(reason);
            }
        }

        public ActionResult ZipFiles(string path, string[] files, string zipName)
        {
            Dictionary<string, string> jo = new Dictionary<string, string>();

            if (System.IO.File.Exists(Path.Combine(path, zipName)))
                System.IO.File.Delete(Path.Combine(path, zipName));

            using (var zip = new ZipFile()) 
            {
                foreach (string file in files)
                {
                    string fullPath = Path.Combine(path, file);
                    zip.AddFile(fullPath);
                }
                zip.Save(Path.Combine(path, zipName));
            }
            //return DownloadFile(Path.Combine(path, zipName));
            return Content("{success:true, result:\"ZIP Files successful!\"}"); //(4)
        }

        /// <summary>
        /// 讀出檔案
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult ReadFile(string id)
        {
            //string reason = "";
            Dictionary<string, string> jo = new Dictionary<string, string>();
            _log.Error("ReadFile id=" + id);
            string contents = System.IO.File.ReadAllText(id);
            jo.Add("success", "true");
            jo.Add("result", "Read Files successful!");
            jo.Add("data", conv2Html(contents));
            return Content(JsonConvert.SerializeObject(jo), "application/json");
        }

        ///
	    /// Converts some important chars (int) to the corresponding html string
        ///
        public static String conv2Html(int i)
        {
            if (i == '&') return "&amp;";
            else if (i == '<') return "&lt;";
            else if (i == '>') return "&gt;";
            else if (i == '"') return "&quot;";
            else return "" + (char)i;
        }

        ///
        /// Converts a normal string to a html conform string
        ///
        public static String conv2Html(String st)
        {
            System.Text.StringBuilder buf = new System.Text.StringBuilder();
            for (int i = 0; i < st.Length; i++)
            {
                buf.Append(conv2Html(st[i]));
            }
            return buf.ToString();
        }
    }
}