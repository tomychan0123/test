﻿using Fubon.MailService.Server.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Fubon.MailService.Server.Services
{
    [ServiceContract]
    public interface IMailService
    {
        /// <summary>
        /// 取得郵件群組清單
        /// </summary>

        [OperationContract]
        [FaultContract(typeof(Exception))]
        IList<MailGroup> GetMailGroupList(string groupId);

        /// <summary>
        /// 以郵件群組ID取得郵件群組物件
        /// <summary>
        [OperationContract]
        [FaultContract(typeof(Exception))]
        IList<MailInfo> GetMailInfoByGroupId(string groupId);


        [OperationContract]
        [FaultContract(typeof(Exception))]
        IList<MailInfo> GetCanaddUserList(string groupId);
        
        /// <summary>
        ///   Mail Group
        /// </summary>
        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool InsertMailGroup(MailGroup mailgroupdata);

        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool UpdateMailGroup(MailGroup mailgroupdata);


        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool DeleteMailGroup(MailGroup mailgroupdata);

        /// <summary>
        ///   Mail Group Item
        /// </summary>
        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool InsertMailGroupItem(MailInfo mailuserdata);

        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool DeleteGroupItem(MailInfo mailuserdata);

        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool DeleteGroupItemByMailId(MailInfo mailuserdata);


        /// <summary>
        ///   Mail 
        /// </summary>
        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool InsertMail(MailInfo mailuserdata);

        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool UpdateMail(MailInfo mailuserdata);

        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool DeleteMail(MailInfo mailuserdata);



        //以下為event 

        [OperationContract]
        [FaultContract(typeof(Exception))]
        IList<EventMail> GetEventMailList(string eventGroupId);

        [OperationContract]
        [FaultContract(typeof(Exception))]
        int UpdateEventMailList(IList<EventMail> eventMailList);

        //以下為送信服務
        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool SendEventMail(string sysID, string eventId, string attachments); 

        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool SendEventMailWithContent(string sysID, string eventId, string subject, string message, string attachments);

        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool SendEventMailWithParameter(string sysID, string eventId, String[] keys, string[] values, string attachments);

        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool SendEventMailWithSubjectAndParameter(string sysID, string eventId, string subject, String[] keys, string[] values, string attachments);

        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool SendEventMailWithReceiver(string sysID, string eventId, string attachments, string receiver);

        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool SendEventMailWithContentAndReceiver(string sysID, string eventId, string subject, string message, string attachments, string receiver);

        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool SendEventMailWithParameterAndReceiver(string sysID, string eventId, String[] keys, string[] values, string attachments, string receiver);

        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool SendEventMailWithSubjectAndParameterAndReceiver(string sysID, string eventId, string subject, String[] keys, string[] values, string attachments, string receiver);

        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool SendEventMailWithReceiverAndSender(string sysID, string eventId, string attachments, string receiver, string sender);

        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool SendEventMailWithContentAndReceiverAndSender(string sysID, string eventId, string subject, string message, string attachments, string receiver, string sender);

        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool SendEventMailWithParameterAndReceiverAndSender(string sysID, string eventId, String[] keys, string[] values, string attachments, string receiver, string sender);

        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool SendEventMailWithSubjectAndParameterAndReceiverAndSender(string sysID, string eventId, string subject, String[] keys, string[] values, string attachments, string receiver, string sender);


        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool SendEventMailWithSender(string sysID, string eventId, string attachments, string sender);

        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool SendEventMailWithContentAndSender(string sysID, string eventId, string subject, string message, string attachments, string sender);

        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool SendEventMailWithParameterAndSender(string sysID, string eventId, String[] keys, string[] values, string attachments, string sender);

        [OperationContract]
        [FaultContract(typeof(Exception))]
        bool SendEventMailWithSubjectAndParameterAndSender(string sysID, string eventId, string subject, String[] keys, string[] values, string attachments, string sender);
    }
}
