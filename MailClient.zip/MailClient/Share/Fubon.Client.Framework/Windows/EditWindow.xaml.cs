﻿using Fubon.Client.Framework.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Fubon.Client.Framework.Windows
{
    public partial class EditWindow : Window
    {

        public EditWindow()
        {
            InitializeComponent();
            this.Owner = AppService.MainWindow;
        }

        public static readonly DependencyProperty ViewProperty = DependencyProperty.Register("View", typeof(EditView), typeof(EditWindow), new UIPropertyMetadata(null));
        public EditView View
        {
            get
            {
                return (EditView)GetValue(ViewProperty);
            }
            set
            {
                SetValue(ViewProperty, value);
                if (value != null)
                {
                    if (value.ViewModel.EditMode == EditMode.View)
                    {
                        HeaderIcon.Source = new BitmapImage(
                                    new Uri(
                                        "pack://application:,,,/Fubon.Client.Framework;;component/Resources/Images/info_32.png"));
                        ModeLabel.Content = "檢視";
                    }
                    else if (value.ViewModel.EditMode == EditMode.Modify)
                    {
                        HeaderIcon.Source = new BitmapImage(
                                   new Uri(
                                       "pack://application:,,,/Fubon.Client.Framework;;component/Resources/Images/pencil_32.png"));
                        ModeLabel.Content = "編輯";
                    }
                    else if (value.ViewModel.EditMode == EditMode.Create)
                    {
                        HeaderIcon.Source = new BitmapImage(
                                    new Uri(
                                        "pack://application:,,,/Fubon.Client.Framework;;component/Resources/Images/plus_32.png"));
                        ModeLabel.Content = "新增";
                    }
                }

                //初始設定
                ButtonName_Yes = "OK";
                ButtonName_No = "No";
                IsYesNo = true;
            }
        }

        private void DoYesClicked(object sender, RoutedEventArgs e)
        {
            if (View != null)
            {
                if (View.ViewModel.Validate())
                {
                    IsYesNo = true;
                    DialogResult = true;
                    this.Close();
                }
            }
        }

        private void DoNoClicked(object sender, RoutedEventArgs e)
        {
            if (View != null)
            {
                if (View.ViewModel.Validate())
                {
                    IsYesNo = false;
                    DialogResult = true;
                    this.Close();
                }
            }
        }


        private void DoCancelClicked(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            this.Close();
        }


        public string EditHeaderIcon
        {
            set
            {
                HeaderIcon.Source = new BitmapImage( new Uri( value));
            }
        }

        public string EditModeLabel
        {
            set
            {
                ModeLabel.Content = value;
            }
        }

        //修改按鈕
        public string ButtonName_Yes
        {
            set
            {
                Button_Yes.Content = value;
            }
        }

        //修改按鈕
        public string ButtonName_No
        {
            set
            {
                Button_No.Content = value;
            }
        }

        //三個按鈕使用  預設都是 true
        private bool _isYesNo;
        public bool IsYesNo
        {
            get
            {
                return _isYesNo;
            }
            set
            {
                this._isYesNo = value;
            }
        }

    }
}
