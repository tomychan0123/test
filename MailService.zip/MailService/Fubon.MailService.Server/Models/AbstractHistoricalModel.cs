﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fubon.MailService.Server.Models
{
    /// <summary>
    /// 如果是支援歷程記錄的資料物件，請繼承此類別
    /// </summary>
    public abstract class AbstractHistoricalModel
    {
        /// <summary>
        /// 建立者編號
        /// </summary>
        public string CreateUser { get; set; }

        /// <summary>
        /// 建立時間
        /// </summary>
        public DateTime? CreateTime { get; set; }

        /// <summary>
        /// 更新者編號
        /// </summary>
        public string UpdateUser { get; set; }

        /// <summary>
        /// 更新時間
        /// </summary>
        public DateTime? UpdateTime { get; set; }
    }
}
