package com.xx.demog.dao.mail;

public class MailGroupRepository {

}
