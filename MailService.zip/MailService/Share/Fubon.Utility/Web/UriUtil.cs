﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;

namespace Fubon.Utility.Web
{
    public class UriUtil
    {
        public static string GetPath(string uri)
        {
            var _uri = new Uri(uri);
            string path = _uri.GetLeftPart(UriPartial.Path);
            return path;
        }

        public static string GetQuery(string uri)
        {
            string pstring = null;
            if (uri != null)
            {
                int idx = uri.IndexOf('?');
                if (idx != -1)
                {
                    pstring = uri.Substring(idx + 1);
                }
            }
            return pstring;
        }

        public static NameValueCollection GetQueryParameters(string uri)
        {

            return ToQueryParameters(GetQuery(uri));
        }

        public static NameValueCollection ToQueryParameters(string query)
        {
            NameValueCollection p = new NameValueCollection();
            if (query != null)
            {
                string[] kvs = query.Split('&');
                foreach (string kv in kvs)
                {
                    if (kv.IndexOf('=') != -1)
                    {
                        int idx = kv.IndexOf('=');
                        string k = kv.Substring(0, idx);
                        string v = kv.Substring(idx + 1);
                        p.Add(k, v);
                    }
                    else
                    {
                        p.Add(kv, "");
                    }
                }
            }
            return p;
        }
    }
}
