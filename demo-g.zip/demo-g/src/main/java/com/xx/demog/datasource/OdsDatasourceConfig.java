package com.xx.demog.datasource;
import java.beans.PropertyVetoException;

import javax.sql.DataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.mybatis.spring.mapper.MapperScannerConfigurer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import com.mchange.v2.c3p0.ComboPooledDataSource;

import oracle.jdbc.pool.OracleDataSource;

@Configuration
@MapperScan(basePackages = OdsDatasourceConfig.Package, sqlSessionFactoryRef = "odsSqlSessionFactory")
public class OdsDatasourceConfig {
	private final Logger log = LoggerFactory.getLogger(MurexDatasourceConfig.class);
	static final String Package = "com.xx.demog.dao.mail";//"com.xx.demog.domain.mail";

    static final String MAPPER_LOCATION = "classpath:config.maps.ods/*.xml";//"src/main/resources/config.maps.ods/*.xml";

    @Value("${spring.ods.datasource.url}")
    private String url;

    @Value("${spring.ods.datasource.username}")
    private String user;

    @Value("${spring.ods.datasource.password}")
    private String password;

    @Value("${spring.ods.datasource.driver-class-name}")
    private String driverClass;

    @Bean(name = "odsDataSource")
    @ConfigurationProperties(prefix = "spring.ods.datasource")
    public DataSource odsDataSource() throws Exception {
    	OracleDataSource dataSource  = new OracleDataSource();
//        dataSource.setDriverClass(this.driverClass);
//        dataSource.setJdbcUrl(this.url);
//        dataSource.setUser(this.user);
//        dataSource.setPassword(this.password);
    	dataSource.setUser(this.user);
        dataSource.setPassword(this.password);
        dataSource.setURL(this.url);
        dataSource.setImplicitCachingEnabled(true);
        dataSource.setFastConnectionFailoverEnabled(true);
        return dataSource;
    }

    @Bean(name = "odsTransactionManager")
    @ConfigurationProperties(prefix = "spring.ods.datasource")
    public DataSourceTransactionManager odsTransactionManager() throws Exception{
        return new DataSourceTransactionManager((odsDataSource()));
    }

    @Bean(name = "odsSqlSessionFactory")
    @ConfigurationProperties(prefix = "spring.ods.datasource")
    public SqlSessionFactory odsSqlSessionFactory(@Qualifier("odsDataSource") DataSource odsDataSource)
            throws Exception {
        final SqlSessionFactoryBean sessionFactoryBean = new SqlSessionFactoryBean();
        sessionFactoryBean.setDataSource(odsDataSource);
        sessionFactoryBean.setMapperLocations(new PathMatchingResourcePatternResolver()
        .getResources(OdsDatasourceConfig.MAPPER_LOCATION));

        return sessionFactoryBean.getObject();
    }
}
