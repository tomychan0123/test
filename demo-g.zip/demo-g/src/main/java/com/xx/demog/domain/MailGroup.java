package com.xx.demog.domain;

import java.util.List;

public class MailGroup {
	// 郵件群組ID
	private String GroupId;
	// 郵件群組名稱
	private String GroupName;
	// 郵件內容清單
	private List<MailInfo> MailList;
	
	public String getGroupId() {
		return GroupId;
	}
	public void setGroupId(String groupId) {
		GroupId = groupId;
	}
	public String getGroupName() {
		return GroupName;
	}
	public void setGroupName(String groupName) {
		GroupName = groupName;
	}
	public List<MailInfo> getMailList() {
		return MailList;
	}
	public void setMailList(List<MailInfo> mailList) {
		MailList = mailList;
	}
}
