package com.xx.demog.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.xx.demog.domain.book.Book;
import com.xx.demog.service.BookService;

@Api(tags = "Book")
@RestController
@RequestMapping(value = "/api")
public class BookController {

    @Autowired
	private BookService bookService;

    @ApiOperation(value = "取得某作者的書", notes = "列出作者所有書本")
    @ResponseStatus(HttpStatus.OK)
    @GetMapping(value = "/books/{author}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public List<Book> getAllByAuthor(@ApiParam(required = true, name = "author", value = "作者") @PathVariable String author) {
    	return bookService.getAllByAuthor(author);
    }

    @ApiOperation(value = "取得書本", notes = "列出所有書本")
    @ResponseStatus(HttpStatus.OK)
    @GetMapping(value = "/books", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public List<Book> getAll() {
    	return bookService.getAll();
    }

    @ApiOperation(value = "新增書本", notes = "新增書本的內容")
    @ApiResponses(value = {@ApiResponse(code = 201, message = "存檔成功")})
    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping(value = "/book", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Book create(@ApiParam(required = true, value = "書本內容") @RequestBody Book book) {
        return bookService.create(book);
    }

    @ApiOperation(value = "取得書本內容", notes = "取得書本內容")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "書本資訊")})
    @ResponseStatus(HttpStatus.OK)
    @GetMapping(value = "/book/{bookid}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Book getOne(@ApiParam(required = true, name = "bookid", value = "書本ID") @PathVariable Integer bookid) {
    	return bookService.getOne(bookid);
    }

    @ApiOperation(value = "取得書本(分頁模式)", notes = "取得書本內容(分頁模式)")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "取得書本內容(分頁模式)")})
    @ResponseStatus(HttpStatus.OK)
    @GetMapping(value = "/books", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Book> findBooks(@ApiParam(required=true, name="page", value="頁數") @RequestParam(value="page", defaultValue="0") Integer page,
    							@ApiParam(required=true, name="size", value="筆數") @RequestParam(value="size", defaultValue="5") Integer size) {
    	return bookService.findBooks(page, size);
    }
    
    @ApiOperation(value = "分頁(取得書本)", notes = "分頁(取得書本內容)")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "分頁(取得書本內容)")})
    @ResponseStatus(HttpStatus.OK)
    @GetMapping(value = "/page/books", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name="page", paramType="query", dataType="int", value = "Results page you want to retrieve (0..N)"),
        @ApiImplicitParam(name="size", paramType="query", dataType="int", value = "Number of records per page."),
        @ApiImplicitParam(name="sort", paramType="query", dataType="string", value = "bookid,asc|desc...", allowMultiple = true)
    })
    public Page<Book> findPageBooks(Pageable pageable) {
    	return bookService.findPageBooks(pageable);
    }
}