﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using log4net;

namespace FileExpApp.Models
{
    public class FileToolKits
    {
        private static ILog _log = LogManager.GetLogger(typeof(FileToolKits));
        private static string rootPath =  System.Configuration.ConfigurationManager.AppSettings["FolderRoot"];
        /// <summary>
        /// 取得web.config設定目錄下的所有目錄
        /// </summary>
        /// <returns></returns>
        public static FileDir GetDirs()
        {
            DateTime st_dt = DateTime.Now;
            TimeSpan st_st = new TimeSpan(st_dt.Ticks);
            _log.Error("GetDirs()開始時間 " + st_st.Hours.ToString() + ":" + st_st.Minutes.ToString() + ":" + st_st.Seconds.ToString());
            System.IO.DirectoryInfo root = new System.IO.DirectoryInfo(rootPath); 
            FileDir rootFileDir = new FileDir();
            rootFileDir.text = root.Name;
            rootFileDir.id = rootPath;
            //_log.Error("rootFileDir.id=" + rootPath);
            rootFileDir.children = new List<FileDir>();
            SearchFileFolders(ref rootFileDir);
            FileDir rootDot = new FileDir();
            rootDot.text = "root";
            rootDot.id = "root";
            rootDot.children = new List<FileDir>();
            rootDot.children.Add(rootFileDir);
            DateTime curr_dt = DateTime.Now;
            TimeSpan diff_st = new TimeSpan(curr_dt.Ticks - st_dt.Ticks);
            _log.Error("GetDirs()經過時間 " + diff_st.Hours.ToString() + ":" + diff_st.Minutes.ToString() + ":" + diff_st.Seconds.ToString());
            return rootDot;
        }


        /// <summary>
        /// 依傳入的目錄，往下找目錄
        /// </summary>
        /// <param name="parentFileDir"></param>
        public static void SearchFileFolders(ref FileDir parentFileDir){
            System.IO.DirectoryInfo parentDir = new System.IO.DirectoryInfo(parentFileDir.id);
            try
            {
                //if ((File.GetAttributes(parentFileDir.ToString()) & FileAttributes.ReparsePoint) != FileAttributes.ReparsePoint)
                //{
                    //DirectoryInfo[] dirs = parentDir.GetDirectories();
                List<string> dirs = new List<string>(Directory.EnumerateDirectories(parentFileDir.id));
                    //_log.Error("SearchFileFolders parentFileDir.id=" + parentFileDir.id + " dirs count=" + dirs.Length);
                    parentFileDir.leaf = (dirs.Count == 0);
                    foreach (var dir in parentDir.EnumerateDirectories("*"))
                    {
                        FileDir subFileDir = new FileDir();
                        subFileDir.text = dir.Name;
                        subFileDir.id = Path.Combine(parentFileDir.id, dir.Name);
                        subFileDir.children = new List<FileDir>();
                        parentFileDir.children.Add(subFileDir);
                        SearchFileFolders(ref subFileDir);
                    }
                //}
            }
            catch (Exception e)
            {
                _log.Error("SearchFileFolders parentFileDir.id="+parentFileDir.id+ " e="+e.Message);
                _log.Error(e.StackTrace);
                //parentFileDir.leaf = true;
                //parentFileDir.children.Add(null);
            }
        }


        /// <summary>
        /// 取得目錄中的檔案
        /// </summary>
        /// <param name="folderPath"></param>
        /// <returns></returns>
        public static List<FileInf> GetFilesByFolderName(string folderPath)
        {
            if (string.IsNullOrEmpty(folderPath))
                folderPath = rootPath;
            List<FileInf> files = new List<FileInf>();
            try
            {
                foreach (FileInfo f in new DirectoryInfo(folderPath).EnumerateFiles())
                {
                    try
                    {
                        FileInf fi = new FileInf();
                        fi.id = f.FullName; //Path.Combine(folderPath, f.Name);
                        fi.filename = f.Name;
                        fi.filedate = f.LastWriteTime.ToString("yyyy/MM/dd HH:mm:ss");
                        fi.filesize = GetFileSizeString(f.Length);
                        files.Add(fi);
                    }
                    catch (IOException e)
                    {
                        _log.Error("GetFilesByFolderName folderPath=" + folderPath + " e:" + e.Message);
                        _log.Error(e.StackTrace);
                        return null;
                    }
                }
            }
            catch (Exception e)
            {
                _log.Error("GetFilesByFolderName folderPath=" + folderPath + " e:" + e.Message);
                _log.Error(e.StackTrace);
                return null;
            }
            return files;
        }
        
        /// <summary>
        /// 依檔案Size大小Format
        /// </summary>
        /// <param name="fileSize"></param>
        /// <returns></returns>
        public static string GetFileSizeString(double fileSize)
        {
            string[] sizes = { "B", "KB", "MB", "GB" };
            double len = fileSize;
            int order = 0;
            while (len >= 1024 && order + 1 < sizes.Length)
            {
                order++;
                len = len / 1024;
            }
            return string.Format("{0:0.##} {1}", len, sizes[order]);
        }
    }
}