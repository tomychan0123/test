﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using FileExpApp.Models;
using log4net;
using Newtonsoft.Json;
using Ionic.Zip;
using System.Diagnostics;

namespace FileExpApp.Controllers
{
    public class HomeController : Controller
    {
        private static ILog _log = LogManager.GetLogger(typeof(HomeController));
        private static string rootPath = System.Configuration.ConfigurationManager.AppSettings["FolderRoot"];
        //
        // GET: /Home/
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// 取得web.config設定目錄下的所有目錄
        /// </summary>
        /// <returns></returns>
        public JsonResult GetDirs()
        {
            FileDir rootDirs = FileToolKits.GetDirs();
            return this.Json(rootDirs, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 取得目錄中的檔案
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public JsonResult GetFiles(string id)
        {
            List<FileInf> files = FileToolKits.GetFilesByFolderName(id);
            _log.Error("GetFiles " + id + " return");
            return this.Json(files, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 取得web.config設定目錄下的所有目錄
        /// </summary>
        /// <returns></returns>
        public JsonResult GetDisks(string folderId)
        {
            List<FileContent> files = FileToolKits.GetDisks(folderId);
            _log.Error("GetDisks "+folderId +" return");
            return this.Json(files, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 傳出檔案
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult DownloadFile(string id)
        {
            _log.Error("DownloadFile id=" + id);
            if (System.IO.File.Exists(id))
            {
                string  strDownLoadFileName   = System.IO.Path.GetFileName(id);
                string mimeType = "application/octet-stream"; //"application/binary"; //
                if (HttpContext.Request.Browser.Browser == "IE")
                {
                    strDownLoadFileName = HttpContext.Server.UrlPathEncode(strDownLoadFileName);
                }
                using (System.IO.FileStream fs = new System.IO.FileStream(id, System.IO.FileMode.Open, 
                    System.IO.FileAccess.Read, System.IO.FileShare.Read))
                {
                    // Read the source file into a byte array.
                    byte[] bytes = new byte[fs.Length];
                    int numBytesToRead = (int)fs.Length;
                    int numBytesRead = 0;
                    while (numBytesToRead > 0)
                    {
                        // Read may return anything from 0 to numBytesToRead.
                        int n = fs.Read(bytes, numBytesRead, numBytesToRead);
                        // Break when the end of the file is reached.
                        if (n == 0)
                            break;
                        numBytesRead += n;
                        numBytesToRead -= n;
                    }
                    numBytesToRead = bytes.Length;
                    _log.Error("DownloadFile "+id+" return");
                    return File(bytes, mimeType, strDownLoadFileName);
                }
             }
            return null;
        }

        public ActionResult UploadFile(string uploadPath)
        {
            _log.Error("UploadFile() uploadPath=" + uploadPath);
            if (string.IsNullOrEmpty(uploadPath))
                uploadPath = rootPath;// "D:\\FMG_APP\\";
            HttpPostedFileBase postedFile = Request.Files["processfile"];
            string fileName = postedFile.FileName;
            string path = Path.Combine(uploadPath, fileName);
            
            if (System.IO.File.Exists(path))
                System.IO.File.Delete(path);

            postedFile.SaveAs(path);
            if (postedFile != null) //(2)
            {
                return Content("{success:true, result:\"File uploaded correctly\"}"); //(4)
            }
            return new JsonResult() //(6)
            {
                ContentType = "text/html",
                Data = new { success = false, error = "File uploaded error" }
            };
        }

        /// <summary>
        /// 刪除檔案
        /// </summary>
        /// <returns></returns>
        public ActionResult DelFiles(string path, string[] files)
        {
            Dictionary<string, string> jo = new Dictionary<string, string>();
            bool result = false;
            string reason = "";
            foreach (string file in files)            {
                string fullPath = Path.Combine(path, file);
                if (System.IO.File.Exists(fullPath))
                {
                    try
                    {
                        System.IO.File.Delete(fullPath);                        
                        result = true;                        
                    }
                    catch (Exception e)
                    {
                        _log.Error(e.Message);
                        _log.Error(e.StackTrace);
                        result = false;
                        reason = "{success:false, result:\"Delete Files failure!e=" + e.Message + "\"}";
                        break;
                    }
                }
                else
                {
                    result = false;
                    reason = "{success:false, result:\"Delete Files not exist!\"}";
                    break;
                }                    
            }
            if (result == true)
            {
                jo.Add("Msg", "刪除成功!");
                jo.Add("ReturnCode", "刪除成功!");
                return Content("{success:true, result:\"Delete Files successful!\"}"); //(4)
            }
            else
            {
                return Content(reason);
            }
        }

        public ActionResult ZipFiles(string path, string[] files, string zipName)
        {
            _log.Error("ZipFiles path=" + path + " zipName=" + zipName);
            Dictionary<string, string> jo = new Dictionary<string, string>();

            if (System.IO.File.Exists(Path.Combine(path, zipName)))
                System.IO.File.Delete(Path.Combine(path, zipName));

            using (var zip = new ZipFile()) 
            {
                foreach (string file in files)
                {
                    string fullPath = Path.Combine(path, file);
                    _log.Error("fullPath =" + fullPath);
                    zip.AddFile(fullPath);
                }
                zip.Save(Path.Combine(path, zipName));
            }
            //return DownloadFile(Path.Combine(path, zipName));
            return Content("{success:true, result:\"ZIP Files successful!\"}"); //(4)
        }

        /// <summary>
        /// 讀出檔案
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult ReadFile(string id)
        {
            //string reason = "";
            string lineFormat = "unix";
            Dictionary<string, string> jo = new Dictionary<string, string>();
            _log.Error("ReadFile id=" + id);
            string contents = System.IO.File.ReadAllText(id);
            _log.Error("ReadFile contents.Length=" + contents.Length);
            //判斷是否為dos
            if (contents.Contains(Environment.NewLine))
                lineFormat = "Ms-Dos/Windows";

            jo.Add("success", "true");
            jo.Add("result", "Read Files successful!");
            jo.Add("data", conv2Html(contents));
            jo.Add("lineFormat", lineFormat);
            _log.Error("ReadFile " + id + " return");
            return Content(JsonConvert.SerializeObject(jo), "application/json");
            //System.Web.HttpContext.Current.Response.Clear(); //清除buffer
            //System.Web.HttpContext.Current.Response.ClearHeaders(); //清除 buffer 表頭
            //System.Web.HttpContext.Current.Response.Buffer = false;
            //System.Web.HttpContext.Current.Response.ContentType = "text/xml;charset=\"UTF-8\"";
            //System.Web.HttpContext.Current.Response.AddHeader("Cache-Control", "no-cache"); // for HTTP 1.1
            //System.Web.HttpContext.Current.Response.AddHeader("Pragma", "no-cache"); // for HTTP 1.0
            //System.Web.HttpContext.Current.Response.Expires = 0; // 避免 cache在 proxy server
            //System.Web.HttpContext.Current.Response.Write(JsonConvert.SerializeObject(jo));
            //// 將檔案輸出
            //System.Web.HttpContext.Current.Response.Flush();
            //// 強制 Flush buffer 內容
            //System.Web.HttpContext.Current.Response.End();
            ////return null;
        }

        ///
	    /// Converts some important chars (int) to the corresponding html string
        ///
        public static String conv2Html(int i)
        {
            if (i == '&') return "&amp;";
            else if (i == '<') return "&lt;";
            else if (i == '>') return "&gt;";
            else if (i == '"') return "&quot;";
            else return "" + (char)i;
        }

        ///
        /// Converts a normal string to a html conform string
        ///
        public static String conv2Html(String st)
        {
            System.Text.StringBuilder buf = new System.Text.StringBuilder();
            for (int i = 0; i < st.Length; i++)
            {
                buf.Append(conv2Html(st[i]));
            }
            return buf.ToString();
        }

        /// <summary>
        /// 寫入檔案
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult WriteFile(string id, string data, bool writeBackup, string lineFormat)
        {
            Dictionary<string, string> jo = new Dictionary<string, string>();
            bool result = false;
            string reason = "";
            DateTime now = DateTime.Now;

            _log.Error("WriteFile id=" + id);
            _log.Error("data=" + data);
            _log.Error("writeBackup=" + writeBackup);
            _log.Error("lineFormat=" + lineFormat);
            if (System.IO.File.Exists(id))
            {
                try
                {
                    if (writeBackup == false)
                        System.IO.File.Delete(id);
                    else
                    {
                        System.IO.File.Copy(id, id + "." + now.ToString("yyyymmdd"));
                        System.IO.File.Delete(id);
                    }
                    if (data.Contains(Environment.NewLine) && lineFormat == "unix")
                        data = data.Replace(Environment.NewLine, "\n");
                    else if (data.Contains("\n") && lineFormat == "Ms-Dos/Windows")
                        data = data.Replace("\n", Environment.NewLine);

                    System.IO.File.WriteAllText(id, data);
                    result = true;
                }
                catch (Exception e)
                {
                    _log.Error(e.Message);
                    _log.Error(e.StackTrace);
                    result = false;
                    reason = "{success:false, result:\"Write Files failure!e=" + e.Message + "\"}";
                }
            }
            else
            {
                result = false;
                reason = "{success:false, result:\"Write Files not exist!\"}";
            }
            if (result == true)
            {
                jo.Add("Msg", "寫檔成功!");
                jo.Add("ReturnCode", "寫檔成功!");
                return Content("{success:true, result:\"Write Files successful!\"}"); //(4)
            }
            else
            {
                return Content(reason);
            }
        }

        public ActionResult ExecuteCmd(string cmt)
        {
            Dictionary<string, string> jo = new Dictionary<string, string>();
            string ReturnCode = "0000";
            _log.Error("ExecuteCmd cmt=" + cmt);
            System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + cmt);

            int timeOut = 120000;
            // The following commands are needed to redirect the standard output.
            // This means that it will be redirected to the Process.StandardOutput StreamReader.
            procStartInfo.RedirectStandardOutput = true;
            procStartInfo.UseShellExecute = false;
            procStartInfo.LoadUserProfile = true;
            // Do not create the black window.
            procStartInfo.CreateNoWindow = true;
            // Now we create a process, assign its ProcessStartInfo and start it
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            
            // Get the output into a string
            string result = "C:\\>"+cmt + '\n';
            result += proc.StandardOutput.ReadToEnd();
            //proc.WaitForInputIdle();
            //bool rtncd = proc.WaitForExit(timeOut);
            proc.WaitForExit();

            //Check to see if the process is still running.
            //if (proc.HasExited == false)
                ////Process is still running.
                ////Test to see if the process is hung up.
                //if (proc.Responding)
                //    //Process was responding; close the main window.
                //    proc.CloseMainWindow();
                //else
                //    //Process was not responding; force the process to close.
                //    proc.Kill();
            _log.Error("ExecuteCmd result=" + result);
            //_log.Error("ExecuteCmd WaitForExit rtncd=" + rtncd);

            if (ReturnCode == "0000")
                jo.Add("Msg", "執行成功!");
            else
                jo.Add("Msg", "程式執行超過 60 秒,強制關閉!");
            jo.Add("ReturnCode", ReturnCode);
            jo.Add("Result", result);
            System.Web.HttpContext.Current.Response.Clear(); //清除buffer
            System.Web.HttpContext.Current.Response.ClearHeaders(); //清除 buffer 表頭
            System.Web.HttpContext.Current.Response.Buffer = false;
            System.Web.HttpContext.Current.Response.ContentType = "text/xml;charset=\"UTF-8\"";
            System.Web.HttpContext.Current.Response.AddHeader("Cache-Control", "no-cache"); // for HTTP 1.1
            System.Web.HttpContext.Current.Response.AddHeader("Pragma", "no-cache"); // for HTTP 1.0
            System.Web.HttpContext.Current.Response.Expires = 0; // 避免 cache在 proxy server
            System.Web.HttpContext.Current.Response.Write(JsonConvert.SerializeObject(jo));
            // 將檔案輸出
            System.Web.HttpContext.Current.Response.Flush();
            // 強制 Flush buffer 內容
            System.Web.HttpContext.Current.Response.End();
            _log.Error("ExecuteCmd return");
            return Content("{success:true, result:\"Execute successful!\"}"); //(4)
        }
    }
}