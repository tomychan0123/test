﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fubon.MailService.Server.Models.Base
{
    public class Log4NetLog
    {
        /// <summary>
        /// LogId
        /// </summary>
        public int LogId { get; set; }

        /// <summary>
        /// log日期
        /// </summary>
        public string LogDate { get; set; }

        /// <summary>
        /// LogThread
        /// </summary>
        public string LogThread { get; set; }

        /// <summary>
        /// LogLevel
        /// </summary>
        public string LogLevel { get; set; }

        /// <summary>
        /// LogLogger
        /// </summary>
        public string LogLogger { get; set; }

        /// <summary>
        /// LogMessage
        /// </summary>
        public string LogMessage { get; set; }

        /// <summary>
        /// LogException
        /// </summary>
        public string LogException { get; set; }

        /// <summary>
        /// LogSource
        /// </summary>
        public string LogSource { get; set; }
    }
}