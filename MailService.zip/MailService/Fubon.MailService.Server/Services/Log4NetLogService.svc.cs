﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Fubon.MailService.Server.Models.Base;
using Fubon.Mdp.Server.Helpers;
using System.ServiceModel.Activation;

namespace Fubon.MailService.Server.Services
{
    // 注意: 您可以使用 [重構] 功能表上的 [重新命名] 命令同時變更程式碼、svc 和組態檔中的類別名稱 "Log4NetLogService"。
    // 注意: 若要啟動 WCF 測試用戶端以便測試此服務，請在 [方案總管] 中選取 Log4NetLogService.svc 或 Log4NetLogService.svc.cs，然後開始偵錯。
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class Log4NetLogService : ILog4NetLogService
    {
        public IList<Log4NetLog> GetLog4NetLogList(string logDate)
        {
            Dictionary<string, string> map = new Dictionary<string, string>();
            map.Add("logDate", logDate);
            IList<Log4NetLog> logList = IBatisHelper.QueryForList<Log4NetLog>("Base.Log4NetLog.SelectLog4NetLog", map);
            return logList;
        }
    }
}
