package com.xx.demog.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient("demog/hiSpringBoot")
@Component
public interface HelloOtherService {
	@RequestMapping(value = "/health", method = RequestMethod.GET )
	String health();
}
