﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace Fubon.Utility.Common
{
    public static class CompareUtil
    {
        public static ChangeResult<TSource> CompareTo<TSource, TKey>(this IEnumerable<TSource> local, IEnumerable<TSource> remote, Func<TSource, TKey> keySelector)
        {
            if (local == null) 
                throw new ArgumentNullException("local");
            if (remote == null)
                throw new ArgumentNullException("remote");
            if (keySelector == null)
                throw new ArgumentNullException("keySelector");

            var remoteKeyValues = Enumerable.ToDictionary<TSource, TKey>(remote, keySelector);

            var deleted = new List<TSource>();
            var changed = new List<TSource>();
            var localKeys = new HashSet<TKey>();

            foreach (var localItem in local)
            {
                var localKey = keySelector(localItem);
                localKeys.Add(localKey);

                /* Check if primary key exists in both local and remote 
                 * and if so check if changed, if not it has been deleted
                 */
                TSource changeCandidate;
                if (remoteKeyValues.TryGetValue(localKey, out changeCandidate))
                {
                    if (!changeCandidate.Equals(localItem))
                        changed.Add(changeCandidate);
                }
                else
                {
                    deleted.Add(localItem);
                }
            }
            var inserted = remoteKeyValues
                            .Where(x => !localKeys.Contains(x.Key))
                            .Select(x => x.Value)
                            .ToList();

            return new ChangeResult<TSource>(deleted, changed, inserted);
        }
    }
    public class ChangeResult<T>
    {
        private readonly ReadOnlyCollection<T> deleted;

        private readonly ReadOnlyCollection<T> changed;

        private readonly ReadOnlyCollection<T> inserted;

        public ChangeResult(IList<T> deleted, IList<T> changed, IList<T> inserted)
        {
            this.deleted = new ReadOnlyCollection<T>(deleted);
            this.changed = new ReadOnlyCollection<T>(changed);
            this.inserted = new ReadOnlyCollection<T>(inserted);
        }

        public IList<T> Deleted
        {
            get
            {
                return this.deleted;
            }
        }

        public IList<T> Changed
        {
            get
            {
                return this.changed;
            }
        }

        public IList<T> Inserted
        {
            get
            {
                return this.inserted;
            }
        }

    }
}
