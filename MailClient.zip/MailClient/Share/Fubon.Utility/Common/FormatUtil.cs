﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Fubon.Utility.Common
{
    public sealed class FormatUtil
    {
        public static string ToNumber(string source)
        {
            Regex rgx = new Regex("[^0-9.-]");
            return rgx.Replace(source, "");
        }
    }
}
