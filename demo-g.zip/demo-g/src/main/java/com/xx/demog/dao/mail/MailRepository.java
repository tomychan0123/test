package com.xx.demog.dao.mail;

import java.io.ByteArrayInputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.util.StringUtils;

import com.xx.demog.domain.EventMail;
import com.xx.demog.domain.MailGroup;
import com.xx.demog.domain.MailInfo;
import com.xx.demog.util.MailOutUtil;
import com.xx.demog.util.TemplateHelper;


public class MailRepository{
	private final Logger log = LoggerFactory.getLogger(MailRepository.class);
	private final SqlSession sqlSession;
	@Autowired
	private static Environment env;
	
	public enum SequenceKeys {
		DATA_FLOW("DF"),MailGroup("MG"),MailID("MI"),DeptID("DI");
		
		private String value;
		
		private SequenceKeys(String value) {
			this.value = value;
		}
		
		public String getValue() {
			return this.value;
		}
	}
	
	public MailRepository(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	public List <MailGroup>GetMailGroupList(String groupId) {
		Map parm = new HashMap();
		parm.put("GroupId", groupId);
		List <MailGroup> mailgroup = this.sqlSession.selectList("mail.SelectAllMailGroup", parm);
		return mailgroup;
	}
	
	public List<MailInfo> selectMailInfoById(long id) {
		return this.sqlSession.selectList("mail.SelectMailInfoByGroupId", id);
	}
	
	public List<MailInfo> GetCanaddUserList(String groupId)
    {
		List<MailInfo> userlist = this.sqlSession.selectList("mail.SelectMailInfobyUse", groupId);
        return userlist;
    }
	
	public boolean InsertMailGroup(MailGroup mailgroupdata)
    {
    	log.error("InsertMailGroup GroupId=" + mailgroupdata.getGroupId());
        if (mailgroupdata.getGroupId() == null)
        {
            mailgroupdata.setGroupId(this.sqlSession.selectOne("mailSequence.SelectNextSeqNo_GROUP", SequenceKeys.MailGroup.getValue()));
        }

        this.sqlSession.insert("Base.Mail.InsMailGroup", mailgroupdata);
        return true;
    }
	
	public boolean UpdateMailGroup(MailGroup mailgroupdata)
    {
        int ret = this.sqlSession.update("mail.UpdMailGroup", mailgroupdata);
        return true;
    }
	
	public boolean DeleteMailGroup(MailGroup mailgroupdata)
    {
        
    	this.sqlSession.delete("mail.DelMailGroup", mailgroupdata);
        return true;
    }
	
	/// <summary>
    ///   Mail Group Item
    /// </summary>
    public boolean InsertMailGroupItem(MailInfo maildata)
    {
    	this.sqlSession.insert("mail.InsMailGroupItem", maildata);
        return true;
    }
    
    public boolean DeleteGroupItem(MailInfo maildata)
    {
    	this.sqlSession.delete("mail.DelMailGroupItem", maildata);
        return true;
    }
    
    public boolean DeleteGroupItemByMailId(MailInfo maildata)
    {
    	this.sqlSession.delete("mail.DelMailGroupItemByMailId", maildata);
        return true;
    }
    
    /// <summary>
    ///   Mail 
    /// </summary>
    public boolean InsertMail(MailInfo mailuserdata)
    {
        if (StringUtils.isEmpty(mailuserdata.getMailId())) 
        {
            mailuserdata.setMailId(this.sqlSession.selectOne("mailSequence.SelectNextSeqNo_MAIL", SequenceKeys.MailID));
        }
    	this.sqlSession.insert("mail.InsMailInfo", mailuserdata);
        log.error("InsertMail:" + mailuserdata.getMailId() + " " + mailuserdata.getEmail() + " " + mailuserdata.getUserName());
		return true;
    }
    
    public boolean UpdateMail(MailInfo mailuserdata)
    {
        int ret = this.sqlSession.update("mail.UpdMailInfo", mailuserdata);
        return true;
    }


    public boolean DeleteMail(MailInfo mailuserdata)
    {
    	this.sqlSession.delete("mail.DelMailInfo", mailuserdata);
        return true;
    }
    
    //以下為event
    
    public List<EventMail> GetEventMailList(String eventGroupId)
    {
    	List<EventMail> eventList = this.sqlSession.selectList("mail.SelectEventMailByEventGroup", eventGroupId);
        return eventList;
    }

    public int UpdateEventMailList(List<EventMail> eventMailList)
    {
        int okCount = 0;
        Date now = new Date();
        for (EventMail em:eventMailList)
        {
            em.setUpdateDate(now);
            em.setUpdateUserId("SYSTEM");
            okCount += this.sqlSession.update("mail.UpdateEventMail", em);
        }
        return okCount;
    }
    
   
    //以下為MailHelper
    public boolean SendMailByEventId(String sysId, String eventId, String subject, String message, String fileName, ByteArrayInputStream attachments)
    {
    	boolean isBodyHtml = false;
        Map map = new HashMap();
        map.put("sysID", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = this.sqlSession.selectOne("mail.SelectEventMailByEventId", map);
            
            if (StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                isBodyHtml = true;
            else
                isBodyHtml = false;
            log.error("EventId[" + eventId + "] isBodyHtml=" + isBodyHtml + " eventMail.IsBodyHtml=" + eventMail.getIsBodyHtml());
            
            if (!StringUtils.isEmpty(eventMail) && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
            	List<MailInfo> mails = this.sqlSession.selectList("mail.SelectMailInfoByGroupId", eventMail.getMailGroupId());
            	
                if (!StringUtils.isEmpty(mails) && mails.size() > 0)
                {
                    String mailTo = "";
                    
                    for (MailInfo mi : mails)
                    {
                        if (!StringUtils.isEmpty(mi.getEmail()))
                        {
                            mailTo += mi.getEmail().contains("@") ? mi.getEmail() : mi.getEmail() + "@fubon.com";
                            mailTo += ";";
                        }
                    }
                    return SendMail(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml);
                }
                else
                {
                    log.error("EventId[" + eventId + "] 郵件群組[" + eventMail.getMailGroupId() + "]的郵件清單是空白.");
                    return false;
                }

            }
            else
            {
                log.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }

        }
        catch (Exception e)
        {
        	e.printStackTrace();
            log.error("SendMailByEventId error", e.getMessage());
        }
        return false;
    }
    
    public boolean SendMailByEventIdTemplate(String sysId, String eventId, String subject, HashMap<String, Object> attrs, String fileName, ByteArrayInputStream attachments)
    {
    	Map<String, String> map = new HashMap<String, String>();
        map.put("sysId", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = this.sqlSession.selectOne("mail.SelectEventMailFullByEventId", map);
            if (!StringUtils.isEmpty(eventMail) && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
            	List<MailInfo> mails = this.sqlSession.selectList("mail.SelectMailInfoByGroupId", eventMail.getMailGroupId());
            	boolean isBodyHtml = false;
                if (!StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                    isBodyHtml = true;
                else
                    isBodyHtml = false;
                if (mails != null && mails.size() > 0)
                {
                    String mailTo = "";
                    for (MailInfo mi : mails)
                    {
                        if (!StringUtils.isEmpty(mi.getEmail()))
                        {
                            mailTo += mi.getEmail().contains("@") ? mi.getEmail() : mi.getEmail() + "@fubon.com";
                            mailTo += ";";
                        }
                    }
                    if (StringUtils.isEmpty(subject))
                        subject = eventMail.getMailSubject();
                    String message = TemplateHelper.RenderTemplateByContent(eventMail.getMailTemplate(), attrs);
                    return SendMail(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml);
                }
                else
                {
                    //if (_log.IsInfoEnabled)
                        log.error("EventId[" + eventId + "] 郵件群組[" + eventMail.getMailGroupId() + "]的郵件清單是空白.");
                    return false;
                }

            }
            else
            {
                //if (_log.IsInfoEnabled)
                    log.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }
        }
        catch (Exception e)
        {
        	e.printStackTrace();
            log.error("SendMailByEventIdTemplate error", e.getMessage());
        }
        return false;
    }
    
    public boolean SendMailByEventIdAndReceiver(String sysId, String eventId, String fileName, ByteArrayInputStream attachments, String receiver)
    {
        Map<String, String> map = new HashMap<String, String>();
        map.put("sysId", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = this.sqlSession.selectOne("mail.SelectEventMailFullByEventId", map);
            if (!StringUtils.isEmpty(eventMail) && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
            	boolean isBodyHtml = false;
                if (!StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                    isBodyHtml = true;
                else
                    isBodyHtml = false;
                String mailTo = receiver;
                String subject = eventMail.getMailSubject();
                String message = eventMail.getMailTemplate();
                return SendMail(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml);
            }
            else
            {
                //if (_log.IsInfoEnabled)
                log.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }
        }
        catch (Exception e)
        {
        	e.printStackTrace();
            log.error("SendMailByEventIdAndReceiver error", e.getMessage());
        }
        return false;
    }
    
    public boolean SendMailByEventIdWithReceiver(String sysId, String eventId, String subject, String message, String fileName, ByteArrayInputStream attachments, String receiver)
    {
        Map<String, String> map = new HashMap<String, String>();
        map.put("sysId", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = this.sqlSession.selectOne(".ail.SelectEventMailByEventId", map);
            boolean isBodyHtml = false;
            if (!StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                isBodyHtml = true;
            else
                isBodyHtml = false;
            
            log.error("EventId[" + eventId + "] isBodyHtml=" + isBodyHtml + " eventMail.IsBodyHtml=" + eventMail.getIsBodyHtml());
            if (eventMail != null && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
                String mailTo = receiver;
                return SendMail(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml);
            }
            else
            {
                //if (_log.IsInfoEnabled)
                log.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }

        }
        catch (Exception e)
        {
        	e.printStackTrace();
            log.error("SendMailByEventIdWithReceiver error", e.getMessage());
        }
        return false;
    }
    
    public boolean SendMailByEventIdWithReceiverAndSender(String sysId, String eventId, String subject, String message, String fileName, ByteArrayInputStream attachments, String receiver, String sender)
    {
    	Map<String, String> map = new HashMap<String, String>();
        map.put("sysId", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = this.sqlSession.selectOne("mil.SelectEventMailByEventId", map);
            boolean isBodyHtml = false;
            if (!StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                isBodyHtml = true;
            else
                isBodyHtml = false;

            log.error("EventId[" + eventId + "] isBodyHtml=" + isBodyHtml + " eventMail.IsBodyHtml=" + eventMail.getIsBodyHtml());
            if (eventMail != null && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
                String mailTo = receiver;
                return SendMailWithSender(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml, sender);
            }
            else
            {
                //if (_log.IsInfoEnabled)
                log.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }

        }
        catch (Exception e)
        {
        	e.printStackTrace();
            log.error("SendMailByEventIdWithReceiverAndSender error", e.getMessage());
        }
        return false;
    }

    public boolean SendMailByEventIdTemplateWithReceiver(String sysId, String eventId, String subject, HashMap<String, Object> attrs, String fileName, ByteArrayInputStream attachments, String receiver)
    {
        Map<String, String> map = new HashMap<String, String>();
        map.put("sysId", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = this.sqlSession.selectOne("mail.SelectEventMailFullByEventId", map);
            if (eventMail != null && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
                List<MailInfo> mails = this.sqlSession.selectList("mail.SelectMailInfoByGroupId", eventMail.getMailGroupId());
                boolean isBodyHtml = false;
                if (!StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                    isBodyHtml = true;
                else
                    isBodyHtml = false;
                String mailTo = receiver;
                String message = TemplateHelper.RenderTemplateByContent(eventMail.getMailTemplate(), attrs);
                return SendMail(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml);
            }
            else
            {
                //if (_log.IsInfoEnabled)
                log.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }
        }
        catch (Exception e)
        {
        	e.printStackTrace();
            log.error("SendMailByEventIdTemplateWithReceiver error", e.getMessage());
        }
        return false;
    }
    
    public boolean SendMailByEventIdTemplateWithReceiverAndSender(String sysId, String eventId, String subject, HashMap<String, Object> attrs, String fileName, ByteArrayInputStream attachments, String receiver, String sender)
    {
        Map<String, String> map = new HashMap<String, String>();
        map.put("sysId", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = this.sqlSession.selectOne("mail.SelectEventMailFullByEventId", map);
            if (eventMail != null && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
                List<MailInfo> mails = this.sqlSession.selectList("mail.SelectMailInfoByGroupId", eventMail.getMailGroupId());
                boolean isBodyHtml = false;
                if (!StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                    isBodyHtml = true;
                else
                    isBodyHtml = false;
                String mailTo = receiver;
                String message = TemplateHelper.RenderTemplateByContent(eventMail.getMailTemplate(), attrs);
                return SendMailWithSender(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml, sender);
            }
            else
            {
                //if (_log.IsInfoEnabled)
                log.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }
        }
        catch (Exception e)
        {
            log.error("SendMailByEventIdTemplateWithReceiverAndSender error", e);
        }
        return false;
    }
    
    public boolean SendMailByEventIdAndReceiverAndSender(String sysId, String eventId, String fileName, ByteArrayInputStream attachments, String receiver, String sender)
    {
        Map<String, String> map = new HashMap<String, String>();
        map.put("sysId", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = this.sqlSession.selectOne("mail.SelectEventMailFullByEventId", map);
            if (eventMail != null && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
            	boolean isBodyHtml = false;
                if (!StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                    isBodyHtml = true;
                else
                    isBodyHtml = false;
                String mailTo = receiver;
                String subject = eventMail.getMailSubject();
                String message = eventMail.getMailTemplate();
                return SendMailWithSender(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml, sender);
            }
            else
            {
                //if (_log.IsInfoEnabled)
                log.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }
        }
        catch (Exception e)
        {
        	e.printStackTrace();
            log.error("SendMailByEventIdAndReceiverAndSender error", e.getMessage());
        }
        return false;
    }
    
    public boolean SendMailByEventIdAndSender(String sysId, String eventId, String fileName, ByteArrayInputStream attachments, String sender)
    {
        Map<String, String> map = new HashMap<String, String>();
        map.put("sysId", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = this.sqlSession.selectOne("mail.SelectEventMailFullByEventId", map);
            if (eventMail != null && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
                List<MailInfo> mails = this.sqlSession.selectList("Base.Mail.SelectMailInfoByGroupId", eventMail.getMailGroupId());
                boolean isBodyHtml = false;
                if (!StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                    isBodyHtml = true;
                else
                    isBodyHtml = false;
                if (mails != null && mails.size() > 0)
                {
                	String mailTo = "";
                    for (MailInfo mi : mails)
                    {
                        if (mi.getEmail() != null)
                        {
                            mailTo += mi.getEmail().contains("@") ? mi.getEmail() : mi.getEmail() + "@fubon.com";
                            mailTo += ";";
                        }
                    }
                    String subject = eventMail.getMailSubject();
                    String message = eventMail.getMailTemplate();
                    return SendMailWithSender(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml, sender);
                }
                else
                {
                    //if (_log.IsInfoEnabled)
                    log.error("EventId[" + eventId + "] 郵件群組[" + eventMail.getMailGroupId() + "]的郵件清單是空白.");
                    return false;
                }
            }
            else
            {
                //if (_log.IsInfoEnabled)
                log.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }
        }
        catch (Exception e)
        {
        	e.printStackTrace();
            log.error("SendMailByEventIdAndSender error", e.getMessage());
        }
        return false;
    }
    
    public boolean SendMailByEventIdTemplateWithSender(String sysId, String eventId, String subject, HashMap<String, Object> attrs, String fileName, ByteArrayInputStream attachments, String sender)
    {
        Map<String, String> map = new HashMap<String, String>();
        map.put("sysId", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = this.sqlSession.selectOne("mail.SelectEventMailFullByEventId", map);
            if (eventMail != null && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
                List<MailInfo> mails = this.sqlSession.selectList("mail.SelectMailInfoByGroupId", eventMail.getMailGroupId());
                boolean isBodyHtml = false;
                if (!StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                    isBodyHtml = true;
                else
                    isBodyHtml = false;

                if (mails != null && mails.size()> 0)
                {
                	String mailTo = "";
                    for (MailInfo mi : mails)
                    {
                        if (!StringUtils.isEmpty(mi.getEmail()))
                        {
                            mailTo += mi.getEmail().contains("@") ? mi.getEmail() : mi.getEmail() + "@fubon.com";
                            mailTo += ";";
                        }
                    }
                    if (subject == null)
                        subject = eventMail.getMailSubject();
                    String message = TemplateHelper.RenderTemplateByContent(eventMail.getMailTemplate(), attrs);
                    return SendMailWithSender(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml, sender);
                }
                else
                {
                    //if (_log.IsInfoEnabled)
                    log.error("EventId[" + eventId + "] 郵件群組[" + eventMail.getMailGroupId() + "]的郵件清單是空白.");
                    return false;
                }
            }
            else
            {
                //if (_log.IsInfoEnabled)
                log.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }
        }
        catch (Exception e)
        {
        	e.printStackTrace();
            log.error("SendMailByEventIdTemplateWithSender error", e.getMessage());
        }
        return false;
    }
    
    public boolean SendMailByEventIdWithSender(String sysId, String eventId, String subject, String message, String fileName, ByteArrayInputStream attachments, String sender)
    {
        Map<String, String> map = new HashMap<String, String>();
        map.put("sysId", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = this.sqlSession.selectOne("mail.SelectEventMailByEventId", map);
            List<MailInfo> mails = this.sqlSession.selectList("Base.Mail.SelectMailInfoByGroupId", eventMail.getMailGroupId());
            boolean isBodyHtml = false;
            if (!StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                isBodyHtml = true;
            else
                isBodyHtml = false;

            log.error("EventId[" + eventId + "] isBodyHtml=" + isBodyHtml + " eventMail.IsBodyHtml=" + eventMail.getIsBodyHtml());

            if (eventMail != null && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
                if (mails != null && mails.size() > 0)
                {
                	String mailTo = "";
                    for (MailInfo mi : mails)
                    {
                        if (!StringUtils.isEmpty(mi.getEmail()))
                        {
                            mailTo += mi.getEmail().contains("@") ? mi.getEmail() : mi.getEmail() + "@fubon.com";
                            mailTo += ";";
                        }
                    }
                    if (subject == null)
                        subject = eventMail.getMailSubject();
                    return SendMailWithSender(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml, sender);
                }
                else
                {
                    //if (_log.IsInfoEnabled)
                    log.error("EventId[" + eventId + "] 郵件群組[" + eventMail.getMailGroupId() + "]的郵件清單是空白.");
                    return false;
                }
            }
            else
            {
                //if (_log.IsInfoEnabled)
                log.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }

        }
        catch (Exception e)
        {
        	e.printStackTrace();
            log.error("SendMailByEventIdWithSender error", e.getMessage());
        }
        return false;
    }
    
    private boolean SendMail(String eventId, String mailTo, String subject, String message, String fileName, ByteArrayInputStream bis, boolean isBodyHtml)
    {
    	MailOutUtil mu = new MailOutUtil();
    	boolean ret = mu.sendMailUsingHtmlWithAttachement(mailTo, env.getProperty("mail.fromUser"), env.getProperty("mail.host"), fileName, bis, false, message, subject);
        String msg = "發送事件[" + eventId + "], 主題[" + subject + "], 訊息[" + message + "]";
        if (ret)
            log.info(msg + "完成");
        else
            log.info(msg + "失敗");
        return ret;
    }
    
    private boolean SendMailWithSender(String eventId, String mailTo, String subject, String message, String fileName, ByteArrayInputStream bis, boolean isBodyHtml, String sender)
    {
    	MailOutUtil mu = new MailOutUtil();
    	boolean ret = mu.sendMailUsingHtmlWithAttachement(mailTo, sender, env.getProperty("mail.host"), fileName, bis, false, message, subject);
    	String msg = "發送事件[" + eventId + "], 主題[" + subject + "], 訊息[" + message + "]";
        if (ret)
            log.info(msg + "完成");
        else
            log.info(msg + "失敗");
        return ret;
    }
}
