﻿using Common.Logging;
using Fubon.MailService.Server.Models.Base;
using Fubon.Mdp.Server.Helpers;
using Fubon.Utility.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.ServiceModel.Activation;

namespace Fubon.MailService.Server.Services
{
    public sealed class SequenceKeys
    {
        public const string DATA_FLOW = "DF";
        public const string MailGroup = "MG";
        public const string MailID = "MI";
        public const string DeptID = "DI";
    }

    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class MailService : IMailService
    {
        MailHelper mailHelper = new MailHelper();
        TaskQueueManager taskQueueManager = new TaskQueueManager();

        private static ILog _log = LogManager.GetLogger(typeof(MailService));

        public IList<MailGroup> GetMailGroupList(string groupId)
        {
            Dictionary<string, string> map = new Dictionary<string, string>();
            map.Add("groupId", groupId);
            IList<MailGroup> mailgroup = IBatisHelper.QueryForList<MailGroup>("Base.Mail.SelectAllMailGroup", map); 
            return mailgroup;
        }

        public IList<MailInfo> GetMailInfoByGroupId(string groupId)
        {
            IList<MailInfo> maillist = IBatisHelper.QueryForList<MailInfo>("Base.Mail.SelectMailInfoByGroupId", groupId);

            //TaskQueue taskeQueue = this.taskQueueManager.GetTaskQueue(sysID, () => CheckFailTask("id1"), 5);
            //Task<IList<MailInfo>> task = Task<IList<MailInfo>>.Factory.StartNew(() => IBatisHelper.QueryForList<MailInfo>("Base.Mail.SelectMailInfoByGroupId", groupId)));
            //taskeQueue.Queue(() => task);

            //maillist = task.Result;

            return maillist;
        }

        public IList<MailInfo> GetCanaddUserList(string groupId)
        {
            IList<MailInfo> userlist = IBatisHelper.QueryForList<MailInfo>("Base.Mail.SelectMailInfobyUse", groupId);
            return userlist;
        }


        /// <summary>
        ///   Mail Group
        /// </summary>
        public bool InsertMailGroup(MailGroup mailgroupdata)
        {
            try
            {
                _log.Error("InsertMailGroup GroupId=" + mailgroupdata.GroupId);
                if (mailgroupdata.GroupId == null)
                {
                    mailgroupdata.GroupId = IBatisHelper.Get<string>("App.Sys.SelectNextSeqNo_GROUP", SequenceKeys.MailGroup);
                }

                IBatisHelper.Insert("Base.Mail.InsMailGroup", mailgroupdata);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool UpdateMailGroup(MailGroup mailgroupdata)
        {
            int ret = IBatisHelper.Update<MailGroup>("Base.Mail.UpdMailGroup", mailgroupdata);
            return true;
        }

        public bool DeleteMailGroup(MailGroup mailgroupdata)
        {
            try
            {
                IBatisHelper.Delete("Base.Mail.DelMailGroup", mailgroupdata);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        ///   Mail Group Item
        /// </summary>
        public bool InsertMailGroupItem(MailInfo maildata)
        {
            try
            {
                IBatisHelper.Insert("Base.Mail.InsMailGroupItem", maildata);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool DeleteGroupItem(MailInfo maildata)
        {
            try
            {
                IBatisHelper.Delete("Base.Mail.DelMailGroupItem", maildata);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool DeleteGroupItemByMailId(MailInfo maildata)
        {
            try
            {
                IBatisHelper.Delete("Base.Mail.DelMailGroupItemByMailId", maildata);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }


        /// <summary>
        ///   Mail 
        /// </summary>
        public bool InsertMail(MailInfo mailuserdata)
        {
            if (mailuserdata.MailId == null)
            {
                mailuserdata.MailId = IBatisHelper.Get<string>("App.Sys.SelectNextSeqNo_MAIL", SequenceKeys.MailID);
            }

            try
            {
                IBatisHelper.Insert("Base.Mail.InsMailInfo", mailuserdata);
                _log.Error("InsertMail:" + mailuserdata.MailId + " " + mailuserdata.Email + " " + mailuserdata.UserName);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool UpdateMail(MailInfo mailuserdata)
        {
            int ret = IBatisHelper.Update<MailInfo>("Base.Mail.UpdMailInfo", mailuserdata);
            return true;
        }


        public bool DeleteMail(MailInfo mailuserdata)
        {
            try
            {
                IBatisHelper.Delete("Base.Mail.DelMailInfo", mailuserdata);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }


        //以下為event 

        public IList<EventMail> GetEventMailList(string eventGroupId)
        {
            IList<EventMail> eventList = IBatisHelper.QueryForList<EventMail>("Base.Mail.SelectEventMailByEventGroup", eventGroupId);
            return eventList;
        }

        public int UpdateEventMailList(IList<EventMail> eventMailList)
        {
            int okCount = 0;
            DateTime now = DateTime.Now;
            foreach (EventMail em in eventMailList)
            {
                em.UpdateDate = now;
                em.UpdateUserId = "SYSTEM";
                okCount += IBatisHelper.Update<EventMail>("Base.Mail.UpdateEventMail", em);
            }
            return okCount;
        }

        
        private async Task CheckFailTask(string id)
        {
            Console.WriteLine("CheckFailTask: {0}", id);
            await Task.Delay(1000);
            Console.WriteLine("CheckFailTaskSendEventMail: {0}", id);
        }

        public bool Sum(int i)
        {
            return true;
        }

        public bool SendEventMail(string sysId, string eventId, string attachments)
        {
            bool result;
            _log.Debug("Send mail by event id[" + eventId + "]");

            TaskQueue taskeQueue = this.taskQueueManager.GetTaskQueue(sysId, () => CheckFailTask(sysId), 5);
            Task<bool> task = Task<bool>.Factory.StartNew(() => MailHelper.SendMailByEventIdTemplate(sysId, eventId, null, new Dictionary<string, object>(), attachments));
            taskeQueue.Queue(() => task);
            
            result = task.Result;

            //var task = new Task<bool>(this.mailHelper.SendMailByEventIdTemplate();
            //var task = new Task(delegate { MailHelper.SendMailByEventIdTemplate(eventId, null, new Dictionary<string, object>()); });
            //var task1 = new Task(delegate { Sum(1); });
            //taskeQueue.Queue(() => task);
            //Task<bool>[] task = new Task<bool>[1];
            //taskeQueue.Queue(() => Task<bool> res = Task<bool>.Factory.StartNew(() => MailHelper.SendMailByEventIdTemplate(eventId, null, new Dictionary<string, object>())));
            //Task.WaitAny(task);
            //result = task[0].Result;
            //bool res = await task.Wait();

            
            //bool res = await result;
            //if (_log.IsDebugEnabled)
                
                //Task.Factory.StartNew(() => MailHelper.SendMailByEventIdTemplate(eventId, null, new Dictionary<string, object>()));

            //MailHelper.SendMailByEventIdTemplate(eventId, new Dictionary<string, object>());
            return result;
        }

        public bool SendEventMailWithContent(string sysId, string eventId, string subject, string message, string attachments)
        {
            bool result;
            //if (_log.IsDebugEnabled)
                _log.Debug("Send mail by event id[" + eventId + "]");

            //Task.Factory.StartNew(() => MailHelper.SendMailByEventId(eventId, subject, message));
                TaskQueue taskeQueue = this.taskQueueManager.GetTaskQueue(sysId, () => CheckFailTask(sysId), 5);
                Task<bool> task = Task<bool>.Factory.StartNew(() => MailHelper.SendMailByEventId(sysId, eventId, subject, message, attachments));
            taskeQueue.Queue(() => task);
            result = task.Result;
            return result;
        }

        public bool SendEventMailWithParameter(string sysId, string eventId, String[] keys, string[] values, string attachments)
        {
            bool result;
            //Task.Factory.StartNew(() => this.SendEventMailWithSubjectAndParameter(sysID, eventId, null, keys, values));
            TaskQueue taskeQueue = this.taskQueueManager.GetTaskQueue(sysId, () => CheckFailTask(sysId), 5);
            Task<bool> task = Task<bool>.Factory.StartNew(() => this.SendEventMailWithSubjectAndParameter(sysId, eventId, null, keys, values, attachments));
            taskeQueue.Queue(() => task);
            result = task.Result;
            return result;
        }

        public bool SendEventMailWithSubjectAndParameter(string sysId, string eventId, string subject, String[] keys, string[] values, string attachments)
        {
            bool result;
            //if (_log.IsDebugEnabled)
            _log.Debug("Send mail by event id[" + eventId + "]");

            if (keys.Count() != values.Count())
            {
                _log.Error("EventId[" + eventId + "] 參數key/values數目不相等.");
                return false;
            }

            Dictionary<string, object> paras = new System.Collections.Generic.Dictionary<string, object>();
            for (int i = 0; i < keys.Count(); i++)
            {
                paras[keys[i]] = values[i];
            }
            //Task.Factory.StartNew(() => MailHelper.SendMailByEventIdTemplate(eventId, subject, paras));
            TaskQueue taskeQueue = this.taskQueueManager.GetTaskQueue(sysId, () => CheckFailTask(sysId), 5);
            Task<bool> task = Task<bool>.Factory.StartNew(() => MailHelper.SendMailByEventIdTemplate(sysId, eventId, subject, paras, attachments));
            taskeQueue.Queue(() => task);
            result = task.Result;
            return result;
        }

        public bool SendEventMailWithReceiver(string sysId, string eventId, string attachments, string receiver)
        {
            bool result;
            //if (_log.IsDebugEnabled)
            _log.Debug("Send mail by event id[" + eventId + "]");

            //Task.Factory.StartNew(() => MailHelper.SendMailByEventId(eventId, subject, message));
            TaskQueue taskeQueue = this.taskQueueManager.GetTaskQueue(sysId, () => CheckFailTask(sysId), 5);
            Task<bool> task = Task<bool>.Factory.StartNew(() => MailHelper.SendMailByEventIdAndReceiver(sysId, eventId, attachments, receiver));
            taskeQueue.Queue(() => task);
            result = task.Result;
            return result;
        }

        public bool SendEventMailWithContentAndReceiver(string sysId, string eventId, string subject, string message, string attachments, string receiver)
        {
            bool result;
            //if (_log.IsDebugEnabled)
            _log.Debug("Send mail by event id[" + eventId + "]");

            //Task.Factory.StartNew(() => MailHelper.SendMailByEventId(eventId, subject, message));
            TaskQueue taskeQueue = this.taskQueueManager.GetTaskQueue(sysId, () => CheckFailTask(sysId), 5);
            Task<bool> task = Task<bool>.Factory.StartNew(() => MailHelper.SendMailByEventIdWithReceiver(sysId, eventId, subject, message, attachments, receiver));
            taskeQueue.Queue(() => task);
            result = task.Result;
            return result;
        }

        public bool SendEventMailWithParameterAndReceiver(string sysId, string eventId, String[] keys, string[] values, string attachments, string receiver)
        {
            bool result;
            //Task.Factory.StartNew(() => this.SendEventMailWithSubjectAndParameter(sysID, eventId, null, keys, values));
            TaskQueue taskeQueue = this.taskQueueManager.GetTaskQueue(sysId, () => CheckFailTask(sysId), 5);
            Task<bool> task = Task<bool>.Factory.StartNew(() => this.SendEventMailWithSubjectAndParameterAndReceiver(sysId, eventId, null, keys, values, attachments, receiver));
            taskeQueue.Queue(() => task);
            result = task.Result;
            return result;
        }

        public bool SendEventMailWithSubjectAndParameterAndReceiver(string sysId, string eventId, string subject, String[] keys, string[] values, string attachments, string receiver)
        {
            bool result;
            //if (_log.IsDebugEnabled)
            _log.Debug("Send mail by event id[" + eventId + "]");

            if (keys.Count() != values.Count())
            {
                _log.Error("EventId[" + eventId + "] 參數key/values數目不相等.");
                return false;
            }

            Dictionary<string, object> paras = new System.Collections.Generic.Dictionary<string, object>();
            for (int i = 0; i < keys.Count(); i++)
            {
                paras[keys[i]] = values[i];
            }
            //Task.Factory.StartNew(() => MailHelper.SendMailByEventIdTemplate(eventId, subject, paras));
            TaskQueue taskeQueue = this.taskQueueManager.GetTaskQueue(sysId, () => CheckFailTask(sysId), 5);
            Task<bool> task = Task<bool>.Factory.StartNew(() => MailHelper.SendMailByEventIdTemplateWithReceiver(sysId, eventId, subject, paras, attachments, receiver));
            taskeQueue.Queue(() => task);
            result = task.Result;
            return result;
        }

        public bool SendEventMailWithReceiverAndSender(string sysId, string eventId, string attachments, string receiver, string sender)
        {
            bool result;
            //if (_log.IsDebugEnabled)
            _log.Debug("Send mail by event id[" + eventId + "]");

            //Task.Factory.StartNew(() => MailHelper.SendMailByEventId(eventId, subject, message));
            TaskQueue taskeQueue = this.taskQueueManager.GetTaskQueue(sysId, () => CheckFailTask(sysId), 5);
            Task<bool> task = Task<bool>.Factory.StartNew(() => MailHelper.SendMailByEventIdAndReceiverAndSender(sysId, eventId, attachments, receiver, sender));
            taskeQueue.Queue(() => task);
            result = task.Result;
            return result;
        }

        public bool SendEventMailWithContentAndReceiverAndSender(string sysId, string eventId, string subject, string message, string attachments, string receiver, string sender)
        {
            bool result;
            //if (_log.IsDebugEnabled)
            _log.Debug("Send mail by event id[" + eventId + "]");

            //Task.Factory.StartNew(() => MailHelper.SendMailByEventId(eventId, subject, message));
            TaskQueue taskeQueue = this.taskQueueManager.GetTaskQueue(sysId, () => CheckFailTask(sysId), 5);
            Task<bool> task = Task<bool>.Factory.StartNew(() => MailHelper.SendMailByEventIdWithReceiverAndSender(sysId, eventId, subject, message, attachments, receiver, sender));
            taskeQueue.Queue(() => task);
            result = task.Result;
            return result;
        }

        public bool SendEventMailWithContentAndReceiverAndSender(string sysId, string eventId, String[] keys, string[] values, string attachments, string receiver, string sender)
        {
            bool result;
            //Task.Factory.StartNew(() => this.SendEventMailWithSubjectAndParameter(sysID, eventId, null, keys, values));
            TaskQueue taskeQueue = this.taskQueueManager.GetTaskQueue(sysId, () => CheckFailTask(sysId), 5);
            Task<bool> task = Task<bool>.Factory.StartNew(() => this.SendEventMailWithSubjectAndParameterAndReceiverAndSender(sysId, eventId, null, keys, values, attachments, receiver, sender));
            taskeQueue.Queue(() => task);
            result = task.Result;
            return result;
        }

        public bool SendEventMailWithSubjectAndParameterAndReceiverAndSender(string sysId, string eventId, string subject, String[] keys, string[] values, string attachments, string receiver, string sender)
        {
            bool result;
            //if (_log.IsDebugEnabled)
            _log.Debug("Send mail by event id[" + eventId + "]");

            if (keys.Count() != values.Count())
            {
                _log.Error("EventId[" + eventId + "] 參數key/values數目不相等.");
                return false;
            }

            Dictionary<string, object> paras = new System.Collections.Generic.Dictionary<string, object>();
            for (int i = 0; i < keys.Count(); i++)
            {
                paras[keys[i]] = values[i];
            }
            //Task.Factory.StartNew(() => MailHelper.SendMailByEventIdTemplate(eventId, subject, paras));
            TaskQueue taskeQueue = this.taskQueueManager.GetTaskQueue(sysId, () => CheckFailTask(sysId), 5);
            Task<bool> task = Task<bool>.Factory.StartNew(() => MailHelper.SendMailByEventIdTemplateWithReceiverAndSender(sysId, eventId, subject, paras, attachments, receiver, sender));
            taskeQueue.Queue(() => task);
            result = task.Result;
            return result;
        }

        public bool SendEventMailWithParameterAndReceiverAndSender(string sysId, string eventId, String[] keys, string[] values, string attachments, string receiver, string sender)
        {
            bool result;
            //Task.Factory.StartNew(() => this.SendEventMailWithSubjectAndParameter(sysID, eventId, null, keys, values));
            TaskQueue taskeQueue = this.taskQueueManager.GetTaskQueue(sysId, () => CheckFailTask(sysId), 5);
            Task<bool> task = Task<bool>.Factory.StartNew(() => this.SendEventMailWithSubjectAndParameterAndReceiverAndSender(sysId, eventId, null, keys, values, attachments, receiver, sender));
            taskeQueue.Queue(() => task);
            result = task.Result;
            return result;
        }

        public bool SendEventMailWithSender(string sysId, string eventId, string attachments, string sender)
        {
            bool result;
            //if (_log.IsDebugEnabled)
            _log.Debug("Send mail by event id[" + eventId + "]");

            //Task.Factory.StartNew(() => MailHelper.SendMailByEventId(eventId, subject, message));
            TaskQueue taskeQueue = this.taskQueueManager.GetTaskQueue(sysId, () => CheckFailTask(sysId), 5);
            //Task<bool> task = Task<bool>.Factory.StartNew(() => MailHelper.SendMailByEventIdAndReceiverAndSender(sysId, eventId, attachments, receiver, sender));            
            Task<bool> task = Task<bool>.Factory.StartNew(() => MailHelper.SendMailByEventIdTemplateWithSender(sysId, eventId, null, new Dictionary<string, object>(), attachments, sender));
            taskeQueue.Queue(() => task);
            result = task.Result;
            return result;
        }

        public bool SendEventMailWithContentAndSender(string sysId, string eventId, string subject, string message, string attachments, string sender)
        {
            bool result;
            //if (_log.IsDebugEnabled)
            _log.Debug("Send mail by event id[" + eventId + "]");

            //Task.Factory.StartNew(() => MailHelper.SendMailByEventId(eventId, subject, message));
            TaskQueue taskeQueue = this.taskQueueManager.GetTaskQueue(sysId, () => CheckFailTask(sysId), 5);
            Task<bool> task = Task<bool>.Factory.StartNew(() => MailHelper.SendMailByEventIdWithSender(sysId, eventId, subject, message, attachments, sender));
            taskeQueue.Queue(() => task);
            result = task.Result;
            return result;
        }

        public bool SendEventMailWithContentAndSender(string sysId, string eventId, String[] keys, string[] values, string attachments, string sender)
        {
            bool result;
            //Task.Factory.StartNew(() => this.SendEventMailWithSubjectAndParameter(sysID, eventId, null, keys, values));
            TaskQueue taskeQueue = this.taskQueueManager.GetTaskQueue(sysId, () => CheckFailTask(sysId), 5);
            Task<bool> task = Task<bool>.Factory.StartNew(() => this.SendEventMailWithSubjectAndParameterAndSender(sysId, eventId, null, keys, values, attachments, sender));
            taskeQueue.Queue(() => task);
            result = task.Result;
            return result;
        }

        public bool SendEventMailWithSubjectAndParameterAndSender(string sysId, string eventId, string subject, String[] keys, string[] values, string attachments, string sender)
        {
            bool result;
            //if (_log.IsDebugEnabled)
            _log.Debug("Send mail by event id[" + eventId + "]");

            if (keys.Count() != values.Count())
            {
                _log.Error("EventId[" + eventId + "] 參數key/values數目不相等.");
                return false;
            }

            Dictionary<string, object> paras = new System.Collections.Generic.Dictionary<string, object>();
            for (int i = 0; i < keys.Count(); i++)
            {
                paras[keys[i]] = values[i];
            }
            //Task.Factory.StartNew(() => MailHelper.SendMailByEventIdTemplate(eventId, subject, paras));
            TaskQueue taskeQueue = this.taskQueueManager.GetTaskQueue(sysId, () => CheckFailTask(sysId), 5);
            Task<bool> task = Task<bool>.Factory.StartNew(() => MailHelper.SendMailByEventIdTemplateWithSender(sysId, eventId, subject, paras, attachments, sender));
            taskeQueue.Queue(() => task);
            result = task.Result;
            return result;
        }

        public bool SendEventMailWithParameterAndSender(string sysId, string eventId, String[] keys, string[] values, string attachments, string sender)
        {
            bool result;
            //Task.Factory.StartNew(() => this.SendEventMailWithSubjectAndParameter(sysID, eventId, null, keys, values));
            TaskQueue taskeQueue = this.taskQueueManager.GetTaskQueue(sysId, () => CheckFailTask(sysId), 5);
            Task<bool> task = Task<bool>.Factory.StartNew(() => this.SendEventMailWithSubjectAndParameterAndSender(sysId, eventId, null, keys, values, attachments, sender));
            taskeQueue.Queue(() => task);
            result = task.Result;
            return result;
        }
    }
}
