﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using IBatisNet.DataMapper;
using IBatisNet.DataMapper.MappedStatements;
using IBatisNet.Common;
using Fubon.MailService.Server.Models;
using Microsoft.Win32; //Registry
using System.Security.Cryptography;
using System.IO;
using log4net;
using System.Collections.Specialized;
using IBatisNet.DataMapper.Configuration;
using System.Configuration;

/*
* 修改人員  修改日期    調整內容
* ====================================================
* 黃教熙    2017/03/16  調整MDP Config取得帳密改為由登錄檔取得
* 

*/

namespace Fubon.Mdp.Server.Helpers
{
    public sealed class IBatisHelper
    {
        private static readonly ILog _log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private static ISqlMapper _mapper;
        static IBatisHelper()
        {
            try
            {
                DomSqlMapBuilder builder = new DomSqlMapBuilder();

                //由web.config取得資料連線資訊
                ConnectionStringSettings dbConnStr = ConfigurationManager.ConnectionStrings["MailService"];

                //把連線資訊以參數方式代入SqlMap.config中
                NameValueCollection properties = new NameValueCollection();
                properties.Add("MailService", dbConnStr.ConnectionString);
                builder.Properties = properties;

                // 進行SqlMap的初始化
                _mapper = builder.Configure("SqlMap.config");
                _mapper.SessionStore = new IBatisNet.DataMapper.SessionStore.HybridWebThreadSessionStore(_mapper.Id);
            }
            catch (
                Exception e)
            {
                _log.Error("Initial iBatis Error.", e);
            }
        }

        public static object Insert<T>(string statementName, T t)
        {
            if (_mapper != null)
            {
                return _mapper.Insert(statementName, t);
            }
            return null;
        }

        public static int Update<T>(string statementName, T t)
        {
            if (_mapper != null)
            {
                return _mapper.Update(statementName, t);
            }
            return 0;
        }

        public static int Delete(string statementName, int primaryKeyId)
        {
            if (_mapper != null)
            {
                return _mapper.Delete(statementName, primaryKeyId);
            }
            return 0;
        }
        public static int Delete(string statementName, object param)
        {
            if (_mapper != null)
            {
                return _mapper.Delete(statementName, param);
            }
            return 0;
        }

        public static T Get<T>(string statementName, int primaryKeyId) where T : class
        {
            if (_mapper != null)
            {
                return _mapper.QueryForObject<T>(statementName, primaryKeyId);
            }
            return null;
        }
        public static T Get<T>(string statementName, string primaryKeyId) where T : class
        {
            if (_mapper != null)
            {
                return _mapper.QueryForObject<T>(statementName, primaryKeyId);
            }
            return null;
        }

        public static T Get<T>(string statementName, Object objects) where T : class
        {
            if (_mapper != null)
            {
                return _mapper.QueryForObject<T>(statementName, objects);
            }
            return null;
        }

        public static IList<T> QueryForList<T>(string statementName, object parameterObject = null)
        {
            if (_mapper != null)
            {
                return _mapper.QueryForList<T>(statementName, parameterObject);
            }
            return null;
        }

        public static Object QueryForObject(string statementName, object parameterObject = null)
        {
            if (_mapper != null)
            {
                return _mapper.QueryForObject(statementName, parameterObject);
            }
            return null;
        }

        public static PaginatedResult<T> SearchPaggingResult<T>(ISqlMapper sqlMap, string statementId, Dictionary<string, string> parameters, int pageSize, int startIndex)
        {

            if (sqlMap != null)
            {
                using (IDalSession session = sqlMap.OpenConnection())
                {
                    int totalCount = sqlMap.QueryForObject<int>(statementId + "#", parameters);
                    int page = 1;
                    if (totalCount > startIndex)
                    {
                        page = Convert.ToInt32(Math.Ceiling(((double)startIndex) / pageSize));
                    }
                    else
                    {
                        page = Convert.ToInt32(Math.Ceiling(((double)totalCount) / pageSize));
                    }
                    if (startIndex % pageSize == 0)
                    {
                        page = page + 1;
                    }
                    int totalPage = Convert.ToInt32(Math.Ceiling(((double)totalCount) / pageSize));

                    PaginatedList pl = sqlMap.QueryForPaginatedList(statementId, parameters, pageSize);
                    pl.GotoPage(page - 1);

                    PaginatedResult<T> result = new PaginatedResult<T>();
                    result.Count = pl.Count;
                    result.Page = page;
                    result.PageSize = pageSize;
                    result.TotalCount = totalCount;
                    result.TotalPage = totalPage;
                    List<T> deals = new List<T>();
                    IEnumerator er = pl.GetEnumerator();
                    while (er.MoveNext())
                    {
                        deals.Add((T)er.Current);
                    }
                    result.Items = deals;
                    return result;
                }
            }
            return null;
        }
        public static PaginatedResult<T> SearchPaggingResult<T>(string statementId, Dictionary<string, string> parameters, int pageSize, int startIndex)
        {
            return SearchPaggingResult<T>(_mapper, statementId, parameters, pageSize, startIndex);
        }

        public static ISqlMapSession BeginTransaction()
        {
            ISqlMapSession session = _mapper.BeginTransaction();
            return session;
        }

        public static ISqlMapper Mapper
        {
            get
            {
                return _mapper;
            }
        }
    }
}
