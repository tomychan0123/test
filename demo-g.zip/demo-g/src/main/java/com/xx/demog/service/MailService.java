package com.xx.demog.service;

import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xx.demog.dao.mail.MailRepository;
import com.xx.demog.domain.EventMail;
import com.xx.demog.domain.MailGroup;
import com.xx.demog.domain.MailInfo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(tags = "MailService")
@Service
public class MailService {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
    private MailRepository mailRepository;
	@ApiOperation(value = "取得群組Mail List", notes = "取得群組Mail List")
	public List <MailGroup>GetMailGroupList(String groupId) {
		return mailRepository.GetMailGroupList(groupId);
	}
	@ApiOperation(value = "取得該id的Mail List", notes = "取得該id的Mail List")
	public List<MailInfo> selectMailInfoById(long id) {
		return mailRepository.selectMailInfoById(id);
	}
	@ApiOperation(value = "取得該id的Mail List", notes = "取得該id的Mail List")
	public List<MailInfo> GetCanaddUserList(String groupId) {
		return mailRepository.GetCanaddUserList(groupId);
	}
	@ApiOperation(value = "查可加入的人員", notes = "查可加入的人員")
	public boolean InsertMailGroup(MailGroup mailgroupdata) {
		return mailRepository.InsertMailGroup(mailgroupdata);
	}
	@ApiOperation(value = "更新MailGroup", notes = "更新MailGroup")
	public boolean UpdateMailGroup(MailGroup mailgroupdata) {
		return mailRepository.UpdateMailGroup(mailgroupdata);
	}
	@ApiOperation(value = "刪除MailGroup", notes = "刪除MailGroup")
	public boolean DeleteMailGroup(MailGroup mailgroupdata) {
		return mailRepository.DeleteMailGroup(mailgroupdata);
	}
	@ApiOperation(value = "新增MailGroup資料", notes = "新增MailGroup資料")
	public boolean InsertMailGroupItem(MailInfo maildata) {
		return mailRepository.InsertMailGroupItem(maildata);
	}
	@ApiOperation(value = "刪除MailGroup資料", notes = "刪除MailGroup資料")
	public boolean DeleteGroupItem(MailInfo maildata) {
		return mailRepository.DeleteGroupItem(maildata);
	}
	@ApiOperation(value = "依MailId刪除MailGroup資料", notes = "依MailId刪除MailGroup資料")
	public boolean DeleteGroupItemByMailId(MailInfo maildata) {
		return mailRepository.DeleteGroupItemByMailId(maildata);
	}
	@ApiOperation(value = "新增Mail資料", notes = "新增Mail資料")
	public boolean InsertMail(MailInfo mailuserdata) {
		return mailRepository.InsertMail(mailuserdata);
	}
	@ApiOperation(value = "修改Mail資料", notes = "修改Mail資料")
	public boolean UpdateMail(MailInfo mailuserdata) {
		return mailRepository.UpdateMail(mailuserdata);
	}
	@ApiOperation(value = "刪除Mail資料", notes = "刪除Mail資料")
	public boolean DeleteMail(MailInfo mailuserdata) {
		return mailRepository.DeleteMail(mailuserdata);
	}
	@ApiOperation(value = "依eventGroupId取得EventMail資料", notes = "依eventGroupId取得EventMail資料")
	public List<EventMail> GetEventMailList(String eventGroupId) {
		return mailRepository.GetEventMailList(eventGroupId);
	}
	@ApiOperation(value = "依eventMailList修改EventMail資料", notes = "依eventMailList修改EventMail資料")
	public int UpdateEventMailList(List<EventMail> eventMailList) {
		return mailRepository.UpdateEventMailList(eventMailList);
	}
	@ApiOperation(value = "依eventId傳送Mail", notes = "依eventId傳送Mail")
	public boolean SendMailByEventId(String sysId, String eventId, String subject, String message, String fileName, ByteArrayInputStream attachments) {
		return mailRepository.SendMailByEventId(sysId, eventId, subject, message, fileName, attachments);
	}
	@ApiOperation(value = "依eventIdTemplate傳送Mail", notes = "依eventIdTemplate傳送Mail")
	public boolean SendMailByEventIdTemplate(String sysId, String eventId, String subject, HashMap<String, Object> attrs, String fileName, ByteArrayInputStream attachments) {
		return mailRepository.SendMailByEventIdTemplate(sysId, eventId, subject, attrs, fileName, attachments);
	}
	@ApiOperation(value = "依eventId與指定收件人傳送Mail", notes = "依eventId與指定收件人傳送Mail")
	public boolean SendMailByEventIdAndReceiver(String sysId, String eventId, String fileName, ByteArrayInputStream attachments, String receiver) {
		return mailRepository.SendMailByEventIdAndReceiver(sysId, eventId, fileName, attachments, receiver);
	}
	@ApiOperation(value = "依eventId與指定收件人/送件人傳送Mail", notes = "依eventId與指定收件人/送件人傳送Mail")
	public boolean SendMailByEventIdWithReceiverAndSender(String sysId, String eventId, String subject, String message, String fileName, ByteArrayInputStream attachments, String receiver, String sender) {
		return mailRepository.SendMailByEventIdWithReceiverAndSender(sysId, eventId, subject, message, fileName, attachments, receiver, sender);
	}
	@ApiOperation(value = "依eventIdTemplate與指定收件人傳送Mail", notes = "依eventIdTemplate與指定收件人傳送Mail")
	public boolean SendMailByEventIdTemplateWithReceiver(String sysId, String eventId, String subject, HashMap<String, Object> attrs, String fileName, ByteArrayInputStream attachments, String receiver) {
		return mailRepository.SendMailByEventIdTemplateWithReceiver(sysId, eventId, subject, attrs, fileName, attachments, receiver);
	}
	@ApiOperation(value = "依eventIdTemplate與指定收件人/送件人傳送Mail", notes = "依eventIdTemplate與指定收件人/送件人傳送Mail")
	public boolean SendMailByEventIdTemplateWithReceiverAndSender(String sysId, String eventId, String subject, HashMap<String, Object> attrs, String fileName, ByteArrayInputStream attachments, String receiver, String sender) {
		return mailRepository.SendMailByEventIdTemplateWithReceiverAndSender(sysId, eventId, subject, attrs, fileName, attachments, receiver, sender);
	}
	@ApiOperation(value = "依eventId與指定收件人/送件人傳送Mail", notes = "依eventId與指定收件人/送件人傳送Mail")
	public boolean SendMailByEventIdAndReceiverAndSender(String sysId, String eventId, String fileName, ByteArrayInputStream attachments, String receiver, String sender) {
		return mailRepository.SendMailByEventIdAndReceiverAndSender(sysId, eventId, fileName, attachments, receiver, sender);
	}
	@ApiOperation(value = "依eventId與指定送件人傳送Mail", notes = "依eventId與指定送件人傳送Mail")
	public boolean SendMailByEventIdAndSender(String sysId, String eventId, String fileName, ByteArrayInputStream attachments, String sender) {
		return mailRepository.SendMailByEventIdAndSender(sysId, eventId, fileName, attachments, sender);
	}
	@ApiOperation(value = "依eventIdTemplate與指定送件人傳送Mail", notes = "依eventIdTemplate與指定送件人傳送Mail")
	public boolean SendMailByEventIdTemplateWithSender(String sysId, String eventId, String subject, HashMap<String, Object> attrs, String fileName, ByteArrayInputStream attachments, String sender) {
		return mailRepository.SendMailByEventIdTemplateWithSender(sysId, eventId, subject, attrs, fileName, attachments, sender);
	}
	@ApiOperation(value = "依eventId與指定送件人傳送Mail", notes = "依eventId與指定送件人傳送Mail")
	public boolean SendMailByEventIdWithSender(String sysId, String eventId, String subject, String message, String fileName, ByteArrayInputStream attachments, String sender) {
		return mailRepository.SendMailByEventIdWithSender(sysId, eventId, subject, message, fileName, attachments, sender);
	}	
}
