﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FileExpApp.Models
{
    public class FileContent
    {
        public string id { get; set; }

        public string folderPath { get; set; }

        public string filename { get; set; }

        public string filenameX { get; set; }

        public string filesize { get; set; }

        public string filedate { get; set; }

        public bool is_dir { get; set; }
    }
}