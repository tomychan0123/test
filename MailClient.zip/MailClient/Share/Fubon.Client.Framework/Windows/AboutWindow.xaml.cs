﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Fubon.Client.Framework.Windows
{
    /// <summary>
    /// AboutWindow.xaml 的互動邏輯
    /// </summary>
    public partial class AboutWindow : Window
    {
        public bool HasLogFile
        {
            get;
            set;
        }
        public AboutWindow()
        {
            InitializeComponent();
            if (File.Exists(AppService.Instance.LogFile))
                HasLogFile = true;
            else
                HasLogFile = false;
            
            this.DataContext = this;
            Version_Shown();
        }

        public string Version
        {
            get;
            set;
        }

        public string AppName
        {
            get;
            set;
        }

        private void OnOKClicked(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Version_Shown()
        { 
            // Current OS Information
            richTextBox1.Document.Blocks.Clear();
            string text = "";
            text = text + "Machine Name： " + Environment.MachineName + Environment.NewLine;

            text = text + ".NET Framework Environment Version： " + Environment.Version + Environment.NewLine;
            text = text + VersionNetFramework.GetVersionDicription() + Environment.NewLine;
            /*
            text = text + ".NET Framework Information From Registry：" + Environment.NewLine;
            text = text + VersionNetFramework.GetVersionFromRegistry() + Environment.NewLine;

            text = text + ".NET Framework 4.5 or later Information From Registry：" + Environment.NewLine;
            text = text + VersionNetFramework.Get45or451FromRegistry();
            */
            richTextBox1.Document.Blocks.Add(new Paragraph(new Run(text)));
        }

 

        private void Expander_Expanded(object sender, RoutedEventArgs e)
        {
            //Height="300" Width="450" 
            this.Height = 450;

        }

        private void Expander_Collapsed(object sender, RoutedEventArgs e)
        {
            this.Height = 300;
        }
        
        private void BtnOpenLogClicked(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Process.Start(AppService.Instance.LogFile);
        }
    }
}
