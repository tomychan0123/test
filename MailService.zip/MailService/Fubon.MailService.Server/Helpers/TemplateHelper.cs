﻿using Antlr3.ST;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fubon.Mdp.Server.Helpers
{
    public class TemplateHelper
    {
        public static string RenderTemplate(string templateName, string attrName, object attrObj)
        {

            StringTemplate st = GetStringTemplate(templateName);
            st.SetAttribute(attrName, attrObj);

            string result = st.ToString();
            return result;
        }

        public static string RenderTemplate(string templateName, Dictionary<string, object> objects)
        {
            StringTemplate st = GetStringTemplate(templateName);
            foreach (string key in objects.Keys)
            {
                st.SetAttribute(key, objects[key]);
            }

            string result = st.ToString();
            return result;
        }

        //ex: templateContent: "Hello $paraName"
        public static string RenderTemplateByContent(string templateContent, Dictionary<string, object> objects)
        {
            StringTemplate st = new StringTemplate(templateContent);
            foreach (string key in objects.Keys)
            {
                st.SetAttribute(key, objects[key]);
            }

            string result = st.ToString();
            return result;
        }
        
        public static StringTemplate GetStringTemplate(string templateName)
        {
            StringTemplateGroup stg = new StringTemplateGroup("default");

            StringTemplate st = stg.GetInstanceOf("Fubon/Mdp/Server/Templates/" + templateName);
            return st;
        }
    }
}