package com.xx.demog.book;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;


@Api(tags = "BookService")
@Service
public class BookService {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private BookRepository bookRepository;
    
    @ApiOperation(value = "取得書本", notes = "列出所有書本")
    public List<Book> getAll() {
    	return (List<Book>) bookRepository.findAll();
    }
    
    @ApiOperation(value = "取得某作者的書", notes = "列出作者所有書本")
    public List<Book> getAllByAuthor(String author) {
    	return bookRepository.findAllByAuthor(author);
    }
    
    @ApiOperation(value = "新增書本", notes = "新增書本的內容")
	public BookDto create(@ApiParam(required = true, value = "書本內容")BookDto bookDto) {
        Book book = new Book();
        book.setBookid(bookDto.getBookid());
        book.setName(bookDto.getName());
        book.setAuthor(bookDto.getAuthor());
        book = bookRepository.save(book);
        bookDto.setBookid(book.getBookid());
        return bookDto;
	}
	
    @ApiOperation(value = "取得書本內容", notes = "取得書本內容")
	public BookDto getOne(@ApiParam(required = true, name = "bookid", value = "書本ID")Integer bookid) {
        Book book = bookRepository.findOne(bookid);
        BookDto bookDto = new BookDto();
        bookDto.setBookid(book.getBookid());
        bookDto.setName(book.getName());
        bookDto.setAuthor(book.getAuthor());
        return bookDto;
	}
    
    public List<Book> findBooks(@ApiParam(required=true, name="page", value="頁數") @RequestParam(value="page", defaultValue="0") Integer page,
    							@ApiParam(required=true, name="size", value="筆數") @RequestParam(value="size", defaultValue="5") Integer size) {
    	Pageable pageable = new PageRequest(page, size, null);
    	logger.info("=================================");
    	logger.info("{}", page, size);
    	logger.info("================***************=================");
    	return bookRepository.findAll(pageable).getContent();
    }
    
    public Page<Book> findPageBooks(@ApiParam(required=true, name="pageable", value="分頁內容") Pageable pageable) {
    	return bookRepository.findAll(pageable);
    }

}
