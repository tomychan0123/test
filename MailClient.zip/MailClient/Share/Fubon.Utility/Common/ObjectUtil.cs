﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Web.Script.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.IO;
using Newtonsoft.Json.Linq;

namespace Fubon.Utility.Common
{
    public class ObjectUtil
    {
        public static void Update(Dictionary<string, object> src, object destObj)
        {
            foreach (KeyValuePair<string, object> item in src)
            {
                //Type type = item.Value.GetType().GetProperty(

                if (destObj.GetType().GetField(item.Key) != null)
                {
                    destObj.GetType().GetField(item.Key).SetValue(destObj, item.Value);
                }
                else
                    if (destObj.GetType().GetProperty(item.Key) != null)
                    {
                        destObj.GetType().GetProperty(item.Key).SetValue(destObj, item.Value, null);
                    }
            }
        }

        public static void Update(object srcObj, object destObj)
        {
            FieldInfo[] fieldInfos = srcObj.GetType().GetFields();
            foreach (FieldInfo fieldInfo in fieldInfos)
            {
                if (destObj.GetType().GetField(fieldInfo.Name) != null)
                {
                    object value = srcObj.GetType().GetField(fieldInfo.Name).GetValue(srcObj);
                    if (destObj.GetType().GetField(fieldInfo.Name) != null)
                    {
                        try
                        {
                            destObj.GetType().GetField(fieldInfo.Name).SetValue(destObj, value);
                        }
                        catch
                        {
                        }
                    }
                }
            }

            PropertyInfo[] propertyInfos = srcObj.GetType().GetProperties();
            foreach (PropertyInfo propertyInfo in propertyInfos)
            {
                if (destObj.GetType().GetProperty(propertyInfo.Name) != null)
                {
                    object value = srcObj.GetType().GetProperty(propertyInfo.Name).GetValue(srcObj, null);
                    if (destObj.GetType().GetProperty(propertyInfo.Name) != null)
                    {
                        try
                        {
                            destObj.GetType().GetProperty(propertyInfo.Name).SetValue(destObj, value, null);
                        }
                        catch
                        {
                        }
                    }
                }
            }

        }

        public static Dictionary<string, object> GetDictionary(object srcObj)
        {
            Dictionary<string, object> dict = new Dictionary<string, object>();

            FieldInfo[] fieldInfos = srcObj.GetType().GetFields();
            foreach (FieldInfo fieldInfo in fieldInfos)
            {
                if (srcObj.GetType().GetField(fieldInfo.Name) != null)
                {
                    object value = srcObj.GetType().GetField(fieldInfo.Name).GetValue(srcObj);
                    if (srcObj.GetType().GetField(fieldInfo.Name) != null)
                    {
                        try
                        {
                            dict.Add(fieldInfo.Name, value);
                        }
                        catch
                        {
                        }
                    }
                }
            }

            PropertyInfo[] propertyInfos = srcObj.GetType().GetProperties();
            foreach (PropertyInfo propertyInfo in propertyInfos)
            {
                if (srcObj.GetType().GetProperty(propertyInfo.Name) != null)
                {
                    object value = srcObj.GetType().GetProperty(propertyInfo.Name).GetValue(srcObj, null);
                    if (srcObj.GetType().GetProperty(propertyInfo.Name) != null)
                    {
                        try
                        {
                            dict.Add(propertyInfo.Name, value);
                        }
                        catch
                        {
                        }
                    }
                }
            }

            return dict;
        }

        public static string ToJson(object obj)
        {
            JsonSerializerSettings st = new JsonSerializerSettings();
            st.Converters.Add(new StringEnumConverter { CamelCaseText = true });
            var json = JsonConvert.SerializeObject(obj, Newtonsoft.Json.Formatting.Indented, st);
            return json;
        }

        public static void ToJsonFile(object obj, string fileName)
        {
            string json = ToJson(obj);
            IOUtil.WriteToFile(json, fileName);
        }

        public static T FromJson<T>(string json)
        {
            object obj = new JavaScriptSerializer().Deserialize(json, typeof(T));
            return (T)obj;
        }

        public static T FromJsonFile<T>(string fileName)
        {
            string json = IOUtil.ReadFromFile(fileName);
            return FromJson<T>(json);
        }

        public static T FromJsonResource<T>(string resourceName)
        {
            string json = IOUtil.ReadFromResource(resourceName);
            return FromJson<T>(json);
        }
        public static T FromJsonResource<T>(string resourceName, string dllName)
        {
            string json = IOUtil.ReadFromResource(resourceName, dllName);
            return FromJson<T>(json);
        }

        public static T Clone<T>(object obj)
        {
            return (T)FromJson<T>(ToJson(obj));
        }


        public static string FindTokens(string jsonString, string parseString)
        {

            JObject jObject = JObject.Parse(jsonString);
            string json = jObject.SelectToken(parseString).ToString();
            return json;
        }
    }
}
