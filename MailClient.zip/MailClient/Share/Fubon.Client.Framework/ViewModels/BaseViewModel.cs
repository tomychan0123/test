﻿using Fubon.Client.Framework.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Fubon.Client.Framework.ViewModels
{
    public abstract class BaseViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected void RaisePropertyChanged(string strProperty)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(strProperty));
        }
        #region Virtual Functions
        virtual public void OnViewLoaded() {}
        public Function AppFunction { get; set; }
        #endregion
    }
}
