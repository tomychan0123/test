package com.xx.demog.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MailOutUtil {
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	public boolean sendMail(String to, String from, String host, String filename, 
			boolean debug, String msgText, String subject) {
		  boolean result = false; 
	      // Get system properties
	      Properties properties = System.getProperties();

	      // Setup mail server
	      properties.setProperty("mail.smtp.host", host);

	      // Get the default Session object.
	      //Session session = Session.getDefaultInstance(properties);
	      Session session = Session.getInstance(properties, null);
			session.setDebug(debug);

	      try {
	         // Create a default MimeMessage object.
	         MimeMessage message = new MimeMessage(session);

	         // Set From: header field of the header.
	         message.setFrom(new InternetAddress(from));

	         // Set To: header field of the header.
	         //message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
	         if (to.contains(","))
	        	 	message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(to));
			    else {
			    	InternetAddress[] address = {new InternetAddress(to)};
			    	message.setRecipients(Message.RecipientType.TO, address);
			    }	

	         // Set Subject: header field
	         message.setSubject(subject);

	         // Now set the actual message
	         //message.setText(msgText);

	         // Send message
	         //Transport.send(message);
	         // create and fill the first message part
			 MimeBodyPart mbp1 = new MimeBodyPart();
			 mbp1.setText(msgText);
			 // 設定郵件內容的型態為 text/plain 或 text/html
	  		 mbp1.setContent(msgText, "text/html" + ";charset=MS950");
	  			
			 // create the second message part
			 MimeBodyPart mbp2 = new MimeBodyPart();
			 if (filename != null) {
				 // attach the file to the message
				 // mbp2.attachFile(filename);
				 File file = new File(filename);
				 FileDataSource fds = new FileDataSource(filename);
				 mbp2.setDataHandler(new DataHandler(fds));
				 try {
					 mbp2.setFileName(MimeUtility.encodeText(fds.getName(), "MS950", "B"));
				 } catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
				 	 e.printStackTrace();
			     }
				    /*
				     * Use the following approach instead of the above line if
				     * you want to control the MIME type of the attached file.
				     * Normally you should never need to do this.
				     *
				    FileDataSource fds = new FileDataSource(filename) {
					public String getContentType() {
					    return "application/octet-stream";
					}
				    };
				    mbp2.setDataHandler(new DataHandler(fds));
				    mbp2.setFileName(fds.getName());
				     */
			     }
			     // create the Multipart and add its parts to it
			     Multipart mp = new MimeMultipart();
			     mp.addBodyPart(mbp1);
			     if (filename != null)
			    	mp.addBodyPart(mbp2);

			     // add the Multipart to the message
			     message.setContent(mp);

			     // set the Date: header
			     message.setSentDate(new Date());

			    /*
			     * If you want to control the Content-Transfer-Encoding
			     * of the attached file, do the following.  Normally you
			     * should never need to do this.
			     *
			    msg.saveChanges();
			    mbp2.setHeader("Content-Transfer-Encoding", "base64");
			     */

			    // send the message
			    Transport.send(message);
			    result = true;
	         System.out.println("Sent message successfully....");
	      } catch (MessagingException mex) {
	         mex.printStackTrace();
	         logger.error("sendMail err="+mex.getMessage());
	      }
	      return result;
	}
	
	public boolean sendMailWithAttachement(String to, String from, String host, String fileName, ByteArrayInputStream bis, 
			boolean debug, String msgText, String subject) {
		  boolean result = false;
	      // Get system properties
	      Properties properties = System.getProperties();

	      // Setup mail server
	      properties.setProperty("mail.smtp.host", host);

	      // Get the default Session object.
	      //Session session = Session.getDefaultInstance(properties);
	      Session session = Session.getInstance(properties, null);
			session.setDebug(debug);

	      try {
	         // Create a default MimeMessage object.
	         MimeMessage message = new MimeMessage(session);

	         // Set From: header field of the header.
	         message.setFrom(new InternetAddress(from));

	         // Set To: header field of the header.
	         //message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
	         if (to.contains(","))
	        	 	message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(to));
			    else {
			    	InternetAddress[] address = {new InternetAddress(to)};
			    	message.setRecipients(Message.RecipientType.TO, address);
			    }	

	         // Set Subject: header field
	         message.setSubject(subject);

	         // Now set the actual message
	         //message.setText(msgText);

	         // Send message
	         //Transport.send(message);
	         // create and fill the first message part
			 MimeBodyPart mbp1 = new MimeBodyPart();
			 mbp1.setText(msgText);
			 // 設定郵件內容的型態為 text/plain 或 text/html
	  		 mbp1.setContent(msgText, "text/html" + ";charset=MS950");
	  			
			 // create the second message part
			 MimeBodyPart mbp2 = new MimeBodyPart();
			 if (bis != null) {
				 // attach the file to the message
				 // mbp2.attachFile(filename);
//				 File file = new File(filename);
//				 FileDataSource fds = new FileDataSource(filename);
				 
//				 InputStream targetStream = new FileInputStream(bis);
				 MailDataSource attachement = new MailDataSource(fileName, null, bis);
				 mbp2.setDataHandler(new DataHandler(attachement));
				 try {
					 mbp2.setFileName(MimeUtility.encodeText(fileName, "MS950", "B"));
				 } catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
				 	 e.printStackTrace();
			     }
				    /*
				     * Use the following approach instead of the above line if
				     * you want to control the MIME type of the attached file.
				     * Normally you should never need to do this.
				     *
				    FileDataSource fds = new FileDataSource(filename) {
					public String getContentType() {
					    return "application/octet-stream";
					}
				    };
				    mbp2.setDataHandler(new DataHandler(fds));
				    mbp2.setFileName(fds.getName());
				     */
			     }
			     // create the Multipart and add its parts to it
			     Multipart mp = new MimeMultipart();
			     mp.addBodyPart(mbp1);
			     if (bis != null)
			    	mp.addBodyPart(mbp2);

			     // add the Multipart to the message
			     message.setContent(mp);

			     // set the Date: header
			     message.setSentDate(new Date());

			    /*
			     * If you want to control the Content-Transfer-Encoding
			     * of the attached file, do the following.  Normally you
			     * should never need to do this.
			     *
			    msg.saveChanges();
			    mbp2.setHeader("Content-Transfer-Encoding", "base64");
			     */

			    // send the message
			    Transport.send(message);
			    result = true;
	         System.out.println("Sent message successfully....");
	      } catch (MessagingException mex) {
	         mex.printStackTrace();
	         logger.error("sendMail err="+mex.getMessage());
	      } catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			logger.error("sendMail err="+e1.getMessage());
		}
	    return result;
	}
	
	public boolean sendMailUsingHtml(String to, String from, String host, String filename, 
			boolean debug, String msgText, String subject) {
		  boolean result = false;
	      // Get system properties
	      Properties properties = System.getProperties();

	      // Setup mail server
	      properties.setProperty("mail.smtp.host", host);

	      // Get the default Session object.
	      //Session session = Session.getDefaultInstance(properties);
	      Session session = Session.getInstance(properties, null);
			session.setDebug(debug);

	      try {
	         // Create a default MimeMessage object.
	         MimeMessage message = new MimeMessage(session);

	         // Set From: header field of the header.
	         message.setFrom(new InternetAddress(from));

	         // Set To: header field of the header.
	         //message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
	         if (to.contains(","))
	        	 	message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(to));
			    else {
			    	InternetAddress[] address = {new InternetAddress(to)};
			    	message.setRecipients(Message.RecipientType.TO, address);
			    }	

	         // Set Subject: header field
	         message.setSubject(subject);

	         // Now set the actual message
	         //message.setText(msgText);

	         // Send message
	         //Transport.send(message);
	         // create and fill the first message part
			 MimeBodyPart mbp1 = new MimeBodyPart();
			 mbp1.setText(msgText);
			 // 設定郵件內容的型態為 text/plain 或 text/html
	  		 mbp1.setContent(msgText, "text/html" + ";charset=MS950");
	  			
			 // create the second message part
			 MimeBodyPart mbp2 = new MimeBodyPart();
			 if (filename != null) {
				 // attach the file to the message
				 // mbp2.attachFile(filename);
				 File file = new File(filename);
				 FileDataSource fds = new FileDataSource(filename);
				 mbp2.setDataHandler(new DataHandler(fds));
				 try {
					 mbp2.setFileName(MimeUtility.encodeText(fds.getName(), "MS950", "B"));
				 } catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
				 	 e.printStackTrace();
			     }
				    /*
				     * Use the following approach instead of the above line if
				     * you want to control the MIME type of the attached file.
				     * Normally you should never need to do this.
				     *
				    FileDataSource fds = new FileDataSource(filename) {
					public String getContentType() {
					    return "application/octet-stream";
					}
				    };
				    mbp2.setDataHandler(new DataHandler(fds));
				    mbp2.setFileName(fds.getName());
				     */
			     }
			     // create the Multipart and add its parts to it
			     Multipart mp = new MimeMultipart();
			     mp.addBodyPart(mbp1);
			     if (filename != null)
			    	mp.addBodyPart(mbp2);

			     // add the Multipart to the message
			     message.setContent(mp);

			     // set the Date: header
			     message.setSentDate(new Date());

			    /*
			     * If you want to control the Content-Transfer-Encoding
			     * of the attached file, do the following.  Normally you
			     * should never need to do this.
			     *
			    msg.saveChanges();
			    mbp2.setHeader("Content-Transfer-Encoding", "base64");
			     */

			    // send the message
			    Transport.send(message);
			    result = true;
	         System.out.println("Sent message successfully....");
	      } catch (MessagingException mex) {
	         mex.printStackTrace();
	         logger.error("sendMail err="+mex.getMessage());
	      }
	      return result;
	}
	
	public boolean sendMailUsingHtmlWithAttachement(String to, String from, String host, String fileName, ByteArrayInputStream bis, 
			boolean debug, String msgText, String subject) {
		  boolean result = false;
	      // Get system properties
	      Properties properties = System.getProperties();

	      // Setup mail server
	      properties.setProperty("mail.smtp.host", host);

	      // Get the default Session object.
	      //Session session = Session.getDefaultInstance(properties);
	      Session session = Session.getInstance(properties, null);
			session.setDebug(debug);

	      try {
	         // Create a default MimeMessage object.
	         MimeMessage message = new MimeMessage(session);

	         // Set From: header field of the header.
	         message.setFrom(new InternetAddress(from));

	         // Set To: header field of the header.
	         //message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
	         if (to.contains(","))
	        	 	message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(to));
			    else {
			    	InternetAddress[] address = {new InternetAddress(to)};
			    	message.setRecipients(Message.RecipientType.TO, address);
			    }	

	         // Set Subject: header field
	         message.setSubject(subject);

	         // Now set the actual message
	         //message.setText(msgText);

	         // Send message
	         //Transport.send(message);
	         // create and fill the first message part
			 MimeBodyPart mbp1 = new MimeBodyPart();
			 mbp1.setText(msgText);
			 // 設定郵件內容的型態為 text/plain 或 text/html
	  		 mbp1.setContent(msgText, "text/html" + ";charset=MS950");
	  			
			 // create the second message part
			 MimeBodyPart mbp2 = new MimeBodyPart();
			 if (bis != null) {
				 // attach the file to the message
				 // mbp2.attachFile(filename);
//				 File file = new File(filename);
//				 FileDataSource fds = new FileDataSource(filename);
				 MailDataSource attachement = new MailDataSource(fileName, null, bis);
				 mbp2.setDataHandler(new DataHandler(attachement));
				 try {
					 mbp2.setFileName(MimeUtility.encodeText(fileName, "MS950", "B"));
				 } catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
				 	 e.printStackTrace();
			     }
				    /*
				     * Use the following approach instead of the above line if
				     * you want to control the MIME type of the attached file.
				     * Normally you should never need to do this.
				     *
				    FileDataSource fds = new FileDataSource(filename) {
					public String getContentType() {
					    return "application/octet-stream";
					}
				    };
				    mbp2.setDataHandler(new DataHandler(fds));
				    mbp2.setFileName(fds.getName());
				     */
			     }
			     // create the Multipart and add its parts to it
			     Multipart mp = new MimeMultipart();
			     mp.addBodyPart(mbp1);
			     if (bis != null)
			    	mp.addBodyPart(mbp2);

			     // add the Multipart to the message
			     message.setContent(mp);

			     // set the Date: header
			     message.setSentDate(new Date());

			    /*
			     * If you want to control the Content-Transfer-Encoding
			     * of the attached file, do the following.  Normally you
			     * should never need to do this.
			     *
			    msg.saveChanges();
			    mbp2.setHeader("Content-Transfer-Encoding", "base64");
			     */

			    // send the message
			    Transport.send(message);
			    result = true;
	         System.out.println("Sent message successfully....");
	      } catch (MessagingException mex) {
	         mex.printStackTrace();
	         logger.error("sendMailUsingHtmlAndFileWithDatasource err="+mex.getMessage());
	      } catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	    return result;
	}

	public static void main() {
		MailOutUtil mo= new MailOutUtil();
		mo.sendMail("tom.chan@fubon.com", "fmgim.bank@fubon.com", "mail.fubon.com", null, false, "test mail!!", "test");
	}
}
