package com.xx.demog.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.charset.Charset;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.LoginContext;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ibm.wsspi.security.auth.callback.WSMappingCallbackHandler;
/**
###########################################################################
#    PROGRAM NAME: BaseUtil.java
#
#    DESCRIPTION: 共用functions
#
#    NOTES:
#
#    WRITEEN BY: alvin 2007/9/12
#
#    MODIFIED:
#         Tom 2019/3/13  - 改為mybatis getSqlSession
############################################################################
*/
public class BaseUtil {
    /**
     * Logger for this class
     */
    private static Logger logger = LoggerFactory.getLogger(BaseUtil.class);

    private static final String _APP_PROPERTIES_NAME = "ima.properties";

    private static Properties props = null;
    
    private static SqlSessionFactory sqlSessionFactory=null;
    
    private static HashMap<String,Object> codeRefListMap= new HashMap<String,Object>(); 

    /**
     * 用來讀取設定檔裡的項目
     * @param String name(項目名稱)
     * @return String returnValue(設定值)
     */
    public static String getProperties(String name) {
        loadProperties();
        return props.getProperty(name);
    }
    
    public static Properties getProps(){
        loadProperties();
        return props;
    }
    
    private static void loadProperties(){
        try {
            if (props == null) {
                logger.debug("****** read application.properties ******");
                InputStream is = new FileInputStream(AppConstants.CONFIGURE_PATH + _APP_PROPERTIES_NAME);
                props = new Properties();
                props.load(is);
                is.close();
            }
        } catch (Exception e) {
            logger.error("Can not read the properties file. Make sure file is in the correct path.");
        }
    }

    /**
     * 用來讀取設定檔裡的項目
     * @param List names(項目名稱)
     * @return Map returnValue(設定值)
     */
    public static Map<String, String> getProperties(List<String> names) {
        Map<String, String> result = new HashMap<String, String>();
        if (names != null && names.size() > 0) {
            try {

                loadProperties();

                Iterator<String> itName = names.iterator();
                String name = null;
                while (itName.hasNext()) {
                    name = itName.next();
                    result.put(name, props.getProperty(name));
                }
            } catch (Exception e) {
                logger.error("Can not read the properties file. Make sure file is in the correct path.");
            }
        }

        return result;
    }
    
	/**
	 * 取得SqlSessionFactory
	 * @return SqlSessionFactory
	 * @throws Exception
	 */
	public static SqlSessionFactory getCurrentSqlSessionFactory() throws Exception {
        if (sqlSessionFactory==null){
            Resources.setCharset( Charset.forName( "UTF-8" ) );
            Reader reader = Resources.getResourceAsReader( AppConstants.SQL_MAP_CONFIG );
            loadProperties();
            //sqlMapClient = SqlMapClientBuilder.buildSqlMapClient( reader,props );
            SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader, props);
        }
        
		return sqlSessionFactory;
	}
	
	public static void clearSqlSessionFactory(){
		sqlSessionFactory=null; 
	}
	
	/**
	 * 取得sqlSessionFactory
	 * @return sqlSessionFactory
	 * @throws Exception
	 */
	public static SqlSessionFactory getSqlSessionFactory() throws Exception {
        Resources.setCharset( Charset.forName( "UTF-8" ) );
        Reader reader = Resources.getResourceAsReader( AppConstants.SQL_MAP_CONFIG );
        loadProperties();
        //SqlMapClient sqlMapClient = SqlMapClientBuilder.buildSqlMapClient( reader,props );
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader, props);
        
		return sqlSessionFactory;
	}	

	/**
	 * 取得sqlSessionFactory
	 * @return sqlSessionFactory
	 * @throws Exception
	 */
	public static SqlSessionFactory getSqlSessionFactoryFts() throws Exception {
		Resources.setCharset( Charset.forName( "UTF-8" ) );
		Reader reader = Resources.getResourceAsReader( AppConstants.SQL_MAP_CONFIG_FTS );
        loadProperties();
		//SqlMapClient sqlMapClient = SqlMapClientBuilder.buildSqlMapClient( reader,props );
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader, props);
        
		return sqlSessionFactory;
	}
	
    /**
     * Reload Properties
     * @return Void
     * @throws IOException 
     */
    public static void reloadProperties() throws IOException {
        InputStream is = new FileInputStream(AppConstants.CONFIGURE_PATH + _APP_PROPERTIES_NAME);
        props = new Properties();
        props.load(is);
        is.close();
    }

    /**
     * getLastMonthStr
     * @return Void
     */
    public static String getLastMonthStr() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -1);
        DateFormat dateFormat = new SimpleDateFormat("yyyyMM");
        return dateFormat.format(cal.getTime());
    }
    
    /**
	 * 讀取datasource專案的ftp properties<br/>
	 * 用來讀取設定檔裡的項目
	 * @param String name(項目名稱)
	 * @return String returnValue(設定值)
	 */
	public String getFtpProperties(String name) {
        String returnValue;

        String classPath = AppConstants.CONFIGURE_PATH;
//    	System.out.println("classPath = "+classPath);
    	//1.
    	//在本機eclopse與在tomcat中，兩者路徑會不相同
    	//本機 ex		: D:/aaa/bbb/專案/WebRoot(或WebContent)/WEB-INF/......
    	//Tomcat ex	: D:/xxx/Tomcat/webapps/專案/WEB-INF/...... 
    	//由此可知在本機中，路徑多了WebRoot(或WebContent)這一層
    	//因此讀取絕對路徑的判斷稍有不同
    	String absolutePath = "";
    	
    	//1.1 抓到WEB-INF之前的絕對路徑
//    	absolutePath = classPath.substring(0,classPath.indexOf("WEB-INF")-1);
//    	System.out.println("absolutePath : " + absolutePath);

    	//1.2 如果有WebRoot(WebContent)，則抓到WebRoot(WebContent)之前的絕對路徑
    	String webPath = "";
//    	if(absolutePath.toLowerCase().indexOf("webcontent") != -1){
//    		absolutePath = absolutePath.substring(0,absolutePath.toLowerCase().indexOf("webcontent")-1);
//    		webPath = "WebRoot/";//datasource專案的路徑為WebRoot
//    	}else if(absolutePath.toLowerCase().indexOf("webroot") != -1){
//    		absolutePath = absolutePath.substring(0,absolutePath.toLowerCase().indexOf("webroot")-1);
//    		webPath = "WebRoot/";//datasource專案的路徑為WebRoot
//    	}
//    	System.out.println("absolutePath without WebRoot(WebContent) : " + absolutePath);
    	
    	//1.3抓到專案目錄之前的絕對路徑
//    	980721修改
//    	absolutePath = classPath.substring(0,classPath.indexOf("ear"));
//    	absolutePath = absolutePath.substring(0,absolutePath.lastIndexOf("/")+1);
    	absolutePath = AppConstants.CONFIGURE_PATH_COMMON;
//    	absolutePath = absolutePath.substring(0,absolutePath.lastIndexOf("/") + 1);
//    	System.out.println("absolutePath without project : " + absolutePath);
    	
    	
    	//2. 取得正式機ip，以IP來區分正式機或測試機讀取的datasource
    	String data = "";
    	String ip = NetTool.getLocalHostIP();
    	String[] ips =  this.getProperties(absolutePath , "db.properties" , "db.prod.ip" , webPath).split(",");
    	
		
		
		//3. 判斷是否為正式機ip，若是，讀取datasource_prod.xml
		//若不是，則讀取datasource_test.xml
		for(int i=0;i<ips.length;i++){
			//System.out.println("ips[i] = "+ips[i]);
			if(ip.equals(ips[i])){
				//System.out.println("ips[i] eq "+ips[i]);
				data = "ftp-prod.txt";
			}
		}
		//若查無資料，以測試機論
		if(data.length() == 0){
			data = "ftp-test.txt";
		}

		String newProPath = absolutePath + data;
//		System.out.println("New path = "+newProPath);
//        InputStream is = getClass().getResourceAsStream(classPath+data);
		
        Properties props = new Properties();
        try {
        	InputStream is = new FileInputStream(newProPath);
            props.load(is);
            returnValue = props.getProperty(name);
            is.close();
        } catch (Exception e) {
        	logger.error("Can not read the properties file. " +newProPath+
                               " Make sure file is in the correct path.");
            return null;
        }
        return returnValue;
    }
	
	/**
	 * 讀取datasource專案的properties<br/>
	 * 用來讀取設定檔裡的項目
	 * @param String path(絕對路徑)(到專案名稱前的路徑，不包含專案名稱)
	 * @param String propertiesName(設定檔名稱)
	 * @param String name(項目名稱)
	 * @param String webPath(路徑是否包含WebRoot(WebContent))
	 * @return String returnValue(設定值)
	 */
	private String getProperties(String path , String propertiesName , String name ,String webPath) {
        String returnValue;
        String propertiesPath = path + propertiesName;
//		System.out.println("propertiesPath : "+propertiesPath);
        //InputStream is = getClass().getResourceAsStream("/" + propertiesName);
        Properties props = new Properties();
        try {
        	InputStream is = new FileInputStream(propertiesPath);
    		
            props.load(is);
            returnValue = props.getProperty(name);
            is.close();
        } catch (Exception e) {
//        	e.printStackTrace();
        	logger.error("getProperties Exception ",e);
        	logger.error("Can not read the properties file. " +
                               "Make sure file is in the correct path.");
            return null;
        }
        return returnValue;
	}
	
	/* createZipFile
	 * @param String files[]:input files
	 * @param String zipFileName:output file
	 * 產生 Zip檔
	 */
	public void createZipFile(String files [] , String zipFileName) {
		this.createZipFile(files, zipFileName, false, null);
	}
	
	/* createZipFile
	 * @param String files[]:input files
	 * @param String zipFileName:output file
	 * @param encrypt:加密與否
	 * @param password:密碼
	 * 產生 Zip檔
	 */
	public void createZipFile(String files [] , String zipFileName, boolean encrypt, String password) {
		try {
			// Initiate ZipFile object with the path/name of the zip file.
			ZipFile zipFile = new ZipFile(zipFileName);
			zipFile.setFileNameCharset("MS950");  
			
			// Initiate Zip Parameters which define various properties such
			// as compression method, etc.
			ZipParameters parameters = new ZipParameters();
			parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE); // set compression method to store compression
			
			// Set the compression level
			parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL); 
			
			if (encrypt == true) {
				// Set the encryption flag to true
				// If this is set to false, then the rest of encryption properties are ignored
				parameters.setEncryptFiles(true);				
				// Set the encryption method to Standard Zip Encryption
				parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_STANDARD);				
				// Set password
				parameters.setPassword(password);
			}
			for (int i = 0; i<files.length; i++) 
				zipFile.addFile(new File(files[i]), parameters);
		} catch (ZipException e) {
			e.printStackTrace();
		}
	}
	public String getStringDate(int type ){
		return getStringDate( type, Calendar.getInstance().getTime());
	}
	/**
	 * 常用日期格式<br>
	 * case 1: SimpleDateFormat("yyyyMMdd")<br>
	 * case 2: SimpleDateFormat("yyyy-MM-dd")<br>
	 * case 3: SimpleDateFormat("yyyyMMdd HHmmss")<br>
	 * csae 4: SimpleDateFormat("yyyy-MM-dd HH:mm:ss")<br>
	 * csae 5: SimpleDateFormat("yyyy/MM/dd HH:mm:ss")
	 * @param type 日期格式 1-5
	 * @param date 指定日期
	 * @return String date
	 */
	public static String getStringDate(int type, Date date) {
		SimpleDateFormat simple;
		switch(type) {
			case 1:
				simple = new SimpleDateFormat("yyyyMMdd");
				break;
			case 2:
				simple = new SimpleDateFormat("yyyy-MM-dd");
				break;
			case 3:
				simple = new SimpleDateFormat("yyyyMMdd HHmmss");
				break;
			case 4:
				simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				break;
			case 5:
				simple = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				break;
			default:
				simple = new SimpleDateFormat("yyyy/MM/dd");
		}
		return simple.format(date);
	}
	
	/**
	 * 轉換日期格式<br>
	 * case 1: yyyyMMdd -> yyyy-MM-dd<br>
	 * case 2: yyyy-MM-dd -> yyyyMMdd<br>
	 * @param int type
	 * @param String date
	 * @return String date
	 */
	public String getStringDate(int type,String date) {
		
		switch(type) {
		case 1:
			date = date.substring(0, 4) + "-" + date.substring(4,6) + "-" + date.substring(6);
			break;
		case 2:
			date = date.replaceAll("-", "");
			break;
		}
		return date;
	}
    
    public static void init(){
        try {        
            Resources.setCharset( Charset.forName( "UTF-8" ) );
            Reader reader;
            reader = Resources.getResourceAsReader( AppConstants.SQL_MAP_CONFIG );
            loadProperties();
//            sqlMapClient = SqlMapClientBuilder.buildSqlMapClient( reader,props );
            SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader, props);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static javax.resource.spi.security.PasswordCredential getJ2CData(String j2cAlias) throws Exception {
        javax.resource.spi.security.PasswordCredential result = null;
        try {
            HashMap map = new HashMap();
            map.put(com.ibm.wsspi.security.auth.callback.Constants.MAPPING_ALIAS, j2cAlias);
            //CallbackHandler cbh = (WSMappingCallbackHandlerFactory.getInstance()).getCallbackHandler(map, null);
            CallbackHandler cbh = new WSMappingCallbackHandler(map, null);
            LoginContext lc = new LoginContext("DefaultPrincipalMapping", cbh);
            lc.login();
            javax.security.auth.Subject subject = lc.getSubject();
            java.util.Set creds = subject.getPrivateCredentials();
            result = (javax.resource.spi.security.PasswordCredential) creds.toArray()[0];
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("APPLICATION ERROR: cannot load credentials for j2calias = " + j2cAlias);
            throw new Exception("Unable to get credentials");
        }

        return result;
    }    
    
    /**
     * 取得Context Path
     * @return ctx
     * @throws Exception
     */
    public static String getCtxPath() throws Exception {
    	String ctx = null;
		try {
			String classpath = BaseUtil.class.getResource( "" ).getPath();
			ctx = classpath.substring( 1, BaseUtil.class.getResource( "" ).getPath().lastIndexOf( "/WEB-INF" ) );
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return ctx;
    }    
	/**
	 * 從 StringBuffer 抽取出字串(並「移除」), 回傳抽出的字串
	 * 注意: 副作用為 StringBuffer 直接被改變 
	 * @param sb 原始字串
	 * @param leading true=從前面取字串, false=從後面取
	 * @param len 要抽出的字串
	 * @return 回傳抽出字串(失敗時回傳 "")
	 */
	public static String extractString(StringBuffer sb, boolean leading, int len){
		String rtnstr = null;
		try{
			if(!leading){
				rtnstr = sb.substring(sb.length()-len);
				sb.delete(sb.length()-len, sb.length());
			}else{
				rtnstr = sb.substring(0, len);
				sb.delete(0, len);
			}
			return rtnstr;
		}catch(Exception e){
			return "";
		}
	}
	
    /**
     * 取得FNIMA_CODE_REF特定TYPE的清單
     * @param codeType 代碼類型
     * @return 回傳代碼清單
     */	
    @SuppressWarnings("unchecked")
    public static List < HashMap<String,Object> > getCodeRefList(String codeType){
        List < HashMap<String,Object> > ret=null;
        if (codeRefListMap.containsKey(codeType)){
            ret=(List < HashMap<String,Object> >)codeRefListMap.get(codeType);    
        }else{
        	
            try {
            	SqlSession sqlSession = BaseUtil.getCurrentSqlSessionFactory().openSession();
                ret=sqlSession.selectList("CODE_REF.getListByCodeType",codeType);
                sqlSession.close();
            } catch (Exception e) {
                logger.error(e.toString(),e);
            }
            codeRefListMap.put(codeType, ret);
        }
        
        return ret;
    }

}
