﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fubon.MailService.Server.Models.Base 
{
    /// <summary>
    /// 儲存郵件資訊內容的類別
    /// </summary>
    public class MailInfo : AbstractHistoricalModel
    { 
        public string MailId { get; set; }
        public string Email { get; set; }
        public string UserName { get; set; }
        public string GroupId { get; set; }

        /*
        /// <summary>
        /// 郵件資訊ID
        /// </summary>
        public string UserId { get; set; }

        /// <summary>
        /// 部門名稱
        /// </summary>
        public string DepartmentName { get; set; }

        /// <summary>
        /// 使用者名稱
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 電子郵件
        /// </summary>
        public string Email { get; set; }

        public string GroupId { get; set; }
         * */
    }
}
