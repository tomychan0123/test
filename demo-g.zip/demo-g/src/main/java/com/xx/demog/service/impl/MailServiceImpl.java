package com.xx.demog.service.impl;

import java.io.ByteArrayInputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.xx.demog.dao.mail.MailRepository;
import com.xx.demog.dao.mail.MailSequenceRepository;
import com.xx.demog.domain.mail.EventMail;
import com.xx.demog.domain.mail.MailGroup;
import com.xx.demog.domain.mail.MailInfo;
import com.xx.demog.service.MailService;
import com.xx.demog.util.MailOutUtil;
import com.xx.demog.util.TemplateHelper;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(tags = "MailService")
@Service
public class MailServiceImpl implements MailService {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
    private MailRepository mailRepository;
	@Autowired
	private MailSequenceRepository mailSequenceRepository;
	
	@Autowired
	private static Environment env;
	
	@ApiOperation(value = "取得群組Mail List", notes = "取得群組Mail List")
	@Override
	public List <MailGroup>GetMailGroupList(String groupId) {
		return mailRepository.SelectAllMailGroup(groupId);
	}
	
	@ApiOperation(value = "取得該id的Mail List", notes = "取得該id的Mail List")
	@Override
	public List<MailInfo> selectMailInfoById(String id) {
		return mailRepository.SelectMailInfoByGroupId(id);
	}
	
	@ApiOperation(value = "取得該id的Mail List", notes = "取得該id的Mail List")
	@Override
	public List<MailInfo> GetCanaddUserList(String groupId) {
		return mailRepository.SelectMailInfobyUse(groupId);
	}
	
	@ApiOperation(value = "查可加入的人員", notes = "查可加入的人員")
	@Override
	public boolean InsertMailGroup(MailGroup mailgroupdata) {
		logger.error("InsertMailGroup GroupId=" + mailgroupdata.getGroupId());
        if (mailgroupdata.getGroupId() == null)
        {
            mailgroupdata.setGroupId(mailSequenceRepository.SelectNextSeqNo_GROUP(MailRepository.SequenceKeys.MailGroup.getValue()));
        }
		return mailRepository.InsMailGroup(mailgroupdata);
	}
	
	@ApiOperation(value = "更新MailGroup", notes = "更新MailGroup")
	@Override
	public boolean UpdateMailGroup(MailGroup mailgroupdata) {
		return mailRepository.UpdMailGroup(mailgroupdata);
	}
	
	@ApiOperation(value = "刪除MailGroup", notes = "刪除MailGroup")
	@Override
	public boolean DeleteMailGroup(MailGroup mailgroupdata) {
		return mailRepository.DelMailGroup(mailgroupdata);
	}
	
	@ApiOperation(value = "新增MailGroup資料", notes = "新增MailGroup資料")
	@Override
	public boolean InsertMailGroupItem(MailInfo maildata) {
		return mailRepository.InsMailGroupItem(maildata);
	}
	
	@ApiOperation(value = "刪除MailGroup資料", notes = "刪除MailGroup資料")
	@Override
	public boolean DeleteGroupItem(MailInfo maildata) {
		return mailRepository.DelMailGroupItem(maildata);
	}
	
	@ApiOperation(value = "依MailId刪除MailGroup資料", notes = "依MailId刪除MailGroup資料")
	@Override
	public boolean DeleteGroupItemByMailId(MailInfo maildata) {
		return mailRepository.DelMailGroupItemByMailId(maildata);
	}
	
	@ApiOperation(value = "新增Mail資料", notes = "新增Mail資料")
	@Override
	public boolean InsertMail(MailInfo mailuserdata) {
		if (StringUtils.isEmpty(mailuserdata.getMailId())) 
        {
            mailuserdata.setMailId(mailSequenceRepository.SelectNextSeqNo_MAIL(MailRepository.SequenceKeys.MailID.getValue()));
        }
		return mailRepository.InsMailInfo(mailuserdata);
	}
	
	@ApiOperation(value = "修改Mail資料", notes = "修改Mail資料")
	@Override
	public boolean UpdateMail(MailInfo mailuserdata) {
		return mailRepository.UpdMailInfo(mailuserdata);
	}
	
	@ApiOperation(value = "刪除Mail資料", notes = "刪除Mail資料")
	@Override
	public boolean DeleteMail(MailInfo mailuserdata) {
		return mailRepository.DelMailInfo(mailuserdata);
	}
	
	@ApiOperation(value = "依eventGroupId取得EventMail資料", notes = "依eventGroupId取得EventMail資料")
	@Override
	public List<EventMail> GetEventMailList(String eventGroupId) {
		return mailRepository.SelectEventMailByEventGroup(eventGroupId);
	}
	
	@ApiOperation(value = "依eventMailList修改EventMail資料", notes = "依eventMailList修改EventMail資料")
	@Override
	public int UpdateEventMailList(List<EventMail> eventMailList) {
		int okCount = 0;
        Date now = new Date();
        for (EventMail em:eventMailList)
        {
            em.setUpdateDate(now);
            em.setUpdateUserId("SYSTEM");            
            okCount += mailRepository.UpdateEventMail(em);
        }
        return okCount;
	}
	
	@ApiOperation(value = "依eventId傳送Mail", notes = "依eventId傳送Mail")
	@Override
	public boolean SendMailByEventId(String sysId, String eventId, String subject, String message, String fileName, ByteArrayInputStream attachments)
    {
    	boolean isBodyHtml = false;
        Map map = new HashMap();
        map.put("sysID", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = mailRepository.SelectEventMailByEventId(map).get(0);
            
            if (StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                isBodyHtml = true;
            else
                isBodyHtml = false;
            logger.error("EventId[" + eventId + "] isBodyHtml=" + isBodyHtml + " eventMail.IsBodyHtml=" + eventMail.getIsBodyHtml());
            
            if (eventMail != null && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
            	List<MailInfo> mails = mailRepository.SelectMailInfoByGroupId(eventMail.getMailGroupId());
            	
                if (mails != null && mails.size() > 0)
                {
                    String mailTo = "";
                    
                    for (MailInfo mi : mails)
                    {
                        if (!StringUtils.isEmpty(mi.getEmail()))
                        {
                            mailTo += mi.getEmail().contains("@") ? mi.getEmail() : mi.getEmail() + "@fubon.com";
                            mailTo += ";";
                        }
                    }
                    return SendMail(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml);
                }
                else
                {
                	logger.error("EventId[" + eventId + "] 郵件群組[" + eventMail.getMailGroupId() + "]的郵件清單是空白.");
                    return false;
                }

            }
            else
            {
            	logger.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }

        }
        catch (Exception e)
        {
        	e.printStackTrace();
        	logger.error("SendMailByEventId error", e.getMessage());
        }
        return false;
    }
	
	@ApiOperation(value = "依eventIdTemplate傳送Mail", notes = "依eventIdTemplate傳送Mail")
	@Override
	public boolean SendMailByEventIdTemplate(String sysId, String eventId, String subject, HashMap<String, Object> attrs, String fileName, ByteArrayInputStream attachments) {
		Map<String, String> map = new HashMap<String, String>();
        map.put("sysId", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = mailRepository.SelectEventMailFullByEventId(map).get(0);
            if (eventMail != null && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
            	List<MailInfo> mails = mailRepository.SelectMailInfoByGroupId(eventMail.getMailGroupId());
            	boolean isBodyHtml = false;
                if (!StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                    isBodyHtml = true;
                else
                    isBodyHtml = false;
                if (mails != null && mails.size() > 0)
                {
                    String mailTo = "";
                    for (MailInfo mi : mails)
                    {
                        if (!StringUtils.isEmpty(mi.getEmail()))
                        {
                            mailTo += mi.getEmail().contains("@") ? mi.getEmail() : mi.getEmail() + "@fubon.com";
                            mailTo += ";";
                        }
                    }
                    if (StringUtils.isEmpty(subject))
                        subject = eventMail.getMailSubject();
                    String message = TemplateHelper.RenderTemplateByContent(eventMail.getMailTemplate(), attrs);
                    return SendMail(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml);
                }
                else
                {
                    logger.error("EventId[" + eventId + "] 郵件群組[" + eventMail.getMailGroupId() + "]的郵件清單是空白.");
                    return false;
                }

            }
            else
            {
                logger.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }
        }
        catch (Exception e)
        {
        	e.printStackTrace();
        	logger.error("SendMailByEventIdTemplate error", e.getMessage());
        }
        return false;
	}
	
	@ApiOperation(value = "依eventId與指定收件人傳送Mail", notes = "依eventId與指定收件人傳送Mail")
	@Override
	public boolean SendMailByEventIdAndReceiver(String sysId, String eventId, String fileName, ByteArrayInputStream attachments, String receiver) {
		Map<String, String> map = new HashMap<String, String>();
        map.put("sysId", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = mailRepository.SelectEventMailFullByEventId(map).get(0);
            if (eventMail != null && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
            	boolean isBodyHtml = false;
                if (!StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                    isBodyHtml = true;
                else
                    isBodyHtml = false;
                String mailTo = receiver;
                String subject = eventMail.getMailSubject();
                String message = eventMail.getMailTemplate();
                return SendMail(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml);
            }
            else
            {
                logger.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }
        }
        catch (Exception e)
        {
        	e.printStackTrace();
        	logger.error("SendMailByEventIdAndReceiver error", e.getMessage());
        }
        return false;
	}
	
	@ApiOperation(value = "依eventId與指定收件人/送件人傳送Mail", notes = "依eventId與指定收件人/送件人傳送Mail")
	@Override
	public boolean SendMailByEventIdWithReceiverAndSender(String sysId, String eventId, String subject, String message, String fileName, ByteArrayInputStream attachments, String receiver, String sender) {
		Map<String, String> map = new HashMap<String, String>();
        map.put("sysId", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = mailRepository.SelectEventMailByEventId(map).get(0);
            boolean isBodyHtml = false;
            if (!StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                isBodyHtml = true;
            else
                isBodyHtml = false;

            logger.error("EventId[" + eventId + "] isBodyHtml=" + isBodyHtml + " eventMail.IsBodyHtml=" + eventMail.getIsBodyHtml());
            if (eventMail != null && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
                String mailTo = receiver;
                return SendMailWithSender(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml, sender);
            }
            else
            {
                //if (_log.IsInfoEnabled)
            	logger.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }

        }
        catch (Exception e)
        {
        	e.printStackTrace();
        	logger.error("SendMailByEventIdWithReceiverAndSender error", e.getMessage());
        }
        return false;
	}
	
	@ApiOperation(value = "依eventIdTemplate與指定收件人傳送Mail", notes = "依eventIdTemplate與指定收件人傳送Mail")
	@Override
	public boolean SendMailByEventIdTemplateWithReceiver(String sysId, String eventId, String subject, HashMap<String, Object> attrs, String fileName, ByteArrayInputStream attachments, String receiver) {
		Map<String, String> map = new HashMap<String, String>();
        map.put("sysId", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = mailRepository.SelectEventMailFullByEventId(map).get(0);
            if (eventMail != null && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
                List<MailInfo> mails = mailRepository.SelectMailInfoByGroupId(eventMail.getMailGroupId());
                boolean isBodyHtml = false;
                if (!StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                    isBodyHtml = true;
                else
                    isBodyHtml = false;
                String mailTo = receiver;
                String message = TemplateHelper.RenderTemplateByContent(eventMail.getMailTemplate(), attrs);
                return SendMail(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml);
            }
            else
            {
                //if (_log.IsInfoEnabled)
            	logger.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }
        }
        catch (Exception e)
        {
        	e.printStackTrace();
        	logger.error("SendMailByEventIdTemplateWithReceiver error", e.getMessage());
        }
        return false;
	}
	
	@ApiOperation(value = "依eventIdTemplate與指定收件人/送件人傳送Mail", notes = "依eventIdTemplate與指定收件人/送件人傳送Mail")
	@Override
	public boolean SendMailByEventIdTemplateWithReceiverAndSender(String sysId, String eventId, String subject, HashMap<String, Object> attrs, String fileName, ByteArrayInputStream attachments, String receiver, String sender) {
		Map<String, String> map = new HashMap<String, String>();
        map.put("sysId", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = mailRepository.SelectEventMailFullByEventId(map).get(0);
            if (eventMail != null && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
                List<MailInfo> mails = mailRepository.SelectMailInfoByGroupId(eventMail.getMailGroupId());
                boolean isBodyHtml = false;
                if (!StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                    isBodyHtml = true;
                else
                    isBodyHtml = false;
                String mailTo = receiver;
                String message = TemplateHelper.RenderTemplateByContent(eventMail.getMailTemplate(), attrs);
                return SendMailWithSender(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml, sender);
            }
            else
            {
                //if (_log.IsInfoEnabled)
            	logger.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }
        }
        catch (Exception e)
        {
        	logger.error("SendMailByEventIdTemplateWithReceiverAndSender error", e);
        }
        return false;
	}
	
	@ApiOperation(value = "依eventId與指定收件人/送件人傳送Mail", notes = "依eventId與指定收件人/送件人傳送Mail")
	@Override
	public boolean SendMailByEventIdAndReceiverAndSender(String sysId, String eventId, String fileName, ByteArrayInputStream attachments, String receiver, String sender) {
		Map<String, String> map = new HashMap<String, String>();
        map.put("sysId", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = mailRepository.SelectEventMailFullByEventId(map).get(0);
            if (eventMail != null && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
            	boolean isBodyHtml = false;
                if (!StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                    isBodyHtml = true;
                else
                    isBodyHtml = false;
                String mailTo = receiver;
                String subject = eventMail.getMailSubject();
                String message = eventMail.getMailTemplate();
                return SendMailWithSender(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml, sender);
            }
            else
            {
                //if (_log.IsInfoEnabled)
            	logger.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }
        }
        catch (Exception e)
        {
        	e.printStackTrace();
        	logger.error("SendMailByEventIdAndReceiverAndSender error", e.getMessage());
        }
        return false;
	}
	
	@ApiOperation(value = "依eventId與指定送件人傳送Mail", notes = "依eventId與指定送件人傳送Mail")
	@Override
	public boolean SendMailByEventIdAndSender(String sysId, String eventId, String fileName, ByteArrayInputStream attachments, String sender) {
		Map<String, String> map = new HashMap<String, String>();
        map.put("sysId", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = mailRepository.SelectEventMailFullByEventId(map).get(0);
            if (eventMail != null && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
                List<MailInfo> mails = mailRepository.SelectMailInfoByGroupId(eventMail.getMailGroupId());
                boolean isBodyHtml = false;
                if (!StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                    isBodyHtml = true;
                else
                    isBodyHtml = false;
                if (mails != null && mails.size() > 0)
                {
                	String mailTo = "";
                    for (MailInfo mi : mails)
                    {
                        if (mi.getEmail() != null)
                        {
                            mailTo += mi.getEmail().contains("@") ? mi.getEmail() : mi.getEmail() + "@fubon.com";
                            mailTo += ";";
                        }
                    }
                    String subject = eventMail.getMailSubject();
                    String message = eventMail.getMailTemplate();
                    return SendMailWithSender(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml, sender);
                }
                else
                {
                    //if (_log.IsInfoEnabled)
                    logger.error("EventId[" + eventId + "] 郵件群組[" + eventMail.getMailGroupId() + "]的郵件清單是空白.");
                    return false;
                }
            }
            else
            {
                //if (_log.IsInfoEnabled)
            	logger.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }
        }
        catch (Exception e)
        {
        	e.printStackTrace();
        	logger.error("SendMailByEventIdAndSender error", e.getMessage());
        }
        return false;
	}
	
	@ApiOperation(value = "依eventIdTemplate與指定送件人傳送Mail", notes = "依eventIdTemplate與指定送件人傳送Mail")
	@Override
	public boolean SendMailByEventIdTemplateWithSender(String sysId, String eventId, String subject, HashMap<String, Object> attrs, String fileName, ByteArrayInputStream attachments, String sender) {
		Map<String, String> map = new HashMap<String, String>();
        map.put("sysId", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = mailRepository.SelectEventMailFullByEventId(map).get(0);
            if (eventMail != null && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
                List<MailInfo> mails = mailRepository.SelectMailInfoByGroupId(eventMail.getMailGroupId());
                boolean isBodyHtml = false;
                if (!StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                    isBodyHtml = true;
                else
                    isBodyHtml = false;

                if (mails != null && mails.size()> 0)
                {
                	String mailTo = "";
                    for (MailInfo mi : mails)
                    {
                        if (!StringUtils.isEmpty(mi.getEmail()))
                        {
                            mailTo += mi.getEmail().contains("@") ? mi.getEmail() : mi.getEmail() + "@fubon.com";
                            mailTo += ";";
                        }
                    }
                    if (subject == null)
                        subject = eventMail.getMailSubject();
                    String message = TemplateHelper.RenderTemplateByContent(eventMail.getMailTemplate(), attrs);
                    return SendMailWithSender(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml, sender);
                }
                else
                {
                    //if (_log.IsInfoEnabled)
                    logger.error("EventId[" + eventId + "] 郵件群組[" + eventMail.getMailGroupId() + "]的郵件清單是空白.");
                    return false;
                }
            }
            else
            {
                //if (_log.IsInfoEnabled)
            	logger.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }
        }
        catch (Exception e)
        {
        	e.printStackTrace();
        	logger.error("SendMailByEventIdTemplateWithSender error", e.getMessage());
        }
        return false;
	}
	
	@ApiOperation(value = "依eventId與指定送件人傳送Mail", notes = "依eventId與指定送件人傳送Mail")
	@Override
	public boolean SendMailByEventIdWithSender(String sysId, String eventId, String subject, String message, String fileName, ByteArrayInputStream attachments, String sender) {
		Map<String, String> map = new HashMap<String, String>();
        map.put("sysId", sysId);
        map.put("eventId", eventId);
        try
        {
            EventMail eventMail = mailRepository.SelectEventMailByEventId(map).get(0);
            List<MailInfo> mails = mailRepository.SelectMailInfoByGroupId(eventMail.getMailGroupId());
            boolean isBodyHtml = false;
            if (!StringUtils.isEmpty(eventMail.getIsBodyHtml()) && eventMail.getIsBodyHtml().equals("Y"))
                isBodyHtml = true;
            else
                isBodyHtml = false;

            logger.error("EventId[" + eventId + "] isBodyHtml=" + isBodyHtml + " eventMail.IsBodyHtml=" + eventMail.getIsBodyHtml());

            if (eventMail != null && !StringUtils.isEmpty(eventMail.getMailGroupId()))
            {
                if (mails != null && mails.size() > 0)
                {
                	String mailTo = "";
                    for (MailInfo mi : mails)
                    {
                        if (!StringUtils.isEmpty(mi.getEmail()))
                        {
                            mailTo += mi.getEmail().contains("@") ? mi.getEmail() : mi.getEmail() + "@fubon.com";
                            mailTo += ";";
                        }
                    }
                    if (subject == null)
                        subject = eventMail.getMailSubject();
                    return SendMailWithSender(eventId, mailTo, subject, message, fileName, attachments, isBodyHtml, sender);
                }
                else
                {
                    //if (_log.IsInfoEnabled)
                	logger.error("EventId[" + eventId + "] 郵件群組[" + eventMail.getMailGroupId() + "]的郵件清單是空白.");
                    return false;
                }
            }
            else
            {
                //if (_log.IsInfoEnabled)
            	logger.error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                return false;
            }

        }
        catch (Exception e)
        {
        	e.printStackTrace();
        	logger.error("SendMailByEventIdWithSender error", e.getMessage());
        }
        return false;
	}
	
	private boolean SendMail(String eventId, String mailTo, String subject, String message, String fileName, ByteArrayInputStream bis, boolean isBodyHtml)
    {
    	MailOutUtil mu = new MailOutUtil();
    	boolean ret = mu.sendMailUsingHtmlWithAttachement(mailTo, env.getProperty("mail.fromUser"), env.getProperty("mail.host"), fileName, bis, false, message, subject);
        String msg = "發送事件[" + eventId + "], 主題[" + subject + "], 訊息[" + message + "]";
        if (ret)
            logger.info(msg + "完成");
        else
        	logger.info(msg + "失敗");
        return ret;
    }
    
    private boolean SendMailWithSender(String eventId, String mailTo, String subject, String message, String fileName, ByteArrayInputStream bis, boolean isBodyHtml, String sender)
    {
    	MailOutUtil mu = new MailOutUtil();
    	boolean ret = mu.sendMailUsingHtmlWithAttachement(mailTo, sender, env.getProperty("mail.host"), fileName, bis, false, message, subject);
    	String msg = "發送事件[" + eventId + "], 主題[" + subject + "], 訊息[" + message + "]";
        if (ret)
        	logger.info(msg + "完成");
        else
        	logger.info(msg + "失敗");
        return ret;
    }
}
