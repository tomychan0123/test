﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using Ionic.Zip;
using log4net;

[assembly: log4net.Config.XmlConfigurator(ConfigFile = "app.log4net", Watch = true)]

namespace Fubon.Utility.Web
{
    public class MailUtil
    {
        private static readonly ILog _log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private string _mailTo;
        private string _mailFrom;
        private string _mailSubject;
        private string _message;
        //private string _host = "10.201.13.35";
        private string _host = "172.16.210.4";
        private int _port= 25;
        private string _attachments;    //多附件使用 , or ; 分隔
        private bool _isBodyHTML = false;
        private bool _zipYes = false;
        
        //壓縮選項  --for  option 
        public Boolean Zip_Yes { get; set; }
        public string Zip_Pwd { get; set; }
        public string Zip_FileName { get; set; }

        public MailUtil(string mailFrom, string mailTo, string mailSubject, string message, string attachments, bool zip_Yes)
        {
            _mailTo = mailTo;
            _mailFrom = mailFrom;
            _mailSubject = mailSubject;
            _message = message; 
            _attachments = attachments;
            _zipYes = zip_Yes;
            Zip_Pwd = "";
            Zip_FileName = "";
            _isBodyHTML = false;
        }

        public MailUtil(string mailFrom, string mailTo, string mailSubject, string message, string attachments, bool isBodyHTML, bool zip_Yes)
        {
            _mailTo = mailTo;
            _mailFrom = mailFrom;
            _mailSubject = mailSubject;
            _message = message;
            _attachments = attachments;
            _zipYes = zip_Yes;
            Zip_Pwd = "";
            Zip_FileName = "";
            _isBodyHTML = isBodyHTML;
        }

        public bool SendMail()
        {
            SmtpClient smtpClient = null;
            bool status = false;
            NameValueCollection appParams = (NameValueCollection)System.Configuration.ConfigurationManager.GetSection("app");
            string hostIP = appParams["ftp.hostIP"];
            string userName = appParams["ftp.userName"];
            string passWord = appParams["ftp.passWord"];
            string path = "D:\\files\\mailService";
            
            try
            {
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
                FtpUtil ftp = new FtpUtil(hostIP, userName, passWord);

                MailMessage mail = new MailMessage();
                mail.From = new MailAddress(_mailFrom);

                string[] receivers = _mailTo.Split(new char[2] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < receivers.Length; i++)
                {
                    if (receivers[i].Length > 0)
                    {
                        mail.To.Add(receivers[i]);  //加入收件者
                    }
                }

                mail.Body = _message;
                mail.IsBodyHtml = _isBodyHTML;
                mail.Subject = _mailSubject;
                smtpClient = new SmtpClient(_host, _port);

                smtpClient.EnableSsl = false;  //目前不使用SSL //經過ssl加密
 
                //依富邦設定目前 exchange server 寄件人無須驗證登入，但是收信需要驗證
                //smtpClient.Credentials = new NetworkCredential(_mailFrom, _mailFromPass);

                if (!string.IsNullOrEmpty(_attachments))
                {
                    string[] files = _attachments.Split(new char[2] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries);

                    Attachment attachment;

                    //壓縮資料
                    if (_zipYes)
                    {
                        if (Zip_FileName.Length == 0) 
                        {
                            Zip_FileName = "ZipTemp";
                        }

                        MemoryStream outputStream = new MemoryStream();
                        using (ZipFile zip = new ZipFile(System.Text.Encoding.Default))
                        {


                            foreach (string file in files)
                            {
                                string fileName = Path.GetFileName(file);
                                string file1 = path + "\\" + fileName;
                                ftp.Download(file, file1);
                                if (Zip_Pwd != null && Zip_Pwd != string.Empty) zip.Password = Zip_Pwd;

                                zip.AddFile(file1, "");
                            }

                            zip.Save(outputStream);
                        }
                        outputStream.Seek(0, 0);    //輸出時要先將position 歸0
                        attachment = new Attachment(outputStream, new ContentType("application/zip")) { Name = Zip_FileName + ".zip" };
                        mail.Attachments.Add(attachment);
                    }
                    else
                    {
                        foreach (string file in files)
                        {
                            string fileName = Path.GetFileName(file);
                            string file1 = path + "\\" + fileName;
                            ftp.Download(file, file1);
                            _log.Error("MailUtils file=" + file + " file1=" + file1);
                            //加入附件的明細
                            attachment = new Attachment(file1, MediaTypeNames.Application.Octet);
                            ContentDisposition disposition = attachment.ContentDisposition;
                            disposition.CreationDate = File.GetCreationTime(file1);
                            disposition.ModificationDate = File.GetLastWriteTime(file1);
                            disposition.ReadDate = File.GetLastAccessTime(file1);
                            disposition.FileName = Path.GetFileName(file1);
                            disposition.Size = new FileInfo(file1).Length;
                            disposition.DispositionType = DispositionTypeNames.Attachment;
                            mail.Attachments.Add(attachment);
                        }
                    
                    }  
                }
 
                //mail.IsBodyHtml = false;
 
                smtpClient.Send(mail);
                status = true;
            }
            catch (Exception ex)
            {
                status = false;
                _log.Error(ex);
            }
            finally
            {
                if (smtpClient != null)
                {
                    smtpClient.Dispose();
                }
            }
            return status;
        }

        public string MailHost
        {
            get
            {
                return _host;
            }
            set
            {
                this._host = value;
            }
        }

        public int MailPort
        {
            get
            {
                return _port;
            }
            set
            {
                this._port = value;
            }
        }
    }
}
