﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Net;
using System.Text;
using Fubon.Utility.Common;
using log4net;

namespace Fubon.Utility.Web
{
    public class FtpUtil
    {
        private static readonly ILog _log = LogManager.GetLogger(typeof(FtpUtil));
        private string _host = null;
        private string _user = null;
        private string _pass = null;
        private Stream _ftpStream = null;
        private FtpWebRequest _ftpRequest = null;
        private FtpWebResponse _ftpResponse = null;
        private int _bufferSize = 2048;
 
        public FtpUtil(string hostIP, string userName, string passWord) {
            _host = hostIP;
            _user = userName;
            _pass = passWord; 
        }

        private FtpWebRequest GetFtpRequest(string filePath)
        {
            _ftpRequest = (FtpWebRequest)FtpWebRequest.Create(_host + "//" + filePath);
            _ftpRequest.Credentials = new NetworkCredential(_user, _pass);
            _ftpRequest.UseBinary = true;
            _ftpRequest.UsePassive = true;
            _ftpRequest.KeepAlive = true;
            return _ftpRequest;
        }

        //get ftp content but not store to file
        public byte[] GetFileContent(string filePath)
        {
            byte[] content = null;
            try
            {
                _ftpRequest = GetFtpRequest(filePath);
                _ftpRequest.Method = WebRequestMethods.Ftp.DownloadFile;
                _ftpResponse = (FtpWebResponse)_ftpRequest.GetResponse();

                Stream ftpStream = _ftpResponse.GetResponseStream();
                content = IOUtil.ReadBytesFromStream(ftpStream);
            }
            catch (Exception ex)
            {
                _log.Error(ex);
            }
            finally
            {
                if (_ftpResponse != null)
                {
                    try
                    {
                        _ftpResponse.Close();
                        _ftpResponse = null;
                    }
                    catch (Exception) { }
                }
                _ftpRequest = null;
            }
            return content;
        }

        // Download File 
        public void Download(string remoteFile, string localFile)
        {
            try
            {
                _log.Error("Download remoteFile=" + remoteFile + " localFile=" + localFile);
                _ftpRequest = GetFtpRequest(remoteFile);
                _ftpRequest.Method = WebRequestMethods.Ftp.DownloadFile;
                _ftpResponse = (FtpWebResponse)_ftpRequest.GetResponse();

                _ftpStream = _ftpResponse.GetResponseStream();

                FileStream localFileStream = new FileStream(localFile, FileMode.Create);

                byte[] byteBuffer = new byte[_bufferSize];
                int bytesRead = _ftpStream.Read(byteBuffer, 0, _bufferSize);
                
                while (bytesRead > 0)
                {
                   localFileStream.Write(byteBuffer, 0, bytesRead);
                   bytesRead = _ftpStream.Read(byteBuffer, 0, _bufferSize);
                }

                localFileStream.Close();
                _ftpStream.Close();
                _ftpResponse.Close();
                _ftpRequest = null;
            } 
            catch (Exception ex) 
            {
                _log.Error(ex);
            }
            return;
        }



        // Upload File by byte[] 
        public void UploadFileByBytes(string remoteFile, byte[] dataByte)
        {
            try
            {
                _ftpRequest = GetFtpRequest(remoteFile);
                _ftpRequest.Method = WebRequestMethods.Ftp.UploadFile;
                _ftpStream = _ftpRequest.GetRequestStream();
                byte[] byteBuffer = new byte[_bufferSize]; 
                _ftpStream.Write(dataByte, 0, dataByte.Length);
                _ftpStream.Close();
                _ftpRequest = null;
            }
            catch (Exception ex)
            {
                _log.Error(ex);
            }
            return;
        }

        // Upload File 
        public void Upload(string remoteFile, string localFile)
        {
            try
            {
                _ftpRequest = GetFtpRequest(remoteFile);
                _ftpRequest.Method = WebRequestMethods.Ftp.UploadFile;
                _ftpStream = _ftpRequest.GetRequestStream();
                FileStream localFileStream = new FileStream(localFile, FileMode.OpenOrCreate);
                byte[] byteBuffer = new byte[_bufferSize];
                int bytesSent = localFileStream.Read(byteBuffer, 0, _bufferSize);
                
                while (bytesSent != 0)
                {
                    _ftpStream.Write(byteBuffer, 0, bytesSent);
                   bytesSent = localFileStream.Read(byteBuffer, 0, _bufferSize);
                }
                localFileStream.Close();
                _ftpStream.Close();
                _ftpRequest = null;
            }
            catch (Exception ex)
            {
                _log.Error(ex);
            }
            return;
        }

        // Delete File 
        public void Delete(string deleteFile)
        {
            try
            {
                _ftpRequest = GetFtpRequest(deleteFile);
                _ftpRequest.Method = WebRequestMethods.Ftp.DeleteFile;
                _ftpResponse = (FtpWebResponse)_ftpRequest.GetResponse();
                _ftpResponse.Close();
                _ftpRequest = null;
            }
            catch (Exception ex)
            {
                _log.Error(ex);
            }
            return;
        }

        // Rename File 
        public void Rename(string currentFileNameAndPath, string newFileName)
        {
            try
            {
                _ftpRequest = GetFtpRequest(currentFileNameAndPath);
                _ftpRequest.Method = WebRequestMethods.Ftp.Rename;
                _ftpRequest.RenameTo = newFileName;
                _ftpResponse = (FtpWebResponse)_ftpRequest.GetResponse();
                _ftpResponse.Close();
                _ftpRequest = null;
            }
            catch (Exception ex)
            {
                _log.Error(ex);
            }
            return;
        }

        // Create a New Directory on the FTP Server 
        public void CreateDirectory(string newDirectory)
        {
            try
            {
                _ftpRequest = GetFtpRequest(newDirectory);
                _ftpRequest.Method = WebRequestMethods.Ftp.MakeDirectory;
                _ftpResponse = (FtpWebResponse)_ftpRequest.GetResponse();
                _ftpResponse.Close();
                _ftpRequest = null;
            }
            catch (Exception ex)
            {
                _log.Error(ex);
            }
            return;
        }

        // Get the Date/Time a File was Created 
        public string GetFileCreatedDateTime(string fileName)
        {
            try
            {
                _ftpRequest = GetFtpRequest(fileName);
                _ftpRequest.Method = WebRequestMethods.Ftp.GetDateTimestamp;
                _ftpResponse = (FtpWebResponse)_ftpRequest.GetResponse();
                _ftpStream = _ftpResponse.GetResponseStream();
                StreamReader ftpReader = new StreamReader(_ftpStream);
                string fileInfo = null;
                fileInfo = ftpReader.ReadToEnd();
                ftpReader.Close();
                _ftpStream.Close();
                _ftpResponse.Close();
                _ftpRequest = null;
                return fileInfo;
            }
            catch (Exception ex)
            {
                _log.Error(ex);
            }
            return "";
        }

        // Get the Size of a File 
        public string GetFileSize(string fileName)
        {
            try
            {
                _ftpRequest = GetFtpRequest(fileName);
                _ftpRequest.Method = WebRequestMethods.Ftp.GetFileSize;
                _ftpResponse = (FtpWebResponse)_ftpRequest.GetResponse();
                _ftpStream = _ftpResponse.GetResponseStream();
                StreamReader ftpReader = new StreamReader(_ftpStream);
                string fileInfo = null;
                while (ftpReader.Peek() != -1) 
                { 
                    fileInfo = ftpReader.ReadToEnd(); 
                }
                ftpReader.Close();
                _ftpStream.Close();
                _ftpResponse.Close();
                _ftpRequest = null;
                return fileInfo;
            }
            catch (Exception ex)
            {
                _log.Error(ex);
            }
            return "";
        }

        // List Directory Contents File/Folder Name Only 
        public string[] DirectoryListSimple(string directory)
        {
            try
            {
                _ftpRequest = GetFtpRequest(directory);
                _ftpRequest.Method = WebRequestMethods.Ftp.ListDirectory;
                _ftpResponse = (FtpWebResponse)_ftpRequest.GetResponse();
                _ftpStream = _ftpResponse.GetResponseStream();
                StreamReader ftpReader = new StreamReader(_ftpStream);
                string directoryRaw = null;
                try { while (ftpReader.Peek() != -1) { directoryRaw += ftpReader.ReadLine() + "|"; } }
                catch (Exception) { }
                ftpReader.Close();
                _ftpStream.Close();
                _ftpResponse.Close();
                _ftpRequest = null;
                // Return the Directory Listing as a string Array by Parsing 'directoryRaw' with the Delimiter you Append (I use | in This Example) 
                try { string[] directoryList = directoryRaw.Split("|".ToCharArray()); return directoryList; }
                catch (Exception ex) { _log.Error(ex); }
            }
            catch (Exception ex)
            {
                _log.Error(ex);
            }
            return new string[] { "" };
        }

        // List Directory Contents in Detail (Name, Size, Created, etc.) 
        public string[] DirectoryListDetailed(string directory)
        {
            try
            {
                _ftpRequest = GetFtpRequest(directory);
                _ftpRequest.Method = WebRequestMethods.Ftp.ListDirectoryDetails;
                _ftpResponse = (FtpWebResponse)_ftpRequest.GetResponse();
                _ftpStream = _ftpResponse.GetResponseStream();
                StreamReader ftpReader = new StreamReader(_ftpStream);
                string directoryRaw = null;
                try { while (ftpReader.Peek() != -1) { directoryRaw += ftpReader.ReadLine() + "|"; } }
                catch (Exception) { }
                ftpReader.Close();
                _ftpStream.Close();
                _ftpResponse.Close();
                _ftpRequest = null;
                // Return the Directory Listing as a string Array by Parsing 'directoryRaw' with the Delimiter you Append (I use | in This Example) 
                try { string[] directoryList = directoryRaw.Split("|".ToCharArray()); return directoryList; }
                catch (Exception ex) { _log.Error(ex); }
            }
            catch (Exception ex)
            {
                _log.Error(ex);
            }
            return new string[] { "" };
        }


        /*
        private static FtpWebRequest GetFtpRequest(String ftpServer, String ftpUserName, String ftpPassword, string filePath)
        {
            FtpWebRequest ftpRequest = (FtpWebRequest)FtpWebRequest.Create(ftpServer + filePath);
            // Log in to the FTP Server with the User Name and Password Provided 
            ftpRequest.Credentials = new NetworkCredential(ftpUserName, ftpPassword);
            // When in doubt, use these options 
            ftpRequest.UseBinary = true;
            ftpRequest.UsePassive = true;
            ftpRequest.KeepAlive = true;
            return ftpRequest;
        }

        public static bool Connect(String ftpServer, String ftpUserName, String ftpPassword)
        {
            try
            {
                FtpWebRequest ftpRequest = GetFtpRequest(ftpServer, ftpUserName, ftpPassword, "/");
                // Specify the Type of FTP Request 
                ftpRequest.Method = WebRequestMethods.Ftp.ListDirectory;
                // Establish Return Communication with the FTP Server 
                FtpWebResponse ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();
                // Establish Return Communication with the FTP Server 
                Stream ftpStream = ftpResponse.GetResponseStream();
                // Get the FTP Server's Response Stream 
                StreamReader ftpReader = new StreamReader(ftpStream);
                // Store the Raw Response 
                string fileInfo = null;
                // Read the Full Response Stream 
                try { while (ftpReader.Peek() != -1) { fileInfo = ftpReader.ReadToEnd(); } }
                catch (Exception) { Console.WriteLine(ex.ToString()); }
                // Resource Cleanup 
                ftpReader.Close();
                ftpStream.Close();
                ftpResponse.Close();
                ftpRequest = null;
                return true;
            }
            catch (Exception)
            {

            }
            return false;
        }

        public static bool FileExists(String ftpServer, String ftpUserName, String ftpPassword, string filePath)
        {

            try
            {
                FtpWebRequest ftpRequest = GetFtpRequest(ftpServer, ftpUserName, ftpPassword, filePath);
                // Specify the Type of FTP Request 
                ftpRequest.Method = WebRequestMethods.Ftp.DownloadFile;
                // Establish Return Communication with the FTP Server 
                FtpWebResponse ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();
                // Establish Return Communication with the FTP Server 
                Stream ftpStream = ftpResponse.GetResponseStream();
                // Get the FTP Server's Response Stream 
                StreamReader ftpReader = new StreamReader(ftpStream);
                // Store the Raw Response 
                string fileInfo = null;
                // Read the Full Response Stream 
                try { while (ftpReader.Peek() != -1) { fileInfo = ftpReader.ReadToEnd(); } }
                catch (Exception) { Console.WriteLine(ex.ToString()); }
                // Resource Cleanup 
                ftpReader.Close();
                ftpStream.Close();
                ftpResponse.Close();
                ftpRequest = null;
                return true;
            }
            catch (Exception)
            {

            }
            return false;
        }

        public static byte[] GetFileContent(String ftpServer, String ftpUserName, String ftpPassword, string filePath)
        {
            FtpWebRequest ftpRequest = null;
            FtpWebResponse ftpResponse = null;
            byte[] content = null;
            try
            {
                ftpRequest = GetFtpRequest(ftpServer, ftpUserName, ftpPassword, filePath);
                // Specify the Type of FTP Request 
                ftpRequest.Method = WebRequestMethods.Ftp.DownloadFile;
                // Establish Return Communication with the FTP Server 
                ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();
                // Establish Return Communication with the FTP Server 
                Stream ftpStream = ftpResponse.GetResponseStream();

                content = IOUtil.ReadBytesFromStream(ftpStream);

            }
            finally
            {
                if (ftpResponse != null)
                {
                    try
                    {
                        ftpResponse.Close();
                        ftpResponse = null;
                    }
                    catch (Exception) { }
                }
                ftpRequest = null;
            }
            return content; ;
        }
        */

    }
}
