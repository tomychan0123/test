﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FileExpApp.Models
{
    /// <summary>
    /// 記錄檔案的資訊
    /// </summary>
    public class FileInf
    {
        public string id { get; set; }

        public string filename { get; set; }

        public string filesize { get; set; }

        public string filedate { get; set; }
    }
}