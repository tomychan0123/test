package com.xx.demog.domain;

import java.util.Date;

public class EventMail {
	// 郵件群組物件
	private MailGroup MailGroup;
	// 事件識別碼(FITSBOND_RCVESB: 接收到FITS評價電文)
	private String EventId;
	// 事件名稱(已接收FITS電文)
	private String EventName;
	// 事件的類別(FITSBOND:FITS債券評價流程)
	private String EventGroupId;
	// 郵件群組ID
	private String MailGroupId;	
	// 資料更新員工編號
	private String UpdateUserId;	
	// 資料更新員工姓名
	private String UpdateUserName;
	
	// 資料更新時間
	private Date UpdateDate;

	private String MailSubject;

	private String MailTemplate;

	private String IsBodyHtml;

	private String SysId;

	public MailGroup getMailGroup() {
		return MailGroup;
	}

	public void setMailGroup(MailGroup mailGroup) {
		MailGroup = mailGroup;
	}

	public String getEventId() {
		return EventId;
	}

	public void setEventId(String eventId) {
		EventId = eventId;
	}

	public String getEventName() {
		return EventName;
	}

	public void setEventName(String eventName) {
		EventName = eventName;
	}

	public String getEventGroupId() {
		return EventGroupId;
	}

	public void setEventGroupId(String eventGroupId) {
		EventGroupId = eventGroupId;
	}

	public String getMailGroupId() {
		return MailGroupId;
	}

	public void setMailGroupId(String mailGroupId) {
		MailGroupId = mailGroupId;
	}

	public Date getUpdateDate() {
		return UpdateDate;
	}

	public void setUpdateDate(Date updateDate) {
		UpdateDate = updateDate;
	}

	public String getMailSubject() {
		return MailSubject;
	}

	public void setMailSubject(String mailSubject) {
		MailSubject = mailSubject;
	}

	public String getMailTemplate() {
		return MailTemplate;
	}

	public void setMailTemplate(String mailTemplate) {
		MailTemplate = mailTemplate;
	}

	public String getIsBodyHtml() {
		return IsBodyHtml;
	}

	public void setIsBodyHtml(String isBodyHtml) {
		IsBodyHtml = isBodyHtml;
	}

	public String getSysId() {
		return SysId;
	}

	public void setSysId(String sysId) {
		SysId = sysId;
	}

	public String getUpdateUserId() {
		return UpdateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		UpdateUserId = updateUserId;
	}

	public String getUpdateUserName() {
		return UpdateUserName;
	}

	public void setUpdateUserName(String updateUserName) {
		UpdateUserName = updateUserName;
	}
	
	public boolean Equals(Object obj)
    {
        if (obj instanceof EventMail)
        {
            EventMail b = (EventMail) obj;
            if (b.MailGroupId != MailGroupId || b.EventId != EventId || b.EventGroupId != EventGroupId || b.SysId != SysId)
            {
                return false;
            }
            return true;
        }
        return false;
    }

    public int hashCode()
    {
        return ("" + EventId + EventGroupId + EventName + MailGroupId + SysId).hashCode();
    }
}
