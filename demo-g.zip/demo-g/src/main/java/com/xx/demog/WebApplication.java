package com.xx.demog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Configuration;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients(basePackages = { "com.xx.demog.service" })
//@EnableSpringDataWebSupport
//http://localhost:8888/hiSpringBoot/swagger-ui.html
public class WebApplication {
	
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(WebApplication.class);
	}
	
	public static void main(String[] args) throws Exception {
		SpringApplication.run(WebApplication.class, args);
	}
	
}



