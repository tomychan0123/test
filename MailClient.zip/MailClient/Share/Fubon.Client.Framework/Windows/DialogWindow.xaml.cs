﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Fubon.Client.Framework.Windows
{
    /// <summary>
    /// DialogWindow.xaml 的互動邏輯
    /// </summary>
    public partial class DialogWindow : Window, IDialog
    {
        public DialogWindow()
        {
            InitializeComponent();
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            Content = null;
            _BaseGrid.Children.Clear();
            _BaseGrid = null;
            _IsOpen = false;
        }

        protected override void OnPreviewKeyDown(KeyEventArgs e)
        {
            if (Keyboard.IsKeyDown(Key.F4) && (Keyboard.IsKeyDown(Key.RightAlt) || Keyboard.IsKeyDown(Key.LeftAlt)))
            {
                e.Handled = true;
                return;
            }
            base.OnPreviewKeyDown(e);
        }
        #region Private Member Varialbes
        private bool _IsOpen = false;
        private Grid _BaseGrid = null;
        #endregion

        #region IDialog Functions
        public void Show(object content)
        {
            if (!_IsOpen)
            {
                if (Open != null)
                    Open();

                _BaseGrid = new Grid();
                Grid maskGrid = new Grid();
                //maskGrid.Background = Brushes.Gray;
                //maskGrid.Opacity = 0.5;
                _BaseGrid.Children.Add(maskGrid);

                if (Owner == null)
                    WindowStartupLocation = WindowStartupLocation.CenterScreen;
                else
                {
                    _BaseGrid.Width = Owner.ActualWidth - 50;
                    _BaseGrid.Height = Owner.ActualHeight - 80;
                    WindowStartupLocation = WindowStartupLocation.CenterOwner;
                }
                if (content as UIElement != null)
                    _BaseGrid.Children.Add(content as UIElement);
                Content = _BaseGrid;

                _IsOpen = true;
                ShowDialog();
            }
            else
            {
            }
        }
        public bool IsOpened { get { return _IsOpen; } }
        public event Action Open;
        #endregion
    }
}
