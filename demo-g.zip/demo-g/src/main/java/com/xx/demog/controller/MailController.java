package com.xx.demog.controller;

import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.xx.demog.domain.EventMail;
import com.xx.demog.domain.MailGroup;
import com.xx.demog.domain.MailInfo;
import com.xx.demog.service.MailService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Api(tags = "Mail")
@RestController
@RequestMapping(value = "/api")
public class MailController {
	@Autowired
	private MailService mailService;
	
	@ApiOperation(value = "取得群組Mail List", notes = "取得群組Mail List")
	@ResponseStatus(HttpStatus.OK)
    @GetMapping(value = "/mail/{groupId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public List <MailGroup>GetMailGroupList(@ApiParam(required = true, name = "groupId", value = "群組id") @PathVariable String groupId) {
		return mailService.GetMailGroupList(groupId);
	}
	@ApiOperation(value = "取得該id的Mail List", notes = "取得該id的Mail List")
	public List<MailInfo> selectMailInfoById(long id) {
		return mailService.selectMailInfoById(id);
	}
	@ApiOperation(value = "取得該id的Mail List", notes = "取得該id的Mail List")
	public List<MailInfo> GetCanaddUserList(String groupId) {
		return mailService.GetCanaddUserList(groupId);
	}
	@ApiOperation(value = "查可加入的人員", notes = "查可加入的人員")
	public boolean InsertMailGroup(MailGroup mailgroupdata) {
		return mailService.InsertMailGroup(mailgroupdata);
	}
	@ApiOperation(value = "更新MailGroup", notes = "更新MailGroup")
	public boolean UpdateMailGroup(MailGroup mailgroupdata) {
		return mailService.UpdateMailGroup(mailgroupdata);
	}
	@ApiOperation(value = "刪除MailGroup", notes = "刪除MailGroup")
	public boolean DeleteMailGroup(MailGroup mailgroupdata) {
		return mailService.DeleteMailGroup(mailgroupdata);
	}
	@ApiOperation(value = "新增MailGroup資料", notes = "新增MailGroup資料")
	public boolean InsertMailGroupItem(MailInfo maildata) {
		return mailService.InsertMailGroupItem(maildata);
	}
	@ApiOperation(value = "刪除MailGroup資料", notes = "刪除MailGroup資料")
	public boolean DeleteGroupItem(MailInfo maildata) {
		return mailService.DeleteGroupItem(maildata);
	}
	@ApiOperation(value = "依MailId刪除MailGroup資料", notes = "依MailId刪除MailGroup資料")
	public boolean DeleteGroupItemByMailId(MailInfo maildata) {
		return mailService.DeleteGroupItemByMailId(maildata);
	}
	@ApiOperation(value = "新增Mail資料", notes = "新增Mail資料")
	public boolean InsertMail(MailInfo mailuserdata) {
		return mailService.InsertMail(mailuserdata);
	}
	@ApiOperation(value = "修改Mail資料", notes = "修改Mail資料")
	public boolean UpdateMail(MailInfo mailuserdata) {
		return mailService.UpdateMail(mailuserdata);
	}
	@ApiOperation(value = "刪除Mail資料", notes = "刪除Mail資料")
	public boolean DeleteMail(MailInfo mailuserdata) {
		return mailService.DeleteMail(mailuserdata);
	}
	@ApiOperation(value = "依eventGroupId取得EventMail資料", notes = "依eventGroupId取得EventMail資料")
	public List<EventMail> GetEventMailList(String eventGroupId) {
		return mailService.GetEventMailList(eventGroupId);
	}
	@ApiOperation(value = "依eventMailList修改EventMail資料", notes = "依eventMailList修改EventMail資料")
	public int UpdateEventMailList(List<EventMail> eventMailList) {
		return mailService.UpdateEventMailList(eventMailList);
	}
	@ApiOperation(value = "依eventId傳送Mail", notes = "依eventId傳送Mail")
	public boolean SendMailByEventId(String sysId, String eventId, String subject, String message, String fileName, ByteArrayInputStream attachments) {
		return mailService.SendMailByEventId(sysId, eventId, subject, message, fileName, attachments);
	}
	@ApiOperation(value = "依eventIdTemplate傳送Mail", notes = "依eventIdTemplate傳送Mail")
	public boolean SendMailByEventIdTemplate(String sysId, String eventId, String subject, HashMap<String, Object> attrs, String fileName, ByteArrayInputStream attachments) {
		return mailService.SendMailByEventIdTemplate(sysId, eventId, subject, attrs, fileName, attachments);
	}
	@ApiOperation(value = "依eventId與指定收件人傳送Mail", notes = "依eventId與指定收件人傳送Mail")
	public boolean SendMailByEventIdAndReceiver(String sysId, String eventId, String fileName, ByteArrayInputStream attachments, String receiver) {
		return mailService.SendMailByEventIdAndReceiver(sysId, eventId, fileName, attachments, receiver);
	}
	@ApiOperation(value = "依eventId與指定收件人/送件人傳送Mail", notes = "依eventId與指定收件人/送件人傳送Mail")
	public boolean SendMailByEventIdWithReceiverAndSender(String sysId, String eventId, String subject, String message, String fileName, ByteArrayInputStream attachments, String receiver, String sender) {
		return mailService.SendMailByEventIdWithReceiverAndSender(sysId, eventId, subject, message, fileName, attachments, receiver, sender);
	}
	@ApiOperation(value = "依eventIdTemplate與指定收件人傳送Mail", notes = "依eventIdTemplate與指定收件人傳送Mail")
	public boolean SendMailByEventIdTemplateWithReceiver(String sysId, String eventId, String subject, HashMap<String, Object> attrs, String fileName, ByteArrayInputStream attachments, String receiver) {
		return mailService.SendMailByEventIdTemplateWithReceiver(sysId, eventId, subject, attrs, fileName, attachments, receiver);
	}
	@ApiOperation(value = "依eventIdTemplate與指定收件人/送件人傳送Mail", notes = "依eventIdTemplate與指定收件人/送件人傳送Mail")
	public boolean SendMailByEventIdTemplateWithReceiverAndSender(String sysId, String eventId, String subject, HashMap<String, Object> attrs, String fileName, ByteArrayInputStream attachments, String receiver, String sender) {
		return mailService.SendMailByEventIdTemplateWithReceiverAndSender(sysId, eventId, subject, attrs, fileName, attachments, receiver, sender);
	}
	@ApiOperation(value = "依eventId與指定收件人/送件人傳送Mail", notes = "依eventId與指定收件人/送件人傳送Mail")
	public boolean SendMailByEventIdAndReceiverAndSender(String sysId, String eventId, String fileName, ByteArrayInputStream attachments, String receiver, String sender) {
		return mailService.SendMailByEventIdAndReceiverAndSender(sysId, eventId, fileName, attachments, receiver, sender);
	}
	@ApiOperation(value = "依eventId與指定送件人傳送Mail", notes = "依eventId與指定送件人傳送Mail")
	public boolean SendMailByEventIdAndSender(String sysId, String eventId, String fileName, ByteArrayInputStream attachments, String sender) {
		return mailService.SendMailByEventIdAndSender(sysId, eventId, fileName, attachments, sender);
	}
	@ApiOperation(value = "依eventIdTemplate與指定送件人傳送Mail", notes = "依eventIdTemplate與指定送件人傳送Mail")
	public boolean SendMailByEventIdTemplateWithSender(String sysId, String eventId, String subject, HashMap<String, Object> attrs, String fileName, ByteArrayInputStream attachments, String sender) {
		return mailService.SendMailByEventIdTemplateWithSender(sysId, eventId, subject, attrs, fileName, attachments, sender);
	}
	@ApiOperation(value = "依eventId與指定送件人傳送Mail", notes = "依eventId與指定送件人傳送Mail")
	public boolean SendMailByEventIdWithSender(String sysId, String eventId, String subject, String message, String fileName, ByteArrayInputStream attachments, String sender) {
		return mailService.SendMailByEventIdWithSender(sysId, eventId, subject, message, fileName, attachments, sender);
	}
}
