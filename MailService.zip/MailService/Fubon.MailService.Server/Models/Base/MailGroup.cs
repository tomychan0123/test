﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fubon.MailService.Server.Models.Base
{
    /// <summary>
    /// 儲存郵件郡組資訊的類別
    /// </summary>
    public class MailGroup : AbstractHistoricalModel
    {
        /// <summary>
        /// 郵件群組ID
        /// </summary>
        public string GroupId { get; set; }

        /// <summary>
        /// 郵件群組名稱
        /// </summary>
        public string GroupName { get; set; }

        /// <summary>
        /// 郵件內容清單
        /// </summary>
        public List<MailInfo> MailList { get; set; }
    }
}
