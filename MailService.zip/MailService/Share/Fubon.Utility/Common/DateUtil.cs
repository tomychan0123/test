﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fubon.Utility.Common
{
    public class DateUtil
    {
        public static string FORMAT_STANDARD_SHORT = "yyyy/MM/dd";
        public static string FORMAT_STANDARD_PUBLIC = "yyyyMMdd";

        public static string ToStandardShortString(DateTime datetime)
        {
            if (datetime == null)
                return "";
            return datetime.ToString(FORMAT_STANDARD_SHORT);
        }

        //西元年轉民國年 
        public static string ToStandardTaiwanShortString(DateTime datetime)
        {
            System.Globalization.TaiwanCalendar taiwanCalendar = new System.Globalization.TaiwanCalendar();

            return string.Format("{0}/{1:00}/{2:00}",
                taiwanCalendar.GetYear(datetime),
                datetime.Month,
                datetime.Day);
        }


        //西元年轉民國年 
        public static string ToStandardTaiwanShortString(DateTime datetime, string format)
        {
            System.Globalization.TaiwanCalendar taiwanCalendar = new System.Globalization.TaiwanCalendar();

            //"{0:0000}/{1:00}/{2:00}"
            return string.Format(format, taiwanCalendar.GetYear(datetime), datetime.Month, datetime.Day);
        }
 
        //民國年轉西元年
        public static DateTime TaiwanCalendarStringToDate(string dateString)
        {
            string chDate = dateString.PadLeft(8, '0');
            System.Globalization.CultureInfo tc = new System.Globalization.CultureInfo("zh-TW");
            tc.DateTimeFormat.Calendar = new System.Globalization.TaiwanCalendar();
            return DateTime.ParseExact(chDate, FORMAT_STANDARD_PUBLIC, tc);
        }




    }
}
