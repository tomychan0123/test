﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using log4net;
using FileExpApp.IO;

namespace FileExpApp.Models
{
    public class FileToolKits
    {
        private static ILog _log = LogManager.GetLogger(typeof(FileToolKits));
        private static string rootPath =  System.Configuration.ConfigurationManager.AppSettings["FolderRoot"];
        private static readonly IEnumerable<DirectoryInfo> EmptyDirectoryInfos = new List<DirectoryInfo>();
        /// <summary>
        /// 取得web.config設定目錄下的所有目錄
        /// </summary>
        /// <returns></returns>
        public static FileDir GetDirs()
        {
            DateTime st_dt = DateTime.Now;
            TimeSpan st_st = new TimeSpan(st_dt.Ticks);
            _log.Error("GetDirs()開始時間 " + st_st.Hours.ToString() + ":" + st_st.Minutes.ToString() + ":" + st_st.Seconds.ToString());
            System.IO.DirectoryInfo root = new System.IO.DirectoryInfo(rootPath);



            FileDir rootFileDir = new FileDir();
            rootFileDir.text = root.Name;
            rootFileDir.id = rootPath;
            //_log.Error("rootFileDir.id=" + rootPath);
            rootFileDir.children = new List<FileDir>();
            SearchFileFolders(ref rootFileDir);
            FileDir rootDot = new FileDir();
            rootDot.text = "root";
            rootDot.id = "root";
            rootDot.children = new List<FileDir>();
            rootDot.children.Add(rootFileDir);
            DateTime curr_dt = DateTime.Now;
            TimeSpan curr_dts = new TimeSpan(st_dt.Ticks);
            TimeSpan diff_st = new TimeSpan(curr_dt.Ticks - st_dt.Ticks);
            _log.Error("GetDirs()結束時間 " + curr_dts.Hours.ToString() + ":" + curr_dts.Minutes.ToString() + ":" + curr_dts.Seconds.ToString());
            _log.Error("GetDirs()經過時間 " + diff_st.Hours.ToString() + ":" + diff_st.Minutes.ToString() + ":" + diff_st.Seconds.ToString());
            return rootDot;
        }


        /// <summary>
        /// 依傳入的目錄，往下找目錄
        /// </summary>
        /// <param name="parentFileDir"></param>
        public static void SearchFileFolders(ref FileDir parentFileDir){
            DirectoryInfo dirI = new DirectoryInfo(parentFileDir.id);
            bool ignoreError = true;

            System.IO.DirectoryInfo parentDir = new System.IO.DirectoryInfo(parentFileDir.id);
            try
            {
                //if ((File.GetAttributes(parentFileDir.ToString()) & FileAttributes.ReparsePoint) != FileAttributes.ReparsePoint)
                //{
                    //DirectoryInfo[] dirs = parentDir.GetDirectories();
                //List<string> dirs = new List<string>(Directory.EnumerateDirectories(parentFileDir.id));
                //SearchFileFolders(ref rootFileDir);
                IEnumerable<FileSystemInfo> liste = dirI.EnumerateDirectories(SearchOption.TopDirectoryOnly, (d, ex) => ignoreError);
                _log.Error("parentFileDir.id="+parentFileDir.id+" liste count=" + liste.Count());
                var dirs = liste.ToList();
                    _log.Error("SearchFileFolders parentFileDir.id=" + parentFileDir.id + " dirs count=" + dirs.Count());
                parentFileDir.leaf = (dirs.Count() == 0);
                    foreach (var dir in dirs)//parentDir.EnumerateDirectories("*")
                    {
                        FileDir subFileDir = new FileDir();
                        subFileDir.text = dir.Name;
                        _log.Error("dir.name=" + dir.Name);
                        subFileDir.id = Path.Combine(parentFileDir.id, dir.Name);
                        subFileDir.children = new List<FileDir>();
                        parentFileDir.children.Add(subFileDir);
                        SearchFileFolders(ref subFileDir);
                    }
                //}
            }
            catch (Exception e)
            {
                _log.Error("SearchFileFolders parentFileDir.id="+parentFileDir.id+ " e="+e.Message);
                _log.Error(e.StackTrace);
                //parentFileDir.leaf = true;
                //parentFileDir.children.Add(null);
            }
        }

        /// <summary>
        /// 依傳入的目錄，往下找目錄
        /// </summary>
        /// <param name="parentFileDir"></param>
        public static List<FileContent> SearchFolders(string folderId)
        {
            List<FileContent> result = new List<FileContent>(); 

            DirectoryInfo dirI = new DirectoryInfo(folderId);
            bool ignoreError = true;

            System.IO.DirectoryInfo parentDir = new System.IO.DirectoryInfo(folderId);
            try
            {
                IEnumerable<FileSystemInfo> liste = dirI.EnumerateDirectories(SearchOption.TopDirectoryOnly, (d, ex) => ignoreError);
                _log.Error("folderId=" + folderId + " liste count=" + liste.Count());
                var dirs = liste.ToList();
                _log.Error("SearchFolders folderId=" + folderId + " dirs count=" + dirs.Count());

                if (!folderId.Equals("C:\\") && !folderId.Equals("D:\\") && !folderId.Equals("E:\\") && !folderId.Equals("F:\\"))
                {
                    FileContent pDir = new FileContent();
                    pDir.folderPath = folderId;
                    pDir.filename = "..";
                    pDir.filenameX = "[..]";
                    pDir.is_dir = true;
                    result.Add(pDir);
                }

                foreach (var dir in dirs)//parentDir.EnumerateDirectories("*")
                {
                    FileContent subDir = new FileContent();
                    subDir.id = Path.Combine(folderId, dir.Name);
                    subDir.folderPath = folderId;
                    subDir.filename = dir.Name;
                    subDir.filenameX = "["+dir.Name+"]";
                    subDir.is_dir = true;
                    result.Add(subDir);
                }
            }
            catch (Exception e)
            {
                _log.Error("SearchFolders folderId=" + folderId + " e=" + e.Message);
                _log.Error(e.StackTrace);
            }
            return result;
        }

        /// <summary>
        /// 取得目錄中的檔案
        /// </summary>
        /// <param name="folderPath"></param>
        /// <returns></returns>
        public static List<FileInf> GetFilesByFolderName(string folderPath)
        {
            DirectoryInfo dir = new DirectoryInfo(folderPath);
            bool ignoreError = true;

            if (string.IsNullOrEmpty(folderPath))
                folderPath = rootPath;
            List<FileInf> files = new List<FileInf>();
            try
            {
                IEnumerable<FileSystemInfo> liste = dir.EnumerateFiles(SearchOption.TopDirectoryOnly, (d, ex) => ignoreError);
                foreach (FileInfo f in liste)//new DirectoryInfo(folderPath).EnumerateFiles()
                {
                    try
                    {
                        FileInf fi = new FileInf();
                        fi.id = f.FullName; //Path.Combine(folderPath, f.Name);
                        fi.filename = f.Name;
                        fi.filedate = f.LastWriteTime.ToString("yyyy/MM/dd HH:mm:ss");
                        fi.filesize = GetFileSizeString(f.Length);
                        files.Add(fi);
                    }
                    catch (IOException e)
                    {
                        _log.Error("GetFilesByFolderName folderPath=" + folderPath + " e:" + e.Message);
                        _log.Error(e.StackTrace);
                        return null;
                    }
                }
            }
            catch (Exception e)
            {
                _log.Error("GetFilesByFolderName folderPath=" + folderPath + " e:" + e.Message);
                _log.Error(e.StackTrace);
                return null;
            }
            return files;
        }

        /// <summary>
        /// 取得目錄中的檔案
        /// </summary>
        /// <param name="folderPath"></param>
        /// <returns></returns>
        public static List<FileContent> GetFiles(string folderId)
        {
            DirectoryInfo dir = new DirectoryInfo(folderId);
            bool ignoreError = true;

            List<FileContent> files = new List<FileContent>();
            try
            {
                IEnumerable<FileSystemInfo> liste = dir.EnumerateFiles(SearchOption.TopDirectoryOnly, (d, ex) => ignoreError);
                foreach (FileInfo f in liste)//new DirectoryInfo(folderPath).EnumerateFiles()
                {
                    try
                    {
                        FileContent fi = new FileContent();
                        fi.folderPath = folderId;
                        fi.id = f.FullName;
                        fi.filename = f.Name;
                        fi.filenameX = f.Name;
                        fi.filedate = f.LastWriteTime.ToString("yyyy/MM/dd HH:mm:ss");
                        fi.filesize = GetFileSizeString(f.Length);
                        files.Add(fi);
                    }
                    catch (IOException e)
                    {
                        _log.Error("GetFiles folderId=" + folderId + " e:" + e.Message);
                        _log.Error(e.StackTrace);
                        return null;
                    }
                }
            }
            catch (Exception e)
            {
                _log.Error("GetFiles folderId=" + folderId + " e:" + e.Message);
                _log.Error(e.StackTrace);
                return null;
            }
            return files;
        }

        /// <summary>
        /// 取得web.config設定目錄下的所有目錄
        /// </summary>
        /// <returns></returns>
        public static List<FileContent>GetDisks(string folderId)
        {
            DateTime st_dt = DateTime.Now;
            TimeSpan st_st = new TimeSpan(st_dt.Ticks);
            _log.Error("GetDisks("+folderId+")開始時間 " + st_st.Hours.ToString() + ":" + st_st.Minutes.ToString() + ":" + st_st.Seconds.ToString());
            _log.Error("folderId=" + folderId);
            if (string.IsNullOrEmpty(folderId))
                folderId = rootPath;// "D:\\FMG_APP\\";

            if (folderId.Contains(".."))
                folderId = System.IO.Directory.GetParent(System.IO.Path.GetDirectoryName(folderId)).FullName;

            _log.Error("folderId=" + folderId);
            List<FileContent> files = new List<FileContent>();

            string[] drives = System.Environment.GetLogicalDrives();
            foreach (string dr in drives)
            {
                System.IO.DriveInfo di = new System.IO.DriveInfo(dr);
                FileContent fi = new FileContent();                

                // Here we skip the drive if it is not ready to be read. This
                // is not necessarily the appropriate action in all scenarios.
                if (!di.IsReady)
                {
                    //Console.WriteLine("The drive {0} could not be read", di.Name);
                    continue;
                }
                System.IO.DirectoryInfo rootDir = di.RootDirectory;
                fi.folderPath = "";// rootDir.ToString();
                fi.filename = rootDir.ToString();
                fi.filenameX = "["+rootDir.ToString()+"]";
                fi.is_dir = true;
                files.Add(fi);
            }
            _log.Error("files DriveInfo Count=" + files.Count());

            List<FileContent> subFolders = SearchFolders(folderId);
            files.AddRange(subFolders);
            _log.Error("files SearchFolders Count=" + subFolders.Count());

            List<FileContent> subFoldersFiles = GetFiles(folderId);
            files.AddRange(subFoldersFiles);
            _log.Error("files GetFiles Count=" + subFoldersFiles.Count());

            _log.Error("files Count=" + files.Count());

            DateTime curr_dt = DateTime.Now;
            TimeSpan curr_dts = new TimeSpan(st_dt.Ticks);
            TimeSpan diff_st = new TimeSpan(curr_dt.Ticks - st_dt.Ticks);
            _log.Error("GetDisks(" + folderId + ")結束時間 " + curr_dts.Hours.ToString() + ":" + curr_dts.Minutes.ToString() + ":" + curr_dts.Seconds.ToString());
            _log.Error("GetDisks(" + folderId + ")經過時間 " + diff_st.Hours.ToString() + ":" + diff_st.Minutes.ToString() + ":" + diff_st.Seconds.ToString());
            return files;
        }

        /// <summary>
        /// 依檔案Size大小Format
        /// </summary>
        /// <param name="fileSize"></param>
        /// <returns></returns>
        public static string GetFileSizeString(double fileSize)
        {
            string[] sizes = { "B", "KB", "MB", "GB" };
            double len = fileSize;
            int order = 0;
            while (len >= 1024 && order + 1 < sizes.Length)
            {
                order++;
                len = len / 1024;
            }
            return string.Format("{0:0.##} {1}", len, sizes[order]);
        }
    }
}