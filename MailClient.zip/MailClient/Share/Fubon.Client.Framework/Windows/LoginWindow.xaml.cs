﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Fubon.Client.Framework.Windows
{
    /// <summary>
    /// LoginWindow.xaml 的互動邏輯
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(LoginWindow_Loaded);
        }

        private void LoginWindow_Loaded(object sender, RoutedEventArgs e)
        {
            EMailBox.Focus();
        }

        private void OnKeyUp(object sender, KeyEventArgs e)
        {
            if (sender == EMailBox && EMailBox.Text.Trim() != "" && e.Key == Key.Enter)
            {
                txtPassword.Focus();
            }
            else if (sender == txtPassword && txtPassword.Password.Trim() != "" && e.Key == Key.Enter)
            {
                Application.Current.Dispatcher.BeginInvoke(new Action(() =>
                {
                    LoginButton.Command.Execute(txtPassword);
                }));
            }
        }


    }
}
