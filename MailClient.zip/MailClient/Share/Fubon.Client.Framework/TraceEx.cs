﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Reflection;

namespace Fubon.Client.Framework
{
    public static class TraceEx
    {
        static private TraceSwitch _traceSwitch = null;

        static TraceEx()
        {
            _traceSwitch = new TraceSwitch("FubonTraceSwitch", "Fubon Client Trace");
        }
        private static int GetAppSettingsInt(string key, int defaultValue)
        {
            if (ConfigurationManager.AppSettings[key] == null)
                return defaultValue;
            else
                return Convert.ToInt32(ConfigurationManager.AppSettings[key]);
        }
        static public void WriteError(string message)
        {
            Trace.WriteLineIf(_traceSwitch.TraceError, "Error:" + message);
        }
        static public void WriteError(string message, string category)
        {
            Trace.WriteLineIf(_traceSwitch.TraceError, "Error:" + message, category);
        }
        static public void WriteInfo(string message)
        {
            Trace.WriteLineIf(_traceSwitch.TraceInfo, "Info:" + message);
        }
        static public void WriteInfo(string message, string category)
        {
            Trace.WriteLineIf(_traceSwitch.TraceInfo, "Info:" + message, category);
        }
        static public void WriteWarning(string message)
        {
            Trace.WriteLineIf(_traceSwitch.TraceWarning, "Warning:" + message);
        }
        static public void WriteWarning(string message, string category)
        {
            Trace.WriteLineIf(_traceSwitch.TraceWarning, "Warning:" + message, category);
        }
        static public void WriteLine(string message)
        {
            Trace.WriteLineIf(_traceSwitch.TraceVerbose, message);
        }
        static public void WriteLine(string message, string category)
        {
            Trace.WriteLineIf(_traceSwitch.TraceVerbose, message, category);
        }
        static public void WriteLine(Exception ex, string category)
        {
            WriteLine(ex.Message, category);
            if (ex.InnerException != null)
                WriteLine(ex.InnerException, category);
        }
    }
}
