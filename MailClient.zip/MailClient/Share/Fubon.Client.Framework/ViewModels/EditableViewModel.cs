﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fubon.Client.Framework.ViewModels
{
    public abstract class EditableViewModel : BaseViewModel
    {
        protected EditMode _editMode;
        private bool _primaryFieldEditable = false;
        private bool _isView = true;
        private bool _isModify = false;
        private bool _isCreate = false;

        //控制 button 
        private bool _isYesBottonVisible = false;
        private bool _isNoBottonVisible = false;

        public EditMode EditMode
        {
            get { return _editMode; }
            set
            {
                _editMode = value;

                switch (_editMode)
                {
                    case EditMode.Create:
                        PrimaryFieldEditable = true;
                        IsModify = true;
                        IsCreate = true;
                        IsView = false;
                        IsYesBottonVisible = true;
                        break;
                    case EditMode.Copy:
                        PrimaryFieldEditable = true;
                        IsModify = true;
                        IsCreate = true;
                        IsView = false;
                        IsYesBottonVisible = true;
                        break;
                    case EditMode.Modify:
                        PrimaryFieldEditable = false;
                        IsModify = true;
                        IsCreate = false;
                        IsView = false;
                        IsYesBottonVisible = true;
                        break;
                    case EditMode.View:
                        IsView = true;
                        IsModify = false;
                        IsCreate = false;
                        PrimaryFieldEditable = false;
                        IsYesBottonVisible = false;
                        break;
                }
                IsNoBottonVisible = false;  //預設都關閉
            }
        }
        public bool PrimaryFieldEditable
        {
            get
            {
                return _primaryFieldEditable;
            }
            private set
            {
                _primaryFieldEditable = value;
                RaisePropertyChanged("PrimaryFieldEditable");
            }
        }
        public bool IsView
        {
            get
            {
                return _isView;
            }
            private set
            {
                _isView = value;
                RaisePropertyChanged("IsView");
            }
        }
        public bool IsModify
        {
            get
            {
                return _isModify;
            }
            private set
            {
                _isModify = value;
                RaisePropertyChanged("IsModify");
            }
        }
        public bool IsCreate
        {
            get
            {
                return _isCreate;
            }
            private set
            {
                _isCreate = value;
                RaisePropertyChanged("IsCreate");
            }
        }

        public bool IsYesBottonVisible
        {
            get
            {
                return _isYesBottonVisible;
            }
            set
            {
                _isYesBottonVisible = value;
                RaisePropertyChanged("IsYesBottonVisible");
            }
        }

        public bool IsNoBottonVisible
        {
            get
            {
                return _isNoBottonVisible;
            }
            set
            {
                _isNoBottonVisible = value;
                RaisePropertyChanged("IsNoBottonVisible");
            }
        }

        public abstract bool Validate();
    }
}
