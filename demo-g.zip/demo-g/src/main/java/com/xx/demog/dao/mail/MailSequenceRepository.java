package com.xx.demog.dao.mail;

import org.springframework.stereotype.Repository;

@Repository
public interface MailSequenceRepository {
	public String SelectNextSeqNo_GROUP(String groupId);
	
	public String SelectNextSeqNo_MAIL(String mailId);
}
