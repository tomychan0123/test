﻿using Fubon.Client.Framework.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace Fubon.Client.Framework.Views
{
    /// <summary>
    /// SimpleReportPage.xaml 的互動邏輯
    /// </summary>
    public partial class SimpleReportPage : AppView
    {
        public IAppService AppService { get; set; }
        public Function AppFunction { get; set; }

        public SimpleReportPage()
        {
            InitializeComponent();
        }

        public void InitPage()
        {
            String reportUrl = AppSettings.ReportURL + AppFunction.Param1;
            webBrowser.Navigate(reportUrl);
        }
    }
}
