﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using Fubon.Client.Framework;
using Fubon.Client.Framework.Widgets;

namespace Fubon.Client.Framework.ViewModels
{
    public class PageTabItemViewModel : BaseViewModel
    {
        private string _header;
        private string _pageId;
        private IAppPage _page;
        private IAppService _appService;


        public PageTabItemViewModel(string pageId, string name, IAppPage page, IAppService appService)
        {
            this._page = page;
            this._header = name;
            this._pageId = pageId;
            this._appService = appService;
            CloseCommand = new DelegateCommand(ClosePage, () => true);
        }

        public string Header
        {
            get
            {
                return _header;
            }
            set
            {
                _header = value;
                RaisePropertyChanged("Header");
            }
        }


        private void ClosePage()
        {
            _appService.ClosePage(_pageId);
        }

        public ICommand CloseCommand { get; set; }

        public IAppPage Page
        {
            get { return _page; }
        }
    }
}
