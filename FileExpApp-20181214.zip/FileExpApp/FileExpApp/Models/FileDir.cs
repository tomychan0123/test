﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FileExpApp.Models
{
    /// <summary>
    /// 記錄目錄的資訊
    /// </summary>
    public class FileDir
    {
        public string id { get; set; }
        public string text { get; set; }
        public bool leaf { get; set; }
        public List<FileDir> children { get; set; } 
    }
}