package com.xx.demog.util;
import java.net.InetAddress;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fubon.web.action.event.send.ImEventSender;
/**
 ###########################################################################
 #    PROGRAM NAME: NetTool.java
 #
 #    DESCRIPTION:
 #
 #    NOTES:
 #
 #    WRITEEN BY: kenny 2007/9/12
 #
 #    MODIFIED:
 #         kenny 2007/9/12 - Initial version. 
 #		   emilio 2009/7/6 - modified for Was   
 #         nick   2011/01/26 -[201101040437]增加傳送IM機制 
 ############################################################################
 */
public class NetTool {
	private static Logger logger = LoggerFactory.getLogger(NetTool.class);

    public static String getLocalHostIP() {
        String ip;
        try {
            InetAddress addr = InetAddress.getLocalHost();
            ip = addr.getHostAddress();
        } catch (Exception ex) {
            ip = "";
        }
        return ip;
    }

    public static String getLocalHostName() {
        String hostName;
        try {
            InetAddress addr = InetAddress.getLocalHost();
            hostName = addr.getHostName();
        } catch (Exception ex) {
            hostName = "";
        }
        return hostName;
    }

    public static String[] getAllLocalHostIP() {
        String[] ret = null;
        try {
            String hostName = getLocalHostName();
            if (hostName.length() > 0) {
                InetAddress[] addrs = InetAddress.getAllByName(hostName);
                if (addrs.length > 0) {
                    ret = new String[addrs.length];
                    for (int i = 0; i < addrs.length; i++) {
                        ret[i] = addrs[i].getHostAddress();
                    }
                }
            }

        } catch (Exception ex) {
            ret = null;
        }
        return ret;
    }

    public static String[] getAllHostIPByName(String hostName) {
        String[] ret = null;
        try {
            if (hostName.length() > 0) {
                InetAddress[] addrs = InetAddress.getAllByName(hostName);
                if (addrs.length > 0) {
                    ret = new String[addrs.length];
                    for (int i = 0; i < addrs.length; i++) {
                        ret[i] = addrs[i].getHostAddress();
                    }
                }
            }

        } catch (Exception ex) {
            ret = null;
        }
        return ret;
    }

    public static boolean isAllowIP() {
        String allowIPList = BaseUtil.getProperties("Job.AllowIP");
        boolean ret = false;

        String[] ipList = allowIPList.split(";");
        ArrayList<String> list = new ArrayList<String>();
        for (int i = 0; i < ipList.length; i++) {
            list.add(ipList[i]);
        }

        String[] localIP = getAllLocalHostIP();
        for (int i = 0; i < localIP.length; i++) {
            if (list.contains(localIP[i])) {
                ret = true;
                break;
            }
        }   
        logger.info("isAllowIP : " + ret);
        return ret;
    }
	/**
	 * 發送mail
	 * @param subSystem 子系統
	 * @param eventId 事件ID, 對應 IM_EVENT_DICTIONARY資料表 EVENTID欄位
	 * @param eventParam 事件簡述
	 * @param visibleFlag
	 * @return imResponse 成功(200)
	 */
    public static String sendMail( String subSystem, String eventId, String eventParam, String visibleFlag ) {
    	String imResponse = "";
    	try {
    		String imHost = BaseUtil.getProperties( "im.event.send.hostName" );
    		ImEventSender ImEventSender = new ImEventSender( imHost );
    		//ex: ImEventSender.send("ORP", "PFOLIO vs 板塊別對照失敗", "DB-ERR-0003", "ORP Murex Outstanding 匯入,無法對應PFOLIO至板塊別", "N");
			imResponse = ImEventSender.send( "BLK", subSystem, eventId, eventParam, visibleFlag );
		}
		catch ( Exception e ) {
			e.printStackTrace();
		}
		return imResponse;
    }
}
