﻿using log4net;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;

[assembly: log4net.Config.XmlConfigurator(ConfigFile = "app.log4net", Watch = true)]

namespace Fubon.MailService.Server
{
    public class Global : System.Web.HttpApplication
    {
        public static string MailHost { get; private set; }
        public static int MailPort { get; private set; }
        public static string AppMode { get; private set; }
        public static string MailFromUser { get; private set; }
        public static string AuthMode { get; private set; }
        public static string ConnectionString { get; set; }
        private static readonly ILog _log = LogManager.GetLogger(typeof(Global));

        protected void Application_Start(object sender, EventArgs e)
        {
            //Initial log4net
            //log4net.Config.XmlConfigurator.Configure();

            NameValueCollection appParams = (NameValueCollection)System.Configuration.ConfigurationManager.GetSection("app");
            AppMode = "prod";
            AuthMode = "none";
            if (appParams != null)
            {

                if (appParams["mail.host"] != null)
                {
                    MailHost = appParams["mail.host"];
                    _log.Debug("Mail Host is :" + MailHost);
                }
                MailPort = 25;
                if (appParams["mail.port"] != null)
                {
                    try
                    {
                        string mailPort = appParams["mail.port"];
                        MailPort = Convert.ToInt32(mailPort);
                    }
                    catch (Exception)
                    {
                    }
                }
                _log.Debug("Mail Host Port is :" + MailPort);


                if (appParams["app.mode"] != null)
                {
                    AppMode = appParams["app.mode"];
                }
                _log.Info("AppMode is :" + AppMode);

                if (appParams["mail.fromUser"] != null)
                {
                    MailFromUser = appParams["mail.fromUser"];
                }
                else
                {
                    MailFromUser = "ftsautosend.bank@fubon.com";
                }
                _log.Debug("Mail fromUser is :" + MailFromUser);
            }            
            _log.Info("AuthMode is :" + AuthMode);
        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}