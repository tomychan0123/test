package com.xx.demog.domain.mail;

import java.util.List;

public class MailGroup {
	// 郵件群組ID
	private String groupId;
	// 郵件群組名稱
	private String groupName;
	// 郵件內容清單
	private List<MailInfo> mailList;
	
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		groupId = groupId;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		groupName = groupName;
	}
	public List<MailInfo> getMailList() {
		return mailList;
	}
	public void setMailList(List<MailInfo> mailList) {
		this.mailList = mailList;
	}
}
