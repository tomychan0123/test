﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace Fubon.Client.Framework.Views
{
    public class AppView : ContentControl
    {
        #region Properties
        public static readonly DependencyProperty TitleProperty = DependencyProperty.Register("Title", typeof(string), typeof(AppView), new UIPropertyMetadata(null));
        public string Title
        {
            get
            {
                return (string)GetValue(TitleProperty);
            }
            set
            {
                SetValue(TitleProperty, value);
            }
        }
        public static readonly DependencyProperty FunctionCodeProperty = DependencyProperty.Register("FunctionCode", typeof(string), typeof(AppView), new UIPropertyMetadata(null));
        public string FunctionCode
        {
            get
            {
                return (string)GetValue(FunctionCodeProperty);
            }
            set
            {
                SetValue(FunctionCodeProperty, value);
            }
        }
        #endregion
    }
}
