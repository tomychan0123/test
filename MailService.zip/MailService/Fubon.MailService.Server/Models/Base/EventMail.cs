﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

namespace Fubon.MailService.Server.Models.Base
{
    /// <summary>
    /// 此類別用於記錄特定事件與發送郵件群組的關聯資訊
    /// </summary>
    public class EventMail
    {
        private MailGroup _mailGroup;
        /// <summary>
        /// 事件識別碼(FITSBOND_RCVESB: 接收到FITS評價電文)
        /// </summary>
        public string EventId { get; set; }

        /// <summary>
        /// 事件名稱(已接收FITS電文)
        /// </summary>
        public string EventName { get; set; }

        /// <summary>
        /// 事件的類別(FITSBOND:FITS債券評價流程)
        /// </summary>
        public string EventGroupId { get; set; }
        /// <summary>
        /// 郵件群組ID
        /// </summary>
        public string MailGroupId { get; set; }

        /// <summary>
        /// 郵件群組物件
        /// </summary>
        public MailGroup MailGroup
        {
            get { return _mailGroup; }
            set
            {
                this._mailGroup = value;
                if (_mailGroup == null)
                    MailGroupId = null;
                else
                    MailGroupId = _mailGroup.GroupId;
            }
        }

        /// <summary>
        /// 資料更新員工編號
        /// </summary>
        public string UpdateUserId { get; set; }

        /// <summary>
        /// 資料更新員工姓名
        /// </summary>
        public string UpdateUserName { get; set; }

        /// <summary>
        /// 資料更新時間
        /// </summary>
        public DateTime? UpdateDate { get; set; }

        public string MailSubject { get; set; }

        public string MailTemplate { get; set; }

        public string IsBodyHtml { get; set; }

        public string SysId { get; set; }

        public override bool Equals(object obj)
        {
            if (obj is EventMail)
            {
                EventMail b = obj as EventMail;
                if (b.MailGroupId != MailGroupId || b.EventId != EventId || b.EventGroupId != EventGroupId || b.SysId != SysId)
                {
                    return false;
                }
                return true;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return ("" + EventId + EventGroupId + EventName + MailGroupId + SysId).GetHashCode();
        }
    }
}
