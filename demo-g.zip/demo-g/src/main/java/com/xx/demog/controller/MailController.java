package com.xx.demog.controller;

import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.xx.demog.domain.EventMail;
import com.xx.demog.domain.MailGroup;
import com.xx.demog.domain.MailInfo;
import com.xx.demog.service.MailService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Api(tags = "Mail")
@RestController
@RequestMapping(value = "/mailService")
public class MailController {
	@Autowired
	private MailService mailService;
	
	@ApiOperation(value = "取得群組Mail List", notes = "取得群組Mail List")
	@ResponseStatus(HttpStatus.OK)
    @GetMapping(value = "/GetMailGroupList/{groupId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public List <MailGroup> GetMailGroupList(@ApiParam(required = true, name = "groupId", value = "群組id") @PathVariable String groupId) {
		return mailService.GetMailGroupList(groupId);
	}
	
	@GetMapping(value = "/selectMailInfoById/{id}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ApiOperation(value = "取得該id的Mail List", notes = "取得該id的Mail List")
	public List<MailInfo> selectMailInfoById(long id) {
		return mailService.selectMailInfoById(id);
	}
	
	@GetMapping(value = "/GetCanaddUserList/{groupId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ApiOperation(value = "取得該id的Mail List", notes = "取得該id的Mail List")
	public List<MailInfo> GetCanaddUserList(String groupId) {
		return mailService.GetCanaddUserList(groupId);
	}
	
	@RequestMapping(value = "/GetCanaddUserList/{mailgroupdata}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "查可加入的人員", notes = "查可加入的人員")
	public boolean InsertMailGroup(MailGroup mailgroupdata) {
		return mailService.InsertMailGroup(mailgroupdata);
	}
	
	@RequestMapping(value = "/UpdateMailGroup/{mailgroupdata}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "更新MailGroup", notes = "更新MailGroup")
	public boolean UpdateMailGroup(MailGroup mailgroupdata) {
		return mailService.UpdateMailGroup(mailgroupdata);
	}
	
	@DeleteMapping(value = "/DeleteMailGroup/{mailgroupdata}")
	@ApiOperation(value = "刪除MailGroup", notes = "刪除MailGroup")
	public boolean DeleteMailGroup(MailGroup mailgroupdata) {
		return mailService.DeleteMailGroup(mailgroupdata);
	}
	
	@RequestMapping(value = "/InsertMailGroupItem/{maildata}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "新增MailGroup資料", notes = "新增MailGroup資料")
	public boolean InsertMailGroupItem(MailInfo maildata) {
		return mailService.InsertMailGroupItem(maildata);
	}
	
	@DeleteMapping(value = "/DeleteGroupItem/{maildata}")
	@ApiOperation(value = "刪除MailGroup資料", notes = "刪除MailGroup資料")
	public boolean DeleteGroupItem(MailInfo maildata) {
		return mailService.DeleteGroupItem(maildata);
	}
	
	@DeleteMapping(value = "/DeleteGroupItemByMailId/{maildata}")
	@ApiOperation(value = "依MailId刪除MailGroup資料", notes = "依MailId刪除MailGroup資料")
	public boolean DeleteGroupItemByMailId(MailInfo maildata) {
		return mailService.DeleteGroupItemByMailId(maildata);
	}
	
	@RequestMapping(value = "/InsertMail/{mailuserdata}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "新增Mail資料", notes = "新增Mail資料")
	public boolean InsertMail(MailInfo mailuserdata) {
		return mailService.InsertMail(mailuserdata);
	}
	
	@RequestMapping(value = "/UpdateMail/{mailuserdata}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "修改Mail資料", notes = "修改Mail資料")
	public boolean UpdateMail(MailInfo mailuserdata) {
		return mailService.UpdateMail(mailuserdata);
	}
	
	@DeleteMapping(value = "/DeleteMail/{maildata}")
	@ApiOperation(value = "刪除Mail資料", notes = "刪除Mail資料")
	public boolean DeleteMail(MailInfo mailuserdata) {
		return mailService.DeleteMail(mailuserdata);
	}
	
	@RequestMapping(value = "/GetEventMailList/{eventGroupId}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "依eventGroupId取得EventMail資料", notes = "依eventGroupId取得EventMail資料")
	public List<EventMail> GetEventMailList(String eventGroupId) {
		return mailService.GetEventMailList(eventGroupId);
	}
	
	@RequestMapping(value = "/UpdateEventMailList/{eventMailList}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "依eventMailList修改EventMail資料", notes = "依eventMailList修改EventMail資料")
	public int UpdateEventMailList(List<EventMail> eventMailList) {
		return mailService.UpdateEventMailList(eventMailList);
	}
	
	@RequestMapping(value = "/SendMailByEventId", method=RequestMethod.GET)
	@ApiOperation(value = "依eventId傳送Mail", notes = "依eventId傳送Mail")
	public boolean SendMailByEventId(@RequestParam("sysId")String sysId, @RequestParam("sysId")String eventId, @RequestParam("subject")String subject, @RequestParam("message")String message, 
			@RequestParam("fileName")String fileName, @RequestParam("attachments")ByteArrayInputStream attachments) {
		return mailService.SendMailByEventId(sysId, eventId, subject, message, fileName, attachments);
	}
	
	@RequestMapping(value = "/SendMailByEventIdTemplate", method=RequestMethod.GET)
	@ApiOperation(value = "依eventIdTemplate傳送Mail", notes = "依eventIdTemplate傳送Mail")
	public boolean SendMailByEventIdTemplate(@RequestParam("sysId")String sysId, @RequestParam("eventId")String eventId, @RequestParam("subject")String subject, 
			@RequestParam("attrs")HashMap<String, Object> attrs, @RequestParam("fileName")String fileName, @RequestParam("attachments")ByteArrayInputStream attachments) {
		return mailService.SendMailByEventIdTemplate(sysId, eventId, subject, attrs, fileName, attachments);
	}
	
	@RequestMapping(value = "/SendMailByEventIdAndReceiver", method=RequestMethod.GET)
	@ApiOperation(value = "依eventId與指定收件人傳送Mail", notes = "依eventId與指定收件人傳送Mail")
	public boolean SendMailByEventIdAndReceiver(@RequestParam("sysId")String sysId, @RequestParam("eventId")String eventId, @RequestParam("fileName")String fileName, 
			@RequestParam("attachments")ByteArrayInputStream attachments, @RequestParam("receiver")String receiver) {
		return mailService.SendMailByEventIdAndReceiver(sysId, eventId, fileName, attachments, receiver);
	}
	
	@RequestMapping(value = "/SendMailByEventIdWithReceiverAndSender", method=RequestMethod.GET)
	@ApiOperation(value = "依eventId與指定收件人/送件人傳送Mail", notes = "依eventId與指定收件人/送件人傳送Mail")
	public boolean SendMailByEventIdWithReceiverAndSender(@RequestParam("sysId")String sysId, @RequestParam("eventId")String eventId, @RequestParam("subject")String subject, 
			@RequestParam("message")String message, @RequestParam("fileName")String fileName, @RequestParam("attachments")ByteArrayInputStream attachments, @RequestParam("receiver")String receiver, 
			@RequestParam("sender")String sender) {
		return mailService.SendMailByEventIdWithReceiverAndSender(sysId, eventId, subject, message, fileName, attachments, receiver, sender);
	}
	
	@RequestMapping(value = "/SendMailByEventIdTemplateWithReceiver", method=RequestMethod.GET)
	@ApiOperation(value = "依eventIdTemplate與指定收件人傳送Mail", notes = "依eventIdTemplate與指定收件人傳送Mail")
	public boolean SendMailByEventIdTemplateWithReceiver(@RequestParam("sysId")String sysId, @RequestParam("eventId")String eventId, @RequestParam("subject")String subject, 
			@RequestParam("attrs")HashMap<String, Object> attrs, @RequestParam("fileName")String fileName, @RequestParam("attachments")ByteArrayInputStream attachments, 
			@RequestParam("receiver")String receiver) {
		return mailService.SendMailByEventIdTemplateWithReceiver(sysId, eventId, subject, attrs, fileName, attachments, receiver);
	}
	
	@RequestMapping(value = "/SendMailByEventIdTemplateWithReceiverAndSender", method=RequestMethod.GET)
	@ApiOperation(value = "依eventIdTemplate與指定收件人/送件人傳送Mail", notes = "依eventIdTemplate與指定收件人/送件人傳送Mail")
	public boolean SendMailByEventIdTemplateWithReceiverAndSender(@RequestParam("sysId")String sysId, @RequestParam("eventId")String eventId, @RequestParam("subject")String subject, 
			@RequestParam("attrs")HashMap<String, Object> attrs, @RequestParam("fileName")String fileName, @RequestParam("attachments")ByteArrayInputStream attachments, 
			@RequestParam("receiver")String receiver, @RequestParam("sender")String sender) {
		return mailService.SendMailByEventIdTemplateWithReceiverAndSender(sysId, eventId, subject, attrs, fileName, attachments, receiver, sender);
	}
	
	@RequestMapping(value = "/SendMailByEventIdAndReceiverAndSender", method=RequestMethod.GET)
	@ApiOperation(value = "依eventId與指定收件人/送件人傳送Mail", notes = "依eventId與指定收件人/送件人傳送Mail")
	public boolean SendMailByEventIdAndReceiverAndSender(@RequestParam("sysId")String sysId, @RequestParam("eventId")String eventId, @RequestParam("fileName")String fileName, 
			@RequestParam("attachments")ByteArrayInputStream attachments, @RequestParam("receiver")String receiver, @RequestParam("sender")String sender) {
		return mailService.SendMailByEventIdAndReceiverAndSender(sysId, eventId, fileName, attachments, receiver, sender);
	}
	
	@RequestMapping(value = "/SendMailByEventIdAndSender", method=RequestMethod.GET)
	@ApiOperation(value = "依eventId與指定送件人傳送Mail", notes = "依eventId與指定送件人傳送Mail")
	public boolean SendMailByEventIdAndSender(@RequestParam("sysId")String sysId, @RequestParam("eventId")String eventId, @RequestParam("fileName")String fileName, 
			@RequestParam("attachments")ByteArrayInputStream attachments, @RequestParam("sender")String sender) {
		return mailService.SendMailByEventIdAndSender(sysId, eventId, fileName, attachments, sender);
	}
	
	@RequestMapping(value = "/SendMailByEventIdTemplateWithSender", method=RequestMethod.GET)
	@ApiOperation(value = "依eventIdTemplate與指定送件人傳送Mail", notes = "依eventIdTemplate與指定送件人傳送Mail")
	public boolean SendMailByEventIdTemplateWithSender(@RequestParam("sysId")String sysId, @RequestParam("eventId")String eventId, @RequestParam("subject")String subject, 
			@RequestParam("attrs")HashMap<String, Object> attrs, @RequestParam("fileName")String fileName, @RequestParam("attrs")ByteArrayInputStream attachments, 
			@RequestParam("sender")String sender) {
		return mailService.SendMailByEventIdTemplateWithSender(sysId, eventId, subject, attrs, fileName, attachments, sender);
	}
	
	@RequestMapping(value = "/SendMailByEventIdWithSender", method=RequestMethod.GET)
	@ApiOperation(value = "依eventId與指定送件人傳送Mail", notes = "依eventId與指定送件人傳送Mail")
	public boolean SendMailByEventIdWithSender(@RequestParam("sysId")String sysId, @RequestParam("eventId")String eventId, @RequestParam("subject")String subject, 
			@RequestParam("message")String message, @RequestParam("fileName")String fileName, @RequestParam("attachments")ByteArrayInputStream attachments, @RequestParam("sender")String sender) {
		return mailService.SendMailByEventIdWithSender(sysId, eventId, subject, message, fileName, attachments, sender);
	}
}
