﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Fubon.MailService.Server.Models.Base;

namespace Fubon.MailService.Server.Services
{
    // 注意: 您可以使用 [重構] 功能表上的 [重新命名] 命令同時變更程式碼和組態檔中的介面名稱 "ILog4NetLogService"。
    [ServiceContract]
    public interface ILog4NetLogService
    {
        /// <summary>
        /// 取得Log4NetLog清單
        /// </summary>
        [OperationContract]
        [FaultContract(typeof(Exception))]
        IList<Log4NetLog> GetLog4NetLogList(String logDate);
    }
}
