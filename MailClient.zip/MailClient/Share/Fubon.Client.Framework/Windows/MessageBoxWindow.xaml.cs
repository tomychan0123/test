﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Globalization;

namespace Fubon.Client.Framework.Windows
{   

    /// <summary>
    /// MessageBoxWindow.xaml 的互動邏輯
    /// </summary>
    public partial class MessageBoxWindow : Window, IMessageBox
    {
        static private ImageSource _warningImage = null;
        static private ImageSource _okImage = null;
        static private ImageSource _waitingImage = null;
        static private ImageSource _infoImage = null;
        static private ImageSource _questionImage = null;

        static void OnMessageBoxButtonChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            MessageBoxWindow messageBoxWindow = sender as MessageBoxWindow;
            if (messageBoxWindow.MessageBoxButton == MessageBoxButton.YesNoCancel)
            {
                Grid.SetColumn(messageBoxWindow.YesButton, 0);
                Grid.SetColumn(messageBoxWindow.NoButton, 1);
            }
            else
            {
                Grid.SetColumn(messageBoxWindow.YesButton, 1);
                Grid.SetColumn(messageBoxWindow.NoButton, 2);
            }
        }
        static void OnMessageBoxIconChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            MessageBoxWindow messageBoxWindow = sender as MessageBoxWindow;
            if (messageBoxWindow.MessageIcon == MessageBoxIcon.None)
            {
                messageBoxWindow.IconImage.Source = _infoImage;
            }
            else if (messageBoxWindow.MessageIcon == MessageBoxIcon.OK)
            {
                messageBoxWindow.IconImage.Source = _okImage;
            }
            else if (messageBoxWindow.MessageIcon == MessageBoxIcon.Waiting)
            {
                messageBoxWindow.IconImage.Source = _waitingImage;
            }
            else if (messageBoxWindow.MessageIcon == MessageBoxIcon.Question)
            {
                messageBoxWindow.IconImage.Source = _questionImage;
            }
            else if (messageBoxWindow.MessageIcon == MessageBoxIcon.Warning)
            {
                messageBoxWindow.IconImage.Source = _warningImage;
            }
            else
            {
                messageBoxWindow.IconImage.Source = _infoImage;
            }
        }

        static MessageBoxWindow()
        {
            _infoImage =
                new BitmapImage(new Uri("/Fubon.Client.Framework;component/Resources/Images/MsgIcon_Info.png", UriKind.RelativeOrAbsolute));
            _questionImage =
                new BitmapImage(new Uri("/Fubon.Client.Framework;component/Resources/Images/MsgIcon_Question.png", UriKind.RelativeOrAbsolute));
            _warningImage =
                new BitmapImage(new Uri("/Fubon.Client.Framework;component/Resources/Images/MsgIcon_Warning.png", UriKind.RelativeOrAbsolute));
            _okImage =
                new BitmapImage(new Uri("/Fubon.Client.Framework;component/Resources/Images/MsgIcon_OK.png", UriKind.RelativeOrAbsolute));
            _waitingImage =
                new BitmapImage(new Uri("/Fubon.Client.Framework;component/Resources/Images/MsgIcon_Wait.png", UriKind.RelativeOrAbsolute));

            MessageBoxButtonProperty =
                DependencyProperty.Register("MessageBoxButton", typeof(MessageBoxButton), typeof(MessageBoxWindow), new UIPropertyMetadata(MessageBoxButton.OK, OnMessageBoxButtonChanged));
            CaptionProperty =
                DependencyProperty.Register("Caption", typeof(string), typeof(MessageBoxWindow), new UIPropertyMetadata(string.Empty));
            MessageProperty =
                DependencyProperty.Register("Message", typeof(string), typeof(MessageBoxWindow), new UIPropertyMetadata(string.Empty));
            MessageIconProperty =
                DependencyProperty.Register("MessageIcon", typeof(MessageBoxIcon), typeof(MessageBoxWindow), new UIPropertyMetadata(MessageBoxIcon.None, OnMessageBoxIconChanged));
        }

        public MessageBoxWindow()
        {
            InitializeComponent();
        }

        #region Dependency Properties
        public static readonly DependencyProperty MessageBoxButtonProperty = null;
        public static readonly DependencyProperty CaptionProperty = null;
        public static readonly DependencyProperty MessageProperty = null;
        public static readonly DependencyProperty MessageIconProperty = null;
        #endregion

        #region Properties Accessors
        public MessageBoxButton MessageBoxButton
        {
            get { return (MessageBoxButton)GetValue(MessageBoxButtonProperty); }
            set { SetValue(MessageBoxButtonProperty, value); }
        }
        public string Caption
        {
            get { return (string)GetValue(CaptionProperty); }
            set { SetValue(CaptionProperty, value); }
        }
        public string Message
        {
            get { return (string)GetValue(MessageProperty); }
            set { SetValue(MessageProperty, value); }
        }
        public MessageBoxIcon MessageIcon
        {
            get { return (MessageBoxIcon)GetValue(MessageIconProperty); }
            set { SetValue(MessageIconProperty, value); }
        }
        #endregion

        #region Private Member Variables
        private bool _IsOpen = false;
        private MessageBoxResult _MessageBoxResult = MessageBoxResult.None;
        #endregion

        #region IMessageBox Functions
        public MessageBoxResult Show(string messageBoxText)
        {
            return Show(messageBoxText, string.Empty, MessageBoxButton.OK, MessageBoxIcon.None);
        }

        public MessageBoxResult Show(string messageBoxText, string caption)
        {
            return Show(messageBoxText, caption, MessageBoxButton.OK, MessageBoxIcon.None);
        }

        public MessageBoxResult Show(string messageBoxText, string caption, MessageBoxButton button)
        {
            return Show(messageBoxText, caption, button, MessageBoxIcon.None);
        }
        public MessageBoxResult Show(string messageBoxText, string caption, MessageBoxButton button, MessageBoxIcon icon)
        {
            Message = messageBoxText;
            Caption = caption;
            MessageBoxButton = button;
            MessageIcon = icon;
            if (!_IsOpen)
            {
                if (Open != null)
                    Open();

                if (Owner == null)
                    WindowStartupLocation = WindowStartupLocation.CenterScreen;
                else
                {
                    BaseGrid.Width = Owner.ActualWidth;
                    BaseGrid.Height = Owner.ActualHeight;
                    WindowStartupLocation = WindowStartupLocation.CenterOwner;
                }

                _IsOpen = true;
                ShowDialog();
            }
            else
            {
            }

            return _MessageBoxResult;
        }

        public void ChangeCaption(string newCaption)
        {
            Caption = newCaption;
        }

        public void ChangeMessageText(string newMessageBoxText)
        {
            Message = newMessageBoxText;
        }

        public void ChangeButton(MessageBoxButton newButton)
        {
            MessageBoxButton = newButton;
        }

        public void ChangeICon(MessageBoxIcon icon)
        {
            MessageIcon = icon;
        }

        public bool IsOpened { get { return _IsOpen; } }
        public event Action Open;
        #endregion

        #region Commands
        private ICommand _CloseCommand = null;
        public ICommand CloseCommand
        {
            get
            {
                if (_CloseCommand == null)
                    _CloseCommand = new DelegateCommand<MessageBoxResult>(ExecuteClose);
                return _CloseCommand;
            }
        }
        private void ExecuteClose(MessageBoxResult result)
        {
            _MessageBoxResult = result;
            Close();
            _IsOpen = false;
        }
        #endregion
    }
}
