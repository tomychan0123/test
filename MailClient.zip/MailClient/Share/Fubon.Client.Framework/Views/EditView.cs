﻿using Fubon.Client.Framework.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace Fubon.Client.Framework.Views
{
    public abstract class EditView : ContentControl
    {
        public abstract EditableViewModel ViewModel { get; }
    }
}
