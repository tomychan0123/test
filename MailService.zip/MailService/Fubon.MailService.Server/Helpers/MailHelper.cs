﻿using Fubon.MailService.Server;
using Fubon.MailService.Server.Models.Base;
using Fubon.Utility.Web;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;


namespace Fubon.Mdp.Server.Helpers
{
    public class MailHelper
    {
        private static ILog _log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public static bool SendMailByEventId(string sysId, string eventId, string subject, string message, string attachments)
        {
            Dictionary<string, string> map = new Dictionary<string, string>();
            map.Add("sysID", sysId);
            map.Add("eventId", eventId);
            try
            {
                EventMail eventMail = IBatisHelper.Get<EventMail>("Base.Mail.SelectEventMailByEventId", map);
                bool isBodyHtml = false;
                if (eventMail.IsBodyHtml != null && eventMail.IsBodyHtml.Equals("Y"))
                    isBodyHtml = true;
                else
                    isBodyHtml = false;
                _log.Error("EventId[" + eventId + "] isBodyHtml=" + isBodyHtml + " eventMail.IsBodyHtml=" + eventMail.IsBodyHtml);
                if (eventMail != null && eventMail.MailGroupId != null)
                {
                    IList<MailInfo> mails = IBatisHelper.QueryForList<MailInfo>("Base.Mail.SelectMailInfoByGroupId", eventMail.MailGroupId);
                    if (mails != null && mails.Count > 0)
                    {
                        string mailTo = "";
                        
                        foreach (MailInfo mi in mails)
                        {
                            if (mi.Email != null)
                            {
                                mailTo += mi.Email.Contains("@") ? mi.Email : mi.Email + "@fubon.com";
                                mailTo += ";";
                            }
                        }
                        return SendMail(eventId, mailTo, subject, message, attachments, isBodyHtml);
                    }
                    else
                    {
                        //if (_log.IsInfoEnabled)
                            _log.Error("EventId[" + eventId + "] 郵件群組[" + eventMail.MailGroupId + "]的郵件清單是空白.");
                        return false;
                    }

                }
                else
                {
                    //if (_log.IsInfoEnabled)
                        _log.Error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                    return false;
                }

            }
            catch (Exception e)
            {
                _log.Error("SendMailByEventId error", e);
            }
            return false;
        }

        public static bool SendMailByEventIdTemplate(string sysId, string eventId, string subject, Dictionary<string, object> attrs, string attachments)
        {
            Dictionary<string, string> map = new Dictionary<string, string>();
            map.Add("sysId", sysId);
            map.Add("eventId", eventId);
            try
            {
                EventMail eventMail = IBatisHelper.Get<EventMail>("Base.Mail.SelectEventMailFullByEventId", map);
                if (eventMail != null && eventMail.MailGroupId != null)
                {
                    IList<MailInfo> mails = IBatisHelper.QueryForList<MailInfo>("Base.Mail.SelectMailInfoByGroupId", eventMail.MailGroupId);
                    bool isBodyHtml = false;
                    if (eventMail.IsBodyHtml != null && eventMail.IsBodyHtml.Equals("Y"))
                        isBodyHtml = true;
                    else
                        isBodyHtml = false;
                    if (mails != null && mails.Count > 0)
                    {
                        string mailTo = "";
                        foreach (MailInfo mi in mails)
                        {
                            if (mi.Email != null)
                            {
                                mailTo += mi.Email.Contains("@") ? mi.Email : mi.Email + "@fubon.com";
                                mailTo += ";";
                            }
                        }
                        if (subject == null)
                            subject = eventMail.MailSubject;
                        string message = TemplateHelper.RenderTemplateByContent(eventMail.MailTemplate, attrs);
                        return SendMail(eventId, mailTo, subject, message, attachments, isBodyHtml);
                    }
                    else
                    {
                        //if (_log.IsInfoEnabled)
                            _log.Error("EventId[" + eventId + "] 郵件群組[" + eventMail.MailGroupId + "]的郵件清單是空白.");
                        return false;
                    }

                }
                else
                {
                    //if (_log.IsInfoEnabled)
                        _log.Error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                    return false;
                }
            }
            catch (Exception e)
            {
                _log.Error("SendMailByEventIdTemplate error", e);
            }
            return false;
        }

        public static bool SendMailByEventIdAndReceiver(string sysId, string eventId, string attachments, string receiver)
        {
            Dictionary<string, string> map = new Dictionary<string, string>();
            map.Add("sysId", sysId);
            map.Add("eventId", eventId);
            try
            {
                EventMail eventMail = IBatisHelper.Get<EventMail>("Base.Mail.SelectEventMailFullByEventId", map);
                if (eventMail != null && eventMail.MailGroupId != null)
                {
                    bool isBodyHtml = false;
                    if (eventMail.IsBodyHtml != null && eventMail.IsBodyHtml.Equals("Y"))
                        isBodyHtml = true;
                    else
                        isBodyHtml = false;
                    string mailTo = receiver;
                    string subject = eventMail.MailSubject;
                    string message = eventMail.MailTemplate;
                    return SendMail(eventId, mailTo, subject, message, attachments, isBodyHtml);
                }
                else
                {
                    //if (_log.IsInfoEnabled)
                    _log.Error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                    return false;
                }
            }
            catch (Exception e)
            {
                _log.Error("SendMailByEventIdAndReceiver error", e);
            }
            return false;
        }

        public static bool SendMailByEventIdWithReceiver(string sysId, string eventId, string subject, string message, string attachments, string receiver)
        {
            Dictionary<string, string> map = new Dictionary<string, string>();
            map.Add("sysId", sysId);
            map.Add("eventId", eventId);
            try
            {
                EventMail eventMail = IBatisHelper.Get<EventMail>("Base.Mail.SelectEventMailByEventId", map);
                bool isBodyHtml = false;
                if (eventMail.IsBodyHtml != null && eventMail.IsBodyHtml.Equals("Y"))
                    isBodyHtml = true;
                else
                    isBodyHtml = false;
                
                _log.Error("EventId[" + eventId + "] isBodyHtml=" + isBodyHtml + " eventMail.IsBodyHtml=" + eventMail.IsBodyHtml);
                if (eventMail != null && eventMail.MailGroupId != null)
                {
                    string mailTo = receiver;
                    return SendMail(eventId, mailTo, subject, message, attachments, isBodyHtml);
                }
                else
                {
                    //if (_log.IsInfoEnabled)
                    _log.Error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                    return false;
                }

            }
            catch (Exception e)
            {
                _log.Error("SendMailByEventIdWithReceiver error", e);
            }
            return false;
        }

        public static bool SendMailByEventIdWithReceiverAndSender(string sysId, string eventId, string subject, string message, string attachments, string receiver, string sender)
        {
            Dictionary<string, string> map = new Dictionary<string, string>();
            map.Add("sysId", sysId);
            map.Add("eventId", eventId);
            try
            {
                EventMail eventMail = IBatisHelper.Get<EventMail>("Base.Mail.SelectEventMailByEventId", map);
                bool isBodyHtml = false;
                if (eventMail.IsBodyHtml != null && eventMail.IsBodyHtml.Equals("Y"))
                    isBodyHtml = true;
                else
                    isBodyHtml = false;

                _log.Error("EventId[" + eventId + "] isBodyHtml=" + isBodyHtml + " eventMail.IsBodyHtml=" + eventMail.IsBodyHtml);
                if (eventMail != null && eventMail.MailGroupId != null)
                {
                    string mailTo = receiver;
                    return SendMailWithSender(eventId, mailTo, subject, message, attachments, isBodyHtml, sender);
                }
                else
                {
                    //if (_log.IsInfoEnabled)
                    _log.Error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                    return false;
                }

            }
            catch (Exception e)
            {
                _log.Error("SendMailByEventIdWithReceiverAndSender error", e);
            }
            return false;
        }

        public static bool SendMailByEventIdTemplateWithReceiver(string sysId, string eventId, string subject, Dictionary<string, object> attrs, string attachments, string receiver)
        {
            Dictionary<string, string> map = new Dictionary<string, string>();
            map.Add("sysId", sysId);
            map.Add("eventId", eventId);
            try
            {
                EventMail eventMail = IBatisHelper.Get<EventMail>("Base.Mail.SelectEventMailFullByEventId", map);
                if (eventMail != null && eventMail.MailGroupId != null)
                {
                    IList<MailInfo> mails = IBatisHelper.QueryForList<MailInfo>("Base.Mail.SelectMailInfoByGroupId", eventMail.MailGroupId);
                    bool isBodyHtml = false;
                    if (eventMail.IsBodyHtml != null && eventMail.IsBodyHtml.Equals("Y"))
                        isBodyHtml = true;
                    else
                        isBodyHtml = false;
                    string mailTo = receiver;
                    string message = TemplateHelper.RenderTemplateByContent(eventMail.MailTemplate, attrs);
                    return SendMail(eventId, mailTo, subject, message, attachments, isBodyHtml);
                }
                else
                {
                    //if (_log.IsInfoEnabled)
                    _log.Error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                    return false;
                }
            }
            catch (Exception e)
            {
                _log.Error("SendMailByEventIdTemplateWithReceiver error", e);
            }
            return false;
        }

        public static bool SendMailByEventIdTemplateWithReceiverAndSender(string sysId, string eventId, string subject, Dictionary<string, object> attrs, string attachments, string receiver, string sender)
        {
            Dictionary<string, string> map = new Dictionary<string, string>();
            map.Add("sysId", sysId);
            map.Add("eventId", eventId);
            try
            {
                EventMail eventMail = IBatisHelper.Get<EventMail>("Base.Mail.SelectEventMailFullByEventId", map);
                if (eventMail != null && eventMail.MailGroupId != null)
                {
                    IList<MailInfo> mails = IBatisHelper.QueryForList<MailInfo>("Base.Mail.SelectMailInfoByGroupId", eventMail.MailGroupId);
                    bool isBodyHtml = false;
                    if (eventMail.IsBodyHtml != null && eventMail.IsBodyHtml.Equals("Y"))
                        isBodyHtml = true;
                    else
                        isBodyHtml = false;
                    string mailTo = receiver;
                    string message = TemplateHelper.RenderTemplateByContent(eventMail.MailTemplate, attrs);
                    return SendMailWithSender(eventId, mailTo, subject, message, attachments, isBodyHtml, sender);
                }
                else
                {
                    //if (_log.IsInfoEnabled)
                    _log.Error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                    return false;
                }
            }
            catch (Exception e)
            {
                _log.Error("SendMailByEventIdTemplateWithReceiverAndSender error", e);
            }
            return false;
        }

        public static bool SendMailByEventIdAndReceiverAndSender(string sysId, string eventId, string attachments, string receiver, string sender)
        {
            Dictionary<string, string> map = new Dictionary<string, string>();
            map.Add("sysId", sysId);
            map.Add("eventId", eventId);
            try
            {
                EventMail eventMail = IBatisHelper.Get<EventMail>("Base.Mail.SelectEventMailFullByEventId", map);
                if (eventMail != null && eventMail.MailGroupId != null)
                {
                    bool isBodyHtml = false;
                    if (eventMail.IsBodyHtml != null && eventMail.IsBodyHtml.Equals("Y"))
                        isBodyHtml = true;
                    else
                        isBodyHtml = false;
                    string mailTo = receiver;
                    string subject = eventMail.MailSubject;
                    string message = eventMail.MailTemplate;
                    return SendMailWithSender(eventId, mailTo, subject, message, attachments, isBodyHtml, sender);
                }
                else
                {
                    //if (_log.IsInfoEnabled)
                    _log.Error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                    return false;
                }
            }
            catch (Exception e)
            {
                _log.Error("SendMailByEventIdAndReceiverAndSender error", e);
            }
            return false;
        }

        public static bool SendMailByEventIdAndSender(string sysId, string eventId, string attachments, string sender)
        {
            Dictionary<string, string> map = new Dictionary<string, string>();
            map.Add("sysId", sysId);
            map.Add("eventId", eventId);
            try
            {
                EventMail eventMail = IBatisHelper.Get<EventMail>("Base.Mail.SelectEventMailFullByEventId", map);
                if (eventMail != null && eventMail.MailGroupId != null)
                {
                    IList<MailInfo> mails = IBatisHelper.QueryForList<MailInfo>("Base.Mail.SelectMailInfoByGroupId", eventMail.MailGroupId);
                    bool isBodyHtml = false;
                    if (eventMail.IsBodyHtml != null && eventMail.IsBodyHtml.Equals("Y"))
                        isBodyHtml = true;
                    else
                        isBodyHtml = false;
                    if (mails != null && mails.Count > 0)
                    {
                        string mailTo = "";
                        foreach (MailInfo mi in mails)
                        {
                            if (mi.Email != null)
                            {
                                mailTo += mi.Email.Contains("@") ? mi.Email : mi.Email + "@fubon.com";
                                mailTo += ";";
                            }
                        }
                        string subject = eventMail.MailSubject;
                        string message = eventMail.MailTemplate;
                        return SendMailWithSender(eventId, mailTo, subject, message, attachments, isBodyHtml, sender);
                    }
                    else
                    {
                        //if (_log.IsInfoEnabled)
                        _log.Error("EventId[" + eventId + "] 郵件群組[" + eventMail.MailGroupId + "]的郵件清單是空白.");
                        return false;
                    }
                }
                else
                {
                    //if (_log.IsInfoEnabled)
                    _log.Error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                    return false;
                }
            }
            catch (Exception e)
            {
                _log.Error("SendMailByEventIdAndSender error", e);
            }
            return false;
        }

        public static bool SendMailByEventIdTemplateWithSender(string sysId, string eventId, string subject, Dictionary<string, object> attrs, string attachments, string sender)
        {
            Dictionary<string, string> map = new Dictionary<string, string>();
            map.Add("sysId", sysId);
            map.Add("eventId", eventId);
            try
            {
                EventMail eventMail = IBatisHelper.Get<EventMail>("Base.Mail.SelectEventMailFullByEventId", map);
                if (eventMail != null && eventMail.MailGroupId != null)
                {
                    IList<MailInfo> mails = IBatisHelper.QueryForList<MailInfo>("Base.Mail.SelectMailInfoByGroupId", eventMail.MailGroupId);
                    bool isBodyHtml = false;
                    if (eventMail.IsBodyHtml != null && eventMail.IsBodyHtml.Equals("Y"))
                        isBodyHtml = true;
                    else
                        isBodyHtml = false;

                    if (mails != null && mails.Count > 0)
                    {
                        string mailTo = "";
                        foreach (MailInfo mi in mails)
                        {
                            if (mi.Email != null)
                            {
                                mailTo += mi.Email.Contains("@") ? mi.Email : mi.Email + "@fubon.com";
                                mailTo += ";";
                            }
                        }
                        if (subject == null)
                            subject = eventMail.MailSubject;
                        string message = TemplateHelper.RenderTemplateByContent(eventMail.MailTemplate, attrs);
                        return SendMailWithSender(eventId, mailTo, subject, message, attachments, isBodyHtml, sender);
                    }
                    else
                    {
                        //if (_log.IsInfoEnabled)
                        _log.Error("EventId[" + eventId + "] 郵件群組[" + eventMail.MailGroupId + "]的郵件清單是空白.");
                        return false;
                    }
                }
                else
                {
                    //if (_log.IsInfoEnabled)
                    _log.Error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                    return false;
                }
            }
            catch (Exception e)
            {
                _log.Error("SendMailByEventIdTemplateWithSender error", e);
            }
            return false;
        }

        public static bool SendMailByEventIdWithSender(string sysId, string eventId, string subject, string message, string attachments, string sender)
        {
            Dictionary<string, string> map = new Dictionary<string, string>();
            map.Add("sysId", sysId);
            map.Add("eventId", eventId);
            try
            {
                EventMail eventMail = IBatisHelper.Get<EventMail>("Base.Mail.SelectEventMailByEventId", map);
                IList<MailInfo> mails = IBatisHelper.QueryForList<MailInfo>("Base.Mail.SelectMailInfoByGroupId", eventMail.MailGroupId);
                bool isBodyHtml = false;
                if (eventMail.IsBodyHtml != null && eventMail.IsBodyHtml.Equals("Y"))
                    isBodyHtml = true;
                else
                    isBodyHtml = false;

                _log.Error("EventId[" + eventId + "] isBodyHtml=" + isBodyHtml + " eventMail.IsBodyHtml=" + eventMail.IsBodyHtml);

                if (eventMail != null && eventMail.MailGroupId != null)
                {
                    if (mails != null && mails.Count > 0)
                    {
                        string mailTo = "";
                        foreach (MailInfo mi in mails)
                        {
                            if (mi.Email != null)
                            {
                                mailTo += mi.Email.Contains("@") ? mi.Email : mi.Email + "@fubon.com";
                                mailTo += ";";
                            }
                        }
                        if (subject == null)
                            subject = eventMail.MailSubject;
                        return SendMailWithSender(eventId, mailTo, subject, message, attachments, isBodyHtml, sender);
                    }
                    else
                    {
                        //if (_log.IsInfoEnabled)
                        _log.Error("EventId[" + eventId + "] 郵件群組[" + eventMail.MailGroupId + "]的郵件清單是空白.");
                        return false;
                    }
                }
                else
                {
                    //if (_log.IsInfoEnabled)
                    _log.Error("EventId[" + eventId + "] 不存在或沒有指定郵件群組.");
                    return false;
                }

            }
            catch (Exception e)
            {
                _log.Error("SendMailByEventIdWithSender error", e);
            }
            return false;
        }


        private static bool SendMail(string eventId, string mailTo, string subject, string message, string attachments, bool isBodyHtml)
        {
            MailUtil mu = new MailUtil(Global.MailFromUser, mailTo, subject, message, attachments, isBodyHtml);
            if (Global.MailHost != null)
            {
                mu.MailHost = Global.MailHost;
            }
            mu.MailPort = Global.MailPort;

            bool ret = mu.SendMail();
            if (_log.IsDebugEnabled)
            {
                string log = "發送事件[" + eventId + "], 主題[" + subject + "], 訊息[" + message + "]";
                if (ret)
                    _log.Info(log + "完成");
                else
                    _log.Info(log + "失敗");
            }
            return ret;
        }

        private static bool SendMailWithSender(string eventId, string mailTo, string subject, string message, string attachments, bool isBodyHtml, string sender)
        {
            MailUtil mu = new MailUtil(sender, mailTo, subject, message, attachments, isBodyHtml);
            if (Global.MailHost != null)
            {
                mu.MailHost = Global.MailHost;
            }
            mu.MailPort = Global.MailPort;

            bool ret = mu.SendMail();
            if (_log.IsDebugEnabled)
            {
                string log = "發送事件[" + eventId + "], 主題[" + subject + "], 訊息[" + message + "]";
                if (ret)
                    _log.Info(log + "完成");
                else
                    _log.Info(log + "失敗");
            }
            return ret;
        }

        public static bool SendTestMail(string mailTo)
        {
            //return SendMail("TEST", mailTo, "Mail Test", "Mail Test", false);
            return SendMail("TEST", mailTo, "Mail Test", "<H1>Hello</H1>", null, true);
        }

    }
}