﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows.Input;
using Fubon.Client.Framework;
using Fubon.Client.Framework.Widgets;
using Fubon.Client.Framework.Models;

namespace Fubon.Client.Framework.ViewModels
{
    public class MenuItemViewModel : BaseViewModel
    {
        private string _header;
        private IAppService _appService;
        private ObservableCollection<MenuItemViewModel> _childItems;
        private object _menuObject;
        private ICommand _command;


        public MenuItemViewModel(MenuItemViewModel parentModel, IAppService appService)
        {
            _appService = appService;
            ParentViewModel = parentModel;
            _childItems = new ObservableCollection<MenuItemViewModel>();
        }
        public MenuItemViewModel(Menu menu, MenuItemViewModel parentModel, IAppService appService)
        {
            _appService = appService;
            _menuObject = menu;
            _header = menu.Name;
            ParentViewModel = parentModel;
            _childItems = new ObservableCollection<MenuItemViewModel>();
            if (menu.Menus != null)
            {
                foreach (Menu submenu in menu.Menus)
                {
                    MenuItemViewModel subModel = new MenuItemViewModel(submenu, this, _appService);
                    _childItems.Add(subModel);
                }
            }

            if (menu.MenuItems != null)
            {
                foreach (MenuItem item in menu.MenuItems)
                {
                    MenuItemViewModel subModel = new MenuItemViewModel(item, this, _appService);
                    _childItems.Add(subModel);
                }
            }
        }
        public MenuItemViewModel(MenuItem item, MenuItemViewModel parentModel, IAppService appService)
        {
            _appService = appService;
            _menuObject = item;
            _header = item.ItemName;
            ParentViewModel = parentModel;
            _childItems = new ObservableCollection<MenuItemViewModel>();
            _command = new DelegateCommand<object>(OnMenuClicked, (object t) => true);
        }

        private void OnMenuClicked(object obj)
        {
            MenuItem menuItem = (MenuItem)obj;
            Function func = _appService.GetFunction(menuItem.FunctionId);

            _appService.ExecuteFunction(menuItem.ItemName, func);


        }

        public object MenuObject
        {
            get { return _menuObject; }
        }

        public string Header
        {
            get
            {
                return _header;
            }
            set
            {
                _header = value;
                RaisePropertyChanged("Header");
            }
        }

        public ObservableCollection<MenuItemViewModel> ChildMenuItems
        {
            get
            {
                return _childItems;
            }
        }

        public ICommand Command
        {
            get { return _command; }
            set
            {
                _command = value;
                RaisePropertyChanged("Command");
            }
        }


        public MenuItemViewModel ParentViewModel { get; set; }

    }

    public class SeparatorViewModel : MenuItemViewModel
    {
        public SeparatorViewModel(MenuItemViewModel parentViewModel, IAppService appService) :
            base(parentViewModel, appService)
        {

        }
    }





}
