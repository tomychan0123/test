﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace FileExpApp.IO
{
    /// <summary>
    /// DirectoryInfoExtension
    /// 
    /// Author : Lionel KOMSA
    /// Copyright © Lionel KOMSA 2011
    /// </summary>
    public static class DirectoryInfoExtension
    {
        #region "Attributes"
        private static readonly IEnumerable<FileSystemInfo> EmptyFileSystemInfos = new List<FileSystemInfo>();
        private static readonly IEnumerable<FileInfo> EmptyFileInfos = new List<FileInfo>();
        private static readonly IEnumerable<DirectoryInfo> EmptyDirectoryInfos = new List<DirectoryInfo>();
        #endregion

        #region "Methods"

        /// <summary>
        /// Returns an enumerable collection of files system information in the current directory.
        /// If an exception is thrown while try to access a directory, call given method (if not null) to know what to do.
        /// (nonrecursive method, traditional order)
        /// </summary>
        /// <param name="directory">The directory to call the method on</param>
        /// <param name="handleExceptionAccess">A callback function to call when exception thrown. The function must return true to indicate that the exception is handled and that it should be ignored; or false to let throw it.</param>
        /// <returns>An enumerable collection of file system information objects.</returns>
        public static IEnumerable<FileSystemInfo> EnumerateFileSystemInfos(this DirectoryInfo directory, Func<DirectoryInfo, Exception, bool> handleExceptionAccess)
        {
            return EnumerateFileSystemInfos(directory, SearchOption.TopDirectoryOnly, handleExceptionAccess);
        }

        /// <summary>
        /// Returns an enumerable collection of file system information that matches search subdirectory option.
        /// If an exception is thrown while try to access a directory, call given method (if not null) to know what to do.
        /// (nonrecursive method, traditional order)
        /// </summary>
        /// <param name="directory">The directory to call the method on</param>
        /// <param name="searchOption">One of the enumeration values that specifies whether the search operation should include only the current directory or all subdirectories. The default value is TopDirectoryOnly.</param>
        /// <param name="handleExceptionAccess">A callback function to call when exception thrown. The function must return true to indicate that the exception is handled and that it should be ignored; or false to let throw it.</param>
        /// <returns>An enumerable collection of file system information objects that matches searchOption.</returns>
        public static IEnumerable<FileSystemInfo> EnumerateFileSystemInfos(this DirectoryInfo directory, SearchOption searchOption, Func<DirectoryInfo, Exception, bool> handleExceptionAccess)
        {
            // To keep traditional order (return first entries of directory, then entries of first subdirectory, then entries of second subdirectory,...),
            // we use a stack of queue.
            Stack<Queue<DirectoryInfo>> directories = new Stack<Queue<DirectoryInfo>>();
            Queue<DirectoryInfo> curQueueDir = new Queue<DirectoryInfo>();
            Queue<DirectoryInfo> queueSubDir = null;
            IEnumerable<FileSystemInfo> entries = null;
            DirectoryInfo curDir = null;

            // Push a queue with the main directory
            curQueueDir.Enqueue(directory);
            directories.Push(curQueueDir);

            do
            {
                // We peek the first queue
                curQueueDir = directories.Peek();
                queueSubDir = new Queue<DirectoryInfo>();

                do
                {
                    curDir = curQueueDir.Dequeue();

                    // Try to get an enumerator on fileSystemInfos of curDir
                    try
                    {
                        entries = curDir.EnumerateFileSystemInfos("*", SearchOption.TopDirectoryOnly);
                    }
                    catch (Exception e)
                    {
                        // If there's a callback delegate and this delegate return true, we don't throw the exception
                        if (handleExceptionAccess == null || !handleExceptionAccess(curDir, e))
                            throw;
                        // If the exception wasn't throw, we make entries reference an empty collection
                        entries = EmptyFileSystemInfos;
                    }

                    // Yield return file system entries of the directory and enqueue the subdirectories
                    foreach (FileSystemInfo entrie in entries)
                    {
                        yield return entrie;
                        if (entrie is DirectoryInfo)
                            queueSubDir.Enqueue((DirectoryInfo)entrie);
                    }

                    // If there's subdir, to keep traditional order, we must stop treat curQueueDir to immediatly treat subDir
                } while (curQueueDir.Count > 0 && queueSubDir.Count == 0);

                // If curQueueDir is empty, we remove it from stack
                if (curQueueDir.Count == 0)
                    directories.Pop();
                // If there's subdirectories and that we must explore them, we push this subdirectories in the stack
                if (searchOption == SearchOption.AllDirectories && queueSubDir.Count > 0)
                    directories.Push(queueSubDir);
                else
                    queueSubDir.Clear();

            } while (directories.Count > 0);
        }

        /// <summary>
        /// Returns an enumerable collection of file system information that matches a specified search pattern and search subdirectory option.
        /// If an exception is thrown while try to access a directory, call given method (if not null) to know what to do.
        /// (nonrecursive method, traditional order)
        /// </summary>
        /// <param name="directory">The directory to call the method on</param>
        /// <param name="searchPattern">The search string. The default pattern is "*", which returns all files or directories. If you always use "*", call method without any pattern which is more faster.</param>
        /// <param name="searchOption">One of the enumeration values that specifies whether the search operation should include only the current directory or all subdirectories. The default value is TopDirectoryOnly.</param>
        /// <param name="handleExceptionAccess">A callback function to call when exception thrown. The function must return true to indicate that the exception is handled and that it should be ignored; or false to let throw it.</param>
        /// <returns>An enumerable collection of file system information objects that matches searchPattern and searchOption.</returns>
        public static IEnumerable<FileSystemInfo> EnumerateFileSystemInfos(this DirectoryInfo directory, string searchPattern, SearchOption searchOption, Func<DirectoryInfo, Exception, bool> handleExceptionAccess)
        {
            // To keep traditional order (return first entries of directory, then entries of first subdirectory, then entries of second subdirectory,...),
            // we use a stack of queue.
            Stack<Queue<DirectoryInfo>> directories = new Stack<Queue<DirectoryInfo>>();
            Queue<DirectoryInfo> curQueueDir = new Queue<DirectoryInfo>();
            Queue<DirectoryInfo> queueSubDir = null;
            IEnumerable<FileSystemInfo> entries = null;
            IEnumerable<DirectoryInfo> subDirectories = EmptyDirectoryInfos;
            DirectoryInfo curDir = null;

            // Push a queue with the main directory
            curQueueDir.Enqueue(directory);
            directories.Push(curQueueDir);

            do
            {
                // We peek the first queue
                curQueueDir = directories.Peek();
                queueSubDir = new Queue<DirectoryInfo>();

                do
                {
                    curDir = curQueueDir.Dequeue();

                    // Try to get an enumerator on fileSystemInfos of curDir
                    try
                    {
                        entries = curDir.EnumerateFileSystemInfos(searchPattern, SearchOption.TopDirectoryOnly);
                        // If we must explore sub folders, we search for them without searchPattern
                        if (searchOption == SearchOption.AllDirectories)
                            subDirectories = curDir.EnumerateDirectories("*", SearchOption.TopDirectoryOnly);
                    }
                    catch (Exception e)
                    {
                        // If there's a callback delegate and this delegate return true, we don't throw the exception
                        if (handleExceptionAccess == null || !handleExceptionAccess(curDir, e))
                            throw;
                        // If the exception wasn't throw, we make entries and subDirectories reference empty collection
                        entries = EmptyFileSystemInfos;
                        subDirectories = EmptyDirectoryInfos;
                    }

                    // Yield return file system entries of the directory
                    foreach (FileSystemInfo entrie in entries)
                    {
                        yield return entrie;
                    }

                    // Enqueue subDirectory
                    foreach (DirectoryInfo subDirectory in subDirectories)
                        queueSubDir.Enqueue(subDirectory);

                    // If there's subdir, to keep traditional order, we must stop to treat curQueueDir and treat subDir
                } while (curQueueDir.Count > 0 && queueSubDir.Count == 0);

                // If curQueueDir is empty, we remove it from stack
                if (curQueueDir.Count == 0)
                    directories.Pop();
                // If there's subdirectories we push them in the stack
                if (queueSubDir.Count > 0)
                    directories.Push(queueSubDir);

            } while (directories.Count > 0);
        }

        /// <summary>
        /// Returns an enumerable collection of files information in the current directory.
        /// If an exception is thrown while try to access a directory, call given method (if not null) to know what to do.
        /// (nonrecursive method, traditional order)
        /// </summary>
        /// <param name="directory">The directory to call the method on</param>
        /// <param name="handleExceptionAccess">A callback function to call when exception thrown. The function must return true to indicate that the exception is handled and that it should be ignored; or false to let throw it.</param>
        /// <returns>An enumerable collection of files information objects.</returns>
        public static IEnumerable<FileInfo> EnumerateFiles(this DirectoryInfo directory, Func<DirectoryInfo, Exception, bool> handleExceptionAccess)
        {
            return EnumerateFiles(directory, SearchOption.TopDirectoryOnly, handleExceptionAccess);
        }


        /// <summary>
        /// Returns an enumerable collection of files information that matches search subdirectory option.
        /// If an exception is thrown while try to access a directory, call given method (if not null) to know what to do.
        /// (nonrecursive method, traditional order)
        /// </summary>
        /// <param name="directory">The directory to call the method on</param>
        /// <param name="searchOption">One of the enumeration values that specifies whether the search operation should include only the current directory or all subdirectories. The default value is TopDirectoryOnly.</param>
        /// <param name="handleExceptionAccess">A callback function to call when exception thrown. The function must return true to indicate that the exception is handled and that it should be ignored; or false to let throw it.</param>
        /// <returns>An enumerable collection of files information objects that matches searchOption.</returns>
        public static IEnumerable<FileInfo> EnumerateFiles(this DirectoryInfo directory, SearchOption searchOption, Func<DirectoryInfo, Exception, bool> handleExceptionAccess)
        {
            // To keep traditional order (return first entries of directory, then entries of first subdirectory, then entries of second subdirectory,...)
            // we use a stack of queue.
            Stack<Queue<DirectoryInfo>> directories = new Stack<Queue<DirectoryInfo>>();
            Queue<DirectoryInfo> curQueueDir = new Queue<DirectoryInfo>();
            Queue<DirectoryInfo> queueSubDir = null;
            IEnumerable<FileSystemInfo> entries = null;
            DirectoryInfo curDir = null;

            // Push a queue with the main directory
            curQueueDir.Enqueue(directory);
            directories.Push(curQueueDir);

            do
            {
                // We peek the first queue
                curQueueDir = directories.Peek();
                queueSubDir = new Queue<DirectoryInfo>();

                do
                {
                    curDir = curQueueDir.Dequeue();

                    // Try to get an enumerator on fileSystemInfos of curDir
                    try
                    {
                        entries = curDir.EnumerateFileSystemInfos("*", SearchOption.TopDirectoryOnly);
                    }
                    catch (Exception e)
                    {
                        // If there's a callback delegate and this delegate return true, we don't throw the exception
                        if (handleExceptionAccess == null || !handleExceptionAccess(curDir, e))
                            throw;
                        // If the exception wasn't throw, we make entries reference an empty collection
                        entries = EmptyFileSystemInfos;
                    }

                    // Yield return file entries of the directory and enqueue the subdirectories
                    foreach (FileSystemInfo entrie in entries)
                    {
                        if (entrie is FileInfo)
                            yield return (FileInfo)entrie;
                        else if (entrie is DirectoryInfo)
                            queueSubDir.Enqueue((DirectoryInfo)entrie);
                    }

                    // If there's subdir, to keep traditional order, we must stop to treat curQueueDir and treat subDir
                } while (curQueueDir.Count > 0 && queueSubDir.Count == 0);

                // If curQueueDir is empty, we remove it from stack
                if (curQueueDir.Count == 0)
                    directories.Pop();
                // If there's subdirectories and that we must explore them, we push this subdirectories in the stack
                if (searchOption == SearchOption.AllDirectories && queueSubDir.Count > 0)
                    directories.Push(queueSubDir);
                else
                    queueSubDir.Clear();

            } while (directories.Count > 0);
        }

        /// <summary>
        /// Returns an enumerable collection of files information that matches a specified search pattern and search subdirectory option.
        /// If an exception is thrown while try to access a directory, call given method (if not null) to know what to do.
        /// (nonrecursive method, traditional order)
        /// </summary>
        /// <param name="directory">The directory to call the method on</param>
        /// <param name="searchPattern">The search string. The default pattern is "*", which returns all files. If you always use "*", call method without any pattern which is more faster.</param>
        /// <param name="searchOption">One of the enumeration values that specifies whether the search operation should include only the current directory or all subdirectories. The default value is TopDirectoryOnly.</param>
        /// <param name="handleExceptionAccess">A callback function to call when exception thrown. The function must return true to indicate that the exception is handled and that it should be ignored; or false to let throw it.</param>
        /// <returns>An enumerable collection of files information objects that matches searchPattern and searchOption.</returns>
        public static IEnumerable<FileInfo> EnumerateFiles(this DirectoryInfo directory, string searchPattern, SearchOption searchOption, Func<DirectoryInfo, Exception, bool> handleExceptionAccess)
        {
            // To keep traditional order (return first entries of directory, then entries of first subdirectory, then entries of second subdirectory,...),
            // we use a stack of queue.
            Stack<Queue<DirectoryInfo>> directories = new Stack<Queue<DirectoryInfo>>();
            Queue<DirectoryInfo> curQueueDir = new Queue<DirectoryInfo>();
            Queue<DirectoryInfo> queueSubDir = null;
            IEnumerable<FileInfo> entries = null;
            IEnumerable<DirectoryInfo> subDirectories = EmptyDirectoryInfos;
            DirectoryInfo curDir = null;

            // Push a queue with the main directory
            curQueueDir.Enqueue(directory);
            directories.Push(curQueueDir);

            do
            {
                // We peek the first queue
                curQueueDir = directories.Peek();
                queueSubDir = new Queue<DirectoryInfo>();

                do
                {
                    curDir = curQueueDir.Dequeue();

                    // Try to get an enumerator on fileSystemInfos of curDir
                    try
                    {
                        entries = curDir.EnumerateFiles(searchPattern, SearchOption.TopDirectoryOnly);
                        // If we must explore sub folders, we search for them without searchPattern
                        if (searchOption == SearchOption.AllDirectories)
                            subDirectories = curDir.EnumerateDirectories("*", SearchOption.TopDirectoryOnly);
                    }
                    catch (Exception e)
                    {
                        // If there's a callback delegate and this delegate return true, we don't throw the exception
                        if (handleExceptionAccess == null || !handleExceptionAccess(curDir, e))
                            throw;
                        // If the exception wasn't throw, we make entries and subDirectories reference empty collection
                        entries = EmptyFileInfos;
                        subDirectories = EmptyDirectoryInfos;
                    }

                    // Yield return file entries of the directory
                    foreach (FileInfo entrie in entries)
                    {
                        yield return entrie;
                    }

                    // Enqueue subDirectory
                    foreach (DirectoryInfo subDirectory in subDirectories)
                        queueSubDir.Enqueue(subDirectory);

                    // If there's subdir, to keep traditional order, we must stop to treat curQueueDir and treat subDir
                } while (curQueueDir.Count > 0 && queueSubDir.Count == 0);

                // If curQueueDir is empty, we remove it from stack
                if (curQueueDir.Count == 0)
                    directories.Pop();
                // If there's subdirectories we push them in the stack
                if (queueSubDir.Count > 0)
                    directories.Push(queueSubDir);

            } while (directories.Count > 0);
        }

        /// <summary>
        /// Returns an enumerable collection of directories information in the current directory.
        /// If an exception is thrown while try to access a directory, call given method (if not null) to know what to do.
        /// (nonrecursive method, traditional order)
        /// </summary>
        /// <param name="directory">The directory to call the method on</param>
        /// <param name="handleExceptionAccess">A callback function to call when exception thrown. The function must return true to indicate that the exception is handled and that it should be ignored; or false to let throw it.</param>
        /// <returns>An enumerable collection of directories information objects.</returns>
        public static IEnumerable<DirectoryInfo> EnumerateDirectories(this DirectoryInfo directory, Func<DirectoryInfo, Exception, bool> handleExceptionAccess)
        {
            return EnumerateDirectories(directory, SearchOption.TopDirectoryOnly, handleExceptionAccess);
        }

        /// <summary>
        /// Returns an enumerable collection of directories information that matches search subdirectory option.
        /// If an exception is thrown while try to access a directory, call given method (if not null) to know what to do.
        /// (nonrecursive method, traditional order)
        /// </summary>
        /// <param name="directory">The directory to call the method on</param>
        /// <param name="searchOption">One of the enumeration values that specifies whether the search operation should include only the current directory or all subdirectories. The default value is TopDirectoryOnly.</param>
        /// <param name="handleExceptionAccess">A callback function to call when exception thrown. The function must return true to indicate that the exception is handled and that it should be ignored; or false to let throw it.</param>
        /// <returns>An enumerable collection of directories information objects that matches searchOption.</returns>
        public static IEnumerable<DirectoryInfo> EnumerateDirectories(this DirectoryInfo directory, SearchOption searchOption, Func<DirectoryInfo, Exception, bool> handleExceptionAccess)
        {
            // To keep traditional order (return first entries of directory, then entries of first subdirectory, then entries of second subdirectory,...),
            // we use a stack of queue.
            Stack<Queue<DirectoryInfo>> directories = new Stack<Queue<DirectoryInfo>>();
            Queue<DirectoryInfo> curQueueDir = new Queue<DirectoryInfo>();
            Queue<DirectoryInfo> queueSubDir = null;
            IEnumerable<DirectoryInfo> entries = null;
            DirectoryInfo curDir = null;

            // Push a queue with the main directory
            curQueueDir.Enqueue(directory);
            directories.Push(curQueueDir);

            do
            {
                // We peek the first queue
                curQueueDir = directories.Peek();
                queueSubDir = new Queue<DirectoryInfo>();

                do
                {
                    curDir = curQueueDir.Dequeue();

                    // Try to get an enumerator on fileSystemInfos of curDir
                    try
                    {
                        entries = curDir.EnumerateDirectories("*", SearchOption.TopDirectoryOnly);
                    }
                    catch (Exception e)
                    {
                        // If there's a callback delegate and this delegate return true, we don't throw the exception
                        if (handleExceptionAccess == null || !handleExceptionAccess(curDir, e))
                            throw;
                        // If the exception wasn't throw, we make entries reference an empty collection
                        entries = EmptyDirectoryInfos;
                    }

                    // Yield return subdirectories of the directory and enqueue them
                    foreach (DirectoryInfo entrie in entries)
                    {
                        yield return entrie;
                        queueSubDir.Enqueue(entrie);
                    }

                    // If there's subdir, to keep traditional order, we must stop to treat curQueueDir and treat subDir
                } while (curQueueDir.Count > 0 && queueSubDir.Count == 0);

                // If curQueueDir is empty, we remove it from stack
                if (curQueueDir.Count == 0)
                    directories.Pop();
                // If there's subdirectories and that we must explore them, we push this subdirectories in the stack
                if (searchOption == SearchOption.AllDirectories && queueSubDir.Count > 0)
                    directories.Push(queueSubDir);
                else
                    queueSubDir.Clear();

            } while (directories.Count > 0);
        }

        /// <summary>
        /// Returns an enumerable collection of directories information that matches a specified search pattern and search subdirectory option.
        /// If an exception is thrown while try to access a directory, call given method (if not null) to know what to do.
        /// (nonrecursive method, traditional order)
        /// </summary>
        /// <param name="directory">The directory to call the method on</param>
        /// <param name="searchPattern">The search string. The default pattern is "*", which returns all directories. If you always use "*", call method without any pattern which is more faster.</param>
        /// <param name="searchOption">One of the enumeration values that specifies whether the search operation should include only the current directory or all subdirectories. The default value is TopDirectoryOnly.</param>
        /// <param name="handleExceptionAccess">A callback function to call when exception thrown. The function must return true to indicate that the exception is handled and that it should be ignored; or false to let throw it.</param>
        /// <returns>An enumerable collection of directories information objects that matches searchPattern and searchOption.</returns>
        public static IEnumerable<DirectoryInfo> EnumerateDirectories(this DirectoryInfo directory, string searchPattern, SearchOption searchOption, Func<DirectoryInfo, Exception, bool> handleExceptionAccess)
        {
            // To keep traditional order (return first entries of directory, then entries of first subdirectory, then entries of second subdirectory,...),
            // we use a stack of queue.
            Stack<Queue<DirectoryInfo>> directories = new Stack<Queue<DirectoryInfo>>();
            Queue<DirectoryInfo> curQueueDir = new Queue<DirectoryInfo>();
            Queue<DirectoryInfo> queueSubDir = null;
            IEnumerable<DirectoryInfo> entries = null;
            IEnumerable<DirectoryInfo> subDirectories = EmptyDirectoryInfos;
            DirectoryInfo curDir = null;

            // Push a queue with the main directory
            curQueueDir.Enqueue(directory);
            directories.Push(curQueueDir);

            do
            {
                // We peek the first queue
                curQueueDir = directories.Peek();
                queueSubDir = new Queue<DirectoryInfo>();

                do
                {
                    curDir = curQueueDir.Dequeue();

                    // Try to get an enumerator on fileSystemInfos of curDir
                    try
                    {
                        entries = curDir.EnumerateDirectories(searchPattern, SearchOption.TopDirectoryOnly);
                        // If we must explore sub folders, we search for them without searchPattern
                        if (searchOption == SearchOption.AllDirectories)
                            subDirectories = curDir.EnumerateDirectories("*", SearchOption.TopDirectoryOnly);
                    }
                    catch (Exception e)
                    {
                        // If there's a callback delegate and this delegate return true, we don't throw the exception
                        if (handleExceptionAccess == null || !handleExceptionAccess(curDir, e))
                            throw;
                        // If the exception wasn't throw, we make entries and subDirectories reference empty collection
                        entries = EmptyDirectoryInfos;
                        subDirectories = EmptyDirectoryInfos;
                    }

                    // Yield return subdirectories entries of the directory
                    foreach (DirectoryInfo entrie in entries)
                    {
                        yield return entrie;
                    }

                    // Enqueue subDirectory
                    foreach (DirectoryInfo subDirectory in subDirectories)
                        queueSubDir.Enqueue(subDirectory);

                    // If there's subdir, to keep traditional order, we must stop to treat curQueueDir and treat subDir
                } while (curQueueDir.Count > 0 && queueSubDir.Count == 0);

                // If curQueueDir is empty, we remove it from stack
                if (curQueueDir.Count == 0)
                    directories.Pop();
                // If there's subdirectories we push them in the stack
                if (queueSubDir.Count > 0)
                    directories.Push(queueSubDir);

            } while (directories.Count > 0);
        }

        #endregion
    }
}