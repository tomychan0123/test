﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Fubon.Utility.Common
{
    public sealed class EnvironmentUtil
    {
        public static string GetDownloadPath()
        {
            string pathUser = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            return Path.Combine(pathUser, "Downloads");
        }
    }
}
