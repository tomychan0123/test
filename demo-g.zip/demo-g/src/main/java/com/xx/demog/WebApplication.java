package com.xx.demog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;

@SpringBootApplication
//@EnableSpringDataWebSupport
//http://localhost:8888/hiSpringBoot/swagger-ui.html
public class WebApplication extends SpringBootServletInitializer {
	
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(WebApplication.class);
	}
	
	public static void main(String[] args) throws Exception {
		SpringApplication.run(WebApplication.class, args);
	}
}

