package com.xx.demog.service;

import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.List;
import com.xx.demog.domain.mail.EventMail;
import com.xx.demog.domain.mail.MailGroup;
import com.xx.demog.domain.mail.MailInfo;

public interface MailService {
	public List <MailGroup>GetMailGroupList(String groupId);
		
	public List<MailInfo> selectMailInfoById(String id);
		
	public List<MailInfo> GetCanaddUserList(String groupId);
	
	public boolean InsertMailGroup(MailGroup mailgroupdata);
	
	public boolean UpdateMailGroup(MailGroup mailgroupdata);
	
	public boolean DeleteMailGroup(MailGroup mailgroupdata);
	
	public boolean InsertMailGroupItem(MailInfo maildata);
	
	public boolean DeleteGroupItem(MailInfo maildata);
	
	public boolean DeleteGroupItemByMailId(MailInfo maildata);
	
	public boolean InsertMail(MailInfo mailuserdata);
	
	public boolean UpdateMail(MailInfo mailuserdata);
	
	public boolean DeleteMail(MailInfo mailuserdata);
	
	public List<EventMail> GetEventMailList(String eventGroupId);
	
	public int UpdateEventMailList(List<EventMail> eventMailList);
	
	public boolean SendMailByEventId(String sysId, String eventId, String subject, String message, String fileName, ByteArrayInputStream attachments);
		
	public boolean SendMailByEventIdTemplate(String sysId, String eventId, String subject, HashMap<String, Object> attrs, String fileName, ByteArrayInputStream attachments);
		
	public boolean SendMailByEventIdAndReceiver(String sysId, String eventId, String fileName, ByteArrayInputStream attachments, String receiver);
	
	public boolean SendMailByEventIdWithReceiverAndSender(String sysId, String eventId, String subject, String message, String fileName, ByteArrayInputStream attachments, String receiver, String sender);
	
	public boolean SendMailByEventIdTemplateWithReceiver(String sysId, String eventId, String subject, HashMap<String, Object> attrs, String fileName, ByteArrayInputStream attachments, String receiver);
	
	public boolean SendMailByEventIdTemplateWithReceiverAndSender(String sysId, String eventId, String subject, HashMap<String, Object> attrs, String fileName, ByteArrayInputStream attachments, String receiver, String sender);
	
	public boolean SendMailByEventIdAndReceiverAndSender(String sysId, String eventId, String fileName, ByteArrayInputStream attachments, String receiver, String sender);
	
	public boolean SendMailByEventIdAndSender(String sysId, String eventId, String fileName, ByteArrayInputStream attachments, String sender);
	
	public boolean SendMailByEventIdTemplateWithSender(String sysId, String eventId, String subject, HashMap<String, Object> attrs, String fileName, ByteArrayInputStream attachments, String sender);
	
	public boolean SendMailByEventIdWithSender(String sysId, String eventId, String subject, String message, String fileName, ByteArrayInputStream attachments, String sender);
}
