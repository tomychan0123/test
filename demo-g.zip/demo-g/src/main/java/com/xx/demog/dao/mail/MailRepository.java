package com.xx.demog.dao.mail;

import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Repository;
import com.xx.demog.domain.mail.EventMail;
import com.xx.demog.domain.mail.MailGroup;
import com.xx.demog.domain.mail.MailInfo;

//@Component
//@Mapper
@Repository
public interface MailRepository{
	public enum SequenceKeys {
		DATA_FLOW("DF"),MailGroup("MG"),MailID("MI"),DeptID("DI");
		
		private String value;
		
		private SequenceKeys(String value) {
			this.value = value;
		}
		
		public String getValue() {
			return this.value;
		}
	}
	
	public List <MailGroup>SelectAllMailGroup(String groupId) ;
	
	public List<MailInfo> SelectMailInfoByGroupId(String id);
	
	public List<MailInfo> SelectMailInfobyUse(String groupId);
	
	public boolean InsMailGroup(MailGroup mailgroupdata);
	
	public boolean UpdMailGroup(MailGroup mailgroupdata);
	
	public boolean DelMailGroup(MailGroup mailgroupdata);
	
    public boolean InsMailGroupItem(MailInfo maildata);
    
    public boolean DelMailGroupItem(MailInfo maildata);
    
    public boolean DelMailGroupItemByMailId(MailInfo maildata);
    
    /// <summary>
    ///   Mail 
    /// </summary>
    public boolean InsMailInfo(MailInfo mailuserdata);
    
    public boolean UpdMailInfo(MailInfo mailuserdata);


    public boolean DelMailInfo(MailInfo mailuserdata);
    
    //以下為event
    
    public List<EventMail> SelectEventMailByEventGroup(String eventGroupId);

    public int UpdateEventMail(EventMail eventMailList);
    
    public List<EventMail> SelectEventMailByEventId(Map map);
    
    public List<EventMail> SelectEventMailFullByEventId(Map map);
    
}
