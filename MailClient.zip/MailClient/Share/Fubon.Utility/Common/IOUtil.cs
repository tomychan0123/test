﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
namespace Fubon.Utility.Common
{
    public class IOUtil
    {
        public static Encoding DEFAULT_ENCODING = Encoding.UTF8;
        public static String ReadFromFile(string fileName)
        {
            String ret = null;
            StringBuilder sb = new StringBuilder();
            try
            {
                using (StreamReader sr = new StreamReader(fileName, DEFAULT_ENCODING))     //小寫TXT
                {
                    String line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        sb.Append(line);
                        sb.Append("\n");
                    }
                }
                ret = sb.ToString();
            }
            catch (Exception e)
            {
                Console.WriteLine("The file could not be read:");
                Console.WriteLine(e.Message);
            }
            return ret;
        }

        public static String ReadFromResource(string resourceName)
        {
            String ret = null;
            StringBuilder sb = new StringBuilder();
            try
            {
                var assembly = Assembly.GetExecutingAssembly();

                using (Stream stream = assembly.GetManifestResourceStream(resourceName))
                {
                    using (StreamReader sr = new StreamReader(stream, DEFAULT_ENCODING))
                    {
                        String line;
                        while ((line = sr.ReadLine()) != null)
                        {
                            sb.Append(line);
                            sb.Append("\n");
                        }
                    }
                }
                ret = sb.ToString();
            }
            catch (Exception e)
            {
                Console.WriteLine("The file could not be read:");
                Console.WriteLine(e.Message);
            }
            return ret;
        }
        public static String ReadFromResource(string resourceName, string dllName)
        {
            String ret = null;
            StringBuilder sb = new StringBuilder();
            try
            {
                var assembly = Assembly.Load(dllName);

                using (Stream stream = assembly.GetManifestResourceStream(resourceName))
                {
                    using (StreamReader sr = new StreamReader(stream, DEFAULT_ENCODING))
                    {
                        String line;
                        while ((line = sr.ReadLine()) != null)
                        {
                            sb.Append(line);
                            sb.Append("\n");
                        }
                    }
                }
                ret = sb.ToString();
            }
            catch (Exception e)
            {
                Console.WriteLine("The file could not be read:");
                Console.WriteLine(e.Message);
            }
            return ret;
        }

        public static void ReadFromResourceToFile(string resourceName, string dllName, string fileName)
        {
            try
            {
                var assembly = Assembly.Load(dllName);

                using (Stream stream = assembly.GetManifestResourceStream(resourceName))
                {
                    FileStream fs = null;
                    try
                    {
                        fs = new FileStream(fileName, FileMode.Create, FileAccess.Write);
                        stream.CopyTo(fs);
                        fs.Flush();
                        fs.Close();
                    }
                    catch
                    {
                        if (fs != null)
                            fs.Close();
                    }
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public static byte[] ReadBytesFromFile(string fileName)
        {
            byte[] bytes = File.ReadAllBytes(fileName);
            return bytes;
        }

        /// <summary>
        ///  從串流中擷取資料轉換為位元組陣列
        /// </summary>
        /// <param name="stream">串流來源</param>
        /// <returns>位元組陣列</returns>
        public static byte[] ReadBytesFromStream(Stream stream)
        {
            long originalPosition = 0;

            if (stream.CanSeek)
            {
                originalPosition = stream.Position;
                stream.Position = 0;
            }

            try
            {
                byte[] readBuffer = new byte[4096];

                int totalBytesRead = 0;
                int bytesRead;

                while ((bytesRead = stream.Read(readBuffer, totalBytesRead, readBuffer.Length - totalBytesRead)) > 0)
                {
                    totalBytesRead += bytesRead;

                    if (totalBytesRead == readBuffer.Length)
                    {
                        int nextByte = stream.ReadByte();
                        if (nextByte != -1)
                        {
                            byte[] temp = new byte[readBuffer.Length * 2];
                            Buffer.BlockCopy(readBuffer, 0, temp, 0, readBuffer.Length);
                            Buffer.SetByte(temp, totalBytesRead, (byte)nextByte);
                            readBuffer = temp;
                            totalBytesRead++;
                        }
                    }
                }

                byte[] buffer = readBuffer;
                if (readBuffer.Length != totalBytesRead)
                {
                    buffer = new byte[totalBytesRead];
                    Buffer.BlockCopy(readBuffer, 0, buffer, 0, totalBytesRead);
                }
                return buffer;
            }
            finally
            {
                if (stream.CanSeek)
                {
                    stream.Position = originalPosition;
                }
            }
        }

        public static void WriteToFile(string text, string fileName)
        {
            using (StreamWriter sw = new StreamWriter(fileName, false, DEFAULT_ENCODING))
            {
                sw.Write(text);
                sw.Flush();
                sw.Close();
            }
        }

        public static void WriteStreamToFile(Stream stream, string fileName)
        {
            byte[] buff = new byte[1024 * 4];
            using (FileStream fs = new FileStream(fileName, FileMode.Create,
                                  FileAccess.Write))
            {
                int read = stream.Read(buff, 0, 1024 * 4);
                if (read != -1)
                {
                    fs.Write(buff, 0, read);
                }
                fs.Flush();
                fs.Close();
            }
        }

        public static void WriteBytesToFile(byte[] bytes, string fileName)
        {
            File.WriteAllBytes(fileName, bytes);
        }

        /// <summary>
        /// 取得檔案名稱的下一序號檔案，如果原始檔案存在，會以(i)序號作為檔案名稱
        /// </summary>
        /// <param name="sourceFileName"></param>
        /// <returns></returns>
        public static string GetNextFileName(string sourceFileName)
        {
            string path = sourceFileName;
            string dir = Path.GetDirectoryName(path);
            string fileName = Path.GetFileNameWithoutExtension(path);
            string fileExt = Path.GetExtension(path);

            for (int i = 1; ; ++i)
            {
                if (!File.Exists(path))
                    return path;

                path = Path.Combine(dir, fileName + "(" + i + ")" + fileExt);
            }
        }
    }
}
