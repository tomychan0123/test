﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;

namespace Fubon.Utility.Common
{
    /// <summary>
    /// Md5Utils gives a cryptographic utils to the application
    /// </summary>
    public class Md5Util
    {
        public Md5Util()
        { }
        /// <summary>
        /// Encode string using MD5 encoding. The string is converted into array
        /// of bytes and converted back to string after the MD5 encoding
        /// </summary>
        /// <param name="raw">string to be encoded</param>
        /// <returns>encoded string</returns>
        public static string GetMd5Base64(string raw)
        {
            ASCIIEncoding asciienc = new ASCIIEncoding();
            UTF8Encoding utf8enc = new UTF8Encoding();
            byte[] buffer = utf8enc.GetBytes(raw);
            return GetMd5Base64(buffer);
        }

        public static string GetMd5Base64(byte[] source)
        {
            MD5 md5serv = MD5CryptoServiceProvider.Create();
            byte[] hash = md5serv.ComputeHash(source);
            return Convert.ToBase64String(hash).Replace("=", String.Empty).Replace('+', '-').Replace('/', '_'); 
        }

        public static string GetMd5Hex(string raw)
        {           
            ASCIIEncoding asciienc = new ASCIIEncoding();
            UTF8Encoding utf8enc = new UTF8Encoding();
            byte[] buffer = utf8enc.GetBytes(raw);
            return GetMd5Hex(buffer);
        }

        public static string GetMd5Hex(byte[] source)
        {
            MD5 md5serv = MD5CryptoServiceProvider.Create();
            byte[] hash = md5serv.ComputeHash(source);
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < hash.Length; i++)
            {
                sb.Append(hash[i].ToString("x2"));
            }
            return sb.ToString().ToLower();
        }
    }
}
