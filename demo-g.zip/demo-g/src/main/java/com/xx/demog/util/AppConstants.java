package com.xx.demog.util;

import org.apache.commons.lang.StringUtils;

/**
############################################################################
#    PROGRAM NAME: AppConstants
#
#    DESCRIPTION:
#
#    NOTES:(若使用上有特別需注意事項)
#          
#    WRITTEN BY: Charlotte
#
#    MODIFIED:
#         Charlotte Jun 24, 2009 - Initial version.
#         Nick 2010/07/02 - 加入SQL_MAP_CONFIG
#         nick 2011/01/26 - [201101040437]加入IO_ERROR_ID
#         Tom 2011/9/5 - add CONFIGURE_PATH_COMMON
#         Tom 2012/9/11 - [201209110040]add FTS connection
#         nick 2013/05/31 - [201305310199-00]新增兩日額度使用異常差異分析功能
#         Eric 2013/08/16 - [201308150315-00]TMU兩張稽核報表-1.客戶兩張權利金檢核表/2.FxOption重組交易檢核表
############################################################################
*/
public class AppConstants {
    public static String contextNameWithoutSlash ="";
    public static String CONFIGURE_PATH = "C:/FMG/config/demo-g/";
    public static final String SQL_MAP_CONFIG = "config/sqlMapConfig.xml";
    public static final String SQL_MAP_CONFIG_FTS = "config/sqlMapConfigFts.xml";
    public static final String SQL_MAP_CONFIG_TIP_RPT = "config/sqlMapConfigTipRpt.xml";
    public static final String IO_ERROR_ID = "BLK-ERR-0001";
    public static final String CONFIGURE_PATH_COMMON = "C:/FMG/config/";
    
    public static void initSystemParameter(String contextName){
        try{
            contextNameWithoutSlash=contextName.replaceAll("/","");

            if (StringUtils.isEmpty(contextNameWithoutSlash)){
                contextNameWithoutSlash="ima";
            }
        
            CONFIGURE_PATH=CONFIGURE_PATH_COMMON+contextNameWithoutSlash+"/";
        }catch(Exception e){
            CONFIGURE_PATH = "C:/FMG/config/demo-g/";
        }
    }
}
