﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using FileExpApp.Models;

namespace FileExpApp.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        public ActionResult Index()
        {
            return View();
        }
        /// <summary>
        /// 取得web.config設定目錄下的所有目錄
        /// </summary>
        /// <returns></returns>
        public JsonResult GetDirs()
        {
            FileDir rootDirs = FileToolKits.GetDirs();
            return this.Json(rootDirs, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 取得目錄中的檔案
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public JsonResult GetFiles(string id)
        {
            List<FileInf> files = FileToolKits.GetFilesByFolderName(id);
            return this.Json(files, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 傳出檔案
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult DownloadFile(string id)
        {
            if (System.IO.File.Exists(id))
            {
                string  strDownLoadFileName   = System.IO.Path.GetFileName(id);
                string mimeType = "application/octet-stream"; //"application/binary"; //
                if (HttpContext.Request.Browser.Browser == "IE")
                {
                    strDownLoadFileName = HttpContext.Server.UrlPathEncode(strDownLoadFileName);
                }
                using (System.IO.FileStream fs = new System.IO.FileStream(id, System.IO.FileMode.Open, 
                    System.IO.FileAccess.Read, System.IO.FileShare.Read))
                {
                    // Read the source file into a byte array.
                    byte[] bytes = new byte[fs.Length];
                    int numBytesToRead = (int)fs.Length;
                    int numBytesRead = 0;
                    while (numBytesToRead > 0)
                    {
                        // Read may return anything from 0 to numBytesToRead.
                        int n = fs.Read(bytes, numBytesRead, numBytesToRead);
                        // Break when the end of the file is reached.
                        if (n == 0)
                            break;
                        numBytesRead += n;
                        numBytesToRead -= n;
                    }
                    numBytesToRead = bytes.Length;
                    return File(bytes, mimeType, strDownLoadFileName);
                }
             }
            return null;
        }
    }
}