﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows;
using System.ComponentModel;
using Fubon.Client.Framework.Models;
using Fubon.Client.Framework.Services;

namespace Fubon.Client.Framework.ViewModels
{
    public class LoginViewModel : BaseViewModel
    {
        private string _email = string.Empty;
        private string _password = string.Empty;
        private IAppService _appService;
        private bool _canInput = true;
        private string _showLogining = "Collapsed";
        private UserAuthority _userAuthority;

        public LoginViewModel(IAppService appService)
        {
            this._appService = appService;
        }

        public string EMail
        {
            get { return _email; }
            set
            {
                _email = value;
                RaisePropertyChanged("EMail");
            }
        }
        public string Password
        {
            set
            {
                if (_password != value)
                    _password = value;
            }
        }
        public bool CanInput
        {
            get
            {
                return _canInput;
            }
            set
            {
                _canInput = value;
                RaisePropertyChanged("CanInput");
            }
        }

        public string ShowLogining
        {
            get
            {
                return _showLogining;
            }
            set
            {
                _showLogining = value;
                RaisePropertyChanged("ShowLogining");
            }
        }

        public bool IsPrototype
        {
            get
            {
                return AppSettings.IsPrototype;
            }
        }

        public string AppName
        {
            get
            {
                return AppSettings.AppName;
            }
        }

        public override void OnViewLoaded()
        {
            //base.OnViewLoaded();            
        }

        #region Commands
        private ICommand _LoginCommand = null;
        public ICommand LoginCommand
        {
            get
            {
                if (_LoginCommand == null)
                    _LoginCommand = new DelegateCommand<PasswordBox>(Login, CanLogin);
                return _LoginCommand;
            }
        }
        private Exception _exception;
        private void Login(PasswordBox password)
        {

            _password = password.Password.Trim();
            if (_password == "")
            {
                _appService.ShowWarning("密碼不能為空白，請輸入。");
                return;
            }

            CanInput = false;
            ShowLogining = "Visible";
            _exception = null;
            BackgroundWorker bw = new BackgroundWorker();

            /// add the event handler for each progress
            bw.DoWork += new DoWorkEventHandler(DoLogin);

            bw.RunWorkerCompleted +=
                new RunWorkerCompletedEventHandler(AfterLogin);

            /// start the background work
            bw.RunWorkerAsync();
        }

        private void DoLogin(object sender, DoWorkEventArgs e)
        {
            if (_appService.Authenticator == null)
            {
                _appService.ShowWarning("IAuthenticator is null.");
                return;
            }
            try
            {
                _userAuthority = _appService.Authenticator.Login(_email, _password, new KeyValuePair<string, string>());
            }
            catch (Exception ex)
            {
                _exception = ex;
                //_appService.ShowWarning("ERR:" + ex);
                return;
            }
        }

        public void AfterLogin(object sender, RunWorkerCompletedEventArgs e)
        {
            ShowLogining = "Collapsed";

            if (_exception != null)
            {
                if (_exception is TimeoutException || _exception is System.ServiceModel.EndpointNotFoundException)
                    _appService.ShowWarning("伺服器連線發生無法連線或連線逾時，請稍後再試。\n或洽詢系統負責人員。");
                else if (_exception.Message != null && _exception.Message.StartsWith("ERR"))
                    _appService.ShowWarning("登人錯誤，原因: " + _exception.Message);
                else
                    _appService.ShowWarning("伺服器連線發生無法預期錯誤，請稍後再試。\n或洽詢系統負責人員。");

                CanInput = true;
                ShowLogining = "Collapsed";
                return;
            }
            else if (_userAuthority == null)
            {
                _appService.ShowWarning("登入失敗，可能是帳號或密碼輸入錯誤。\n請重新登入。");
                CanInput = true;
                ShowLogining = "Collapsed";
                return;
            }
            TokenManagerMessageInspector.Instance.Token = _userAuthority.Token;
            Application.Current.Dispatcher.Invoke((Action)delegate
            {
                _appService.UserAuthority = _userAuthority;
                CanInput = true;
                ShowLogining = "Collapsed";
                _userAuthority = null;
            });
        }

        private bool CanLogin(PasswordBox t)
        {
            return true;
        }

        private ICommand _CancelCommand = null;
        public ICommand CancelCommand
        {
            get
            {
                if (_CancelCommand == null)
                    _CancelCommand = new DelegateCommand(Cancel, () => true);
                return _CancelCommand;
            }
        }
        private void Cancel()
        {
            _appService.Shutdown();
        }
        #endregion
    }
}
