package com.xx.demog.util;

import java.util.HashMap;

import org.stringtemplate.v4.ST;
import org.stringtemplate.v4.STGroup;


public class TemplateHelper {
    public static String RenderTemplate(String templateName, String attrName, Object attrObj)
    {

    	ST st = GetStringTemplate(templateName);
        st.add(attrName, attrObj);

        String result = st.toString();
        return result;
    }

    public static String RenderTemplate(String templateName, HashMap<String, Object> objects)
    {
        ST st = GetStringTemplate(templateName);
        for (String key : objects.keySet())
        {
            st.add(key, objects.get(key));
        }

        String result = st.toString();
        return result;
    }

    //ex: templateContent: "Hello $paraName"
    public static String RenderTemplateByContent(String templateContent, HashMap<String, Object> objects)
    {
        ST st = new ST(templateContent);
        for (String key : objects.keySet())
        {
            st.add(key, objects.get(key));
        }

        String result = st.toString();
        return result;
    }
    
    public static ST GetStringTemplate(String templateName)
    {
    	STGroup stg = new STGroup(); //new StringTemplateGroup("default");

        ST st = stg.getInstanceOf("Fubon/Mdp/Server/Templates/" + templateName);
        return st;
    }
}
