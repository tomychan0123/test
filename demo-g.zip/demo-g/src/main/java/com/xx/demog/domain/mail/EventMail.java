package com.xx.demog.domain.mail;

import java.util.Date;

public class EventMail {
	// 郵件群組物件
	private MailGroup mailGroup;
	// 事件識別碼(FITSBOND_RCVESB: 接收到FITS評價電文)
	private String eventId;
	// 事件名稱(已接收FITS電文)
	private String eventName;
	// 事件的類別(FITSBOND:FITS債券評價流程)
	private String eventGroupId;
	// 郵件群組ID
	private String mailGroupId;	
	// 資料更新員工編號
	private String updateUserId;	
	// 資料更新員工姓名
	private String updateUserName;
	
	// 資料更新時間
	private Date updateDate;

	private String mailSubject;

	private String mailTemplate;

	private String isBodyHtml;

	private String sysId;

	public MailGroup getMailGroup() {
		return mailGroup;
	}

	public void setMailGroup(MailGroup mailGroup) {
		this.mailGroup = mailGroup;
	}

	public boolean Equals(Object obj)
    {
        if (obj instanceof EventMail)
        {
            EventMail b = (EventMail) obj;
            if (b.mailGroupId != mailGroupId || b.eventId != eventId || b.eventGroupId != eventGroupId || b.sysId != sysId)
            {
                return false;
            }
            return true;
        }
        return false;
    }

    public int hashCode()
    {
        return ("" + eventId + eventGroupId + eventName + mailGroupId + sysId).hashCode();
    }

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getEventGroupId() {
		return eventGroupId;
	}

	public void setEventGroupId(String eventGroupId) {
		this.eventGroupId = eventGroupId;
	}

	public String getMailGroupId() {
		return mailGroupId;
	}

	public void setMailGroupId(String mailGroupId) {
		this.mailGroupId = mailGroupId;
	}

	public String getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public String getUpdateUserName() {
		return updateUserName;
	}

	public void setUpdateUserName(String updateUserName) {
		this.updateUserName = updateUserName;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getMailSubject() {
		return mailSubject;
	}

	public void setMailSubject(String mailSubject) {
		this.mailSubject = mailSubject;
	}

	public String getMailTemplate() {
		return mailTemplate;
	}

	public void setMailTemplate(String mailTemplate) {
		this.mailTemplate = mailTemplate;
	}

	public String getIsBodyHtml() {
		return isBodyHtml;
	}

	public void setIsBodyHtml(String isBodyHtml) {
		this.isBodyHtml = isBodyHtml;
	}

	public String getSysId() {
		return sysId;
	}

	public void setSysId(String sysId) {
		this.sysId = sysId;
	}
}
