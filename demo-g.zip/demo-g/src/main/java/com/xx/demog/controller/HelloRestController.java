package com.xx.demog.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.xx.demog.service.HelloOtherService;

@RestController()
public class HelloRestController {
	 @Value("${cont.hello}")
	    private String hello;

	
	@Autowired
	HelloOtherService helloOtherService;
	
	@RequestMapping(value = "/rest", method = { RequestMethod.POST,
			RequestMethod.GET })
	public String rest() {
		return "Hello Rest Controller Spring Boot!";
	}

	@RequestMapping("/health")
	public String health() {
		return "ok";
	}

	@RequestMapping("/health2")
	public Map rootContext() {
		Map a = new HashMap();
		a.put("AAA", hello);
		return a;
	}
	
	
	@RequestMapping(value = "/feign-hello", method = RequestMethod.GET)
    public String feignHello() {
        return helloOtherService.health();
    }

	
}
